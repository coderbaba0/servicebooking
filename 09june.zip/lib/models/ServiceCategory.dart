class Servicedetails {
  Servicedetails({
      required this.id,
      required this.categoryId,
      required this.name,
      required this.description,
      required this.pricePerUnit,
      required this.issuesTitle,
      required this.issuesValues,
      required this.issuesDescription,
      required this.customerHave,
      required this.isOfferApplicable,
      required this.image,
      required this.createdAt,
      required this.updatedAt,});
  Servicedetails.fromJson(dynamic json) {
    id = json['id'];
    categoryId = json['category_id'];
    name = json['name'];
    description = json['description'];
    pricePerUnit = json['price_per_unit'];
    issuesTitle = json['issues_title'];
    issuesValues = json['issues_values'];
    issuesDescription = json['issues_description'];
    customerHave = json['customer_have'];
    isOfferApplicable = json['is_offer_applicable'];
    image = json['image'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }
 late  int id;
  late  int categoryId;
  late String name;
  late String description;
  late int pricePerUnit;
  late  String issuesTitle;
  late String issuesValues;
  late String issuesDescription;
  late String customerHave;
  late int isOfferApplicable;
  late String image;
  late String createdAt;
  late String updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['category_id'] = categoryId;
    map['name'] = name;
    map['description'] = description;
    map['price_per_unit'] = pricePerUnit;
    map['issues_title'] = issuesTitle;
    map['issues_values'] = issuesValues;
    map['issues_description'] = issuesDescription;
    map['customer_have'] = customerHave;
    map['is_offer_applicable'] = isOfferApplicable;
    map['image'] = image;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }
}