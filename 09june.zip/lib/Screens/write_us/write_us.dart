import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/persisit/constantdata.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../data_repo/sendwriteus.dart';
List<String> list = <String>['Choose Category', 'Related to Service', 'Related to Service Worker', 'Related to payment'];

class Suggestion extends StatefulWidget {
  static String routeName = "/suggestion";
  const Suggestion({Key? key}) : super(key: key);

  @override
  State<Suggestion> createState() => _SuggestionState();
}
class _SuggestionState extends State<Suggestion> {
  DateTime selectedDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        builder: (context, child) {
          return Theme(
            data: Theme.of(context).copyWith(
              colorScheme: ColorScheme.light(
                primary: kPrimaryColor, // <-- SEE HERE
                onPrimary: Colors.white, // <-- SEE HERE
                onSurface: Colors.black, // <-- SEE HERE
              ),
              textButtonTheme: TextButtonThemeData(
                style: TextButton.styleFrom(
                  primary: Colors.red, // button text color
                ),
              ),
            ),
            child: child!,
          );
        },
        initialDate: selectedDate,
        firstDate: DateTime(2022, 8),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }
  int _value=0;
  int myIndex=0;
  String dropdownValue = list.first;
  TextEditingController messagecontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.suggestions),
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        title: Text('Write Us',style: TextStyle(color: Colors.white,fontSize: 18,shadows: [
          Shadow(
            blurRadius: 1.0, // shadow blur
            color: Colors.black, // shadow color
            offset:
            Offset(0.5, 0.5), // how much shadow will be shown
          ),
        ],),),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
               _writeus(),
                SizedBox(height: getProportionateScreenWidth(8)),

              ],
            ),
          ),

        ),
      ),
    );
  }
  _writeus() {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.only(top: 30.0,left: 25,bottom: 20.0,right: 25),
          child: Column(
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Radio(
                          activeColor: kPrimaryColor,
                          value: 0, groupValue: _value, onChanged: (value){
                        setState(() {
                          _value= value!;
                        });

                      }),
                      Text("Suggestion",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w300),),

                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          activeColor: kPrimaryColor,
                          value: 1, groupValue: _value, onChanged: (value){
                        setState(() {
                          _value= value!;
                        });
                      }),
                      Text("Complaints",style: TextStyle(fontSize: 15,color: Colors.black,fontWeight: FontWeight.w200),)

                    ],
                  ),
                ],
              ),
              // SizedBox(height: 10,),
              // Container(
              //   width: double.infinity,
              //   decoration: BoxDecoration(
              //     borderRadius: BorderRadius.circular(10),
              //       border: Border.all(color: Colors.black,width: 1)
              //   ),
              //   child: DropdownButtonHideUnderline(
              //     child: DropdownButton(
              //       icon: Icon(Icons.arrow_drop_down_sharp,size: 30,),
              //       onChanged: ( String? newvalue){
              //         setState(() {
              //           dropdownValue=newvalue!;
              //         });
              //       },
              //       value: dropdownValue,
              //       items: list.map<DropdownMenuItem<String>>((String value) {
              //         return DropdownMenuItem(
              //           value: value,
              //           child: Padding(
              //             padding: const EdgeInsets.only(left: 20),
              //             child: Text(value),
              //           ),
              //         );
              //       }).toList(),
              //     ),
              //   ),
              // ),
              Divider(
                color: kPrimaryColor,
                thickness: 0.8,
                indent: 5,
                endIndent: 5,
              ),

              const SizedBox(height: 10.0,),
              Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(width: 0.8,color: Colors.black)
                    ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                        child: Text("Service Date: "+"${selectedDate.toLocal()}".split(' ')[0],style: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),),
                      )),
                  const SizedBox(width: 10.0,),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary:kPrimaryColor,
                      side: BorderSide(color: Colors.white,width: 1),
                    ),
                    onPressed: () => _selectDate(context),
                    child: const Text('Choose'),
                  ),
                ],
              ),
              const SizedBox(height: 10.0,),
              Text('Note: Please, Mention your Suggesions or any type of Complaints in the below box.',style: TextStyle(fontSize: 12,fontWeight: FontWeight.w200),),
              SizedBox(height: 20,),
              Container(
                width: double.infinity,
                child: TextField(
                  controller: messagecontroller,
                  minLines: 10,
                  maxLines: 10,
                  keyboardType: TextInputType.multiline,
                  style: TextStyle(color: Colors.black,fontSize: 16),
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.only(left: 15,top: 20),
                    hintText: "Please, type your message..",
                    hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: kPrimaryColor),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: Colors.red),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Container(
                  height: 50,
                  width: double.infinity,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(primary: kPrimaryColor,side: BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                      onPressed: (){
                        if(messagecontroller.text.isEmpty){
                          Fluttertoast.showToast(
                            msg: "Please type your Message!",
                            backgroundColor: Colors.black,
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                          );
                        }
                        else{
                          sendwriteus(Constant.userId.toString(),_value.toString()=='0'?'Suggestion':'Complaints',"${selectedDate.toLocal()}".split(' ')[0],messagecontroller.text).then((value) => value? showAlertDialog(context,'Message Sucessfully Sent!') : showAlertDialog(context,'Somthing Error!') ,);
                        }
                      }, child: Text("Submit",style: TextStyle(fontSize: 18,color: Colors.white),))),
            SizedBox(height: 20,),
            ],
          ),
      ),
    )
    );
  }
  showAlertDialog(BuildContext context,String message) {
    // set up the button
    Widget okButton = TextButton(
      child: Text("OK",style: TextStyle(color: kPrimaryColor),),
      onPressed: () {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Suggestion(),
            ));
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Message"),
      content: Text(message),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}