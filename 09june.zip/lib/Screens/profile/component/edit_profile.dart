import 'dart:convert';
import 'dart:io';
import 'package:book_services/Screens/profile/profile.dart';
import 'package:http/http.dart' as http;

import 'package:book_services/constant/constui.dart';
import 'package:book_services/helper/global.dart';
import 'package:flutter/material.dart';
import 'package:book_services/size_config.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';

import '../../../persisit/constantdata.dart';
import '../../../persisit/helperfunctions.dart';

class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);
  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {

  final _formKey = GlobalKey<FormState>();
  String? name;
  String? email;
  String? address;
  TextEditingController namectrl = TextEditingController();
  TextEditingController emailctrl = TextEditingController();
  TextEditingController addressctrl = TextEditingController();

  final ImagePicker _picker = ImagePicker();
  File? _selectedImage;
  String imageUrl = 'Empty';
  String? fileName;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white54,
      body: Container(
        margin: EdgeInsets.only(
          left: 10,
          right: 10,
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15, top: 10, bottom: 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: Icon(
                              Icons.cancel,
                              size: 30,
                              color: kPrimaryColor,
                            ),
                          )
                        ],
                      ),
                      InkWell(
                        onTap: () {
                          _optionsDialogBox();
                        },
                        child: Stack(alignment: Alignment.bottomRight, children: [
                          Positioned(
                            child: CircleAvatar(
                              radius: 35,
                              backgroundColor: kPrimaryColor.withOpacity(0.6),
                              child: Icon(
                                Icons.person_add_alt_1_outlined,
                                size: 35,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ]),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        width: SizeConfig.screenWidth * 0.7,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: TextFormField(
                          // initialValue: Constant.username,
                          controller: namectrl..text=Constant.username,
                          onSaved: (newValue) => name = newValue!,
                          style: TextStyle(color: Colors.black, fontSize: 16),
                          cursorColor: kPrimaryColor,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, enter name!';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.person,
                              color: kPrimaryColor,
                            ),
                            contentPadding: EdgeInsets.only(left: 15,top: 20),
                            hintText: "Enter name..",
                            hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.black),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: kPrimaryColor),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        width: SizeConfig.screenWidth * 0.7,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: TextFormField(
                          // initialValue: Constant.useremail,

                          controller: emailctrl..text=Constant.useremail,
                          onSaved: (newValue) => email = newValue!,
                          validator: (val) {
                            return RegExp(
                                r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                .hasMatch(val!)
                                ? null
                                : "Please enter a valid email";
                          },
                          style: TextStyle(color: Colors.black, fontSize: 16),
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.mail,
                              color: kPrimaryColor,
                            ),
                            isDense: true,
                            isCollapsed: true,
                            contentPadding: EdgeInsets.only(left: 15,top: 12),
                            hintText: "Type email-address..",
                            hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.black),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: kPrimaryColor),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Container(
                        width: SizeConfig.screenWidth * 0.7,
                        child: TextFormField(
                          controller: addressctrl,
                          onSaved: (newValue) => address = newValue!,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, enter address!';
                            }
                            return null;
                          },


                          minLines: 3,
                          maxLines: 3,
                          keyboardType: TextInputType.multiline,
                          style: TextStyle(color: Colors.black, fontSize: 16),
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                            prefixIcon: Padding(
                              padding: const EdgeInsets.only(bottom: 40.0),
                              child: Icon(
                                Icons.location_on_outlined,
                                color: kPrimaryColor,
                              ),
                            ),
                            contentPadding: EdgeInsets.only(left: 15,top: 20),
                            hintText: "Please, type your address..",
                            hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.black),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: kPrimaryColor),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: kPrimaryColor,
                            side: BorderSide(color: Colors.white, width: 2),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10))),
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            updateprofile(Constant.userId,name!,email!,address!);
                          }


                        },
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 60.0, right: 60, top: 10, bottom: 10),
                          child: Text(
                            "Submit",
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 40,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _optionsDialogBox() {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Choose Source'),
          contentPadding: const EdgeInsets.all(20.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                GestureDetector(
                  child: const Text("Take a Picture"),
                  onTap: openCamera,
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                ),
                const Divider(
                  color: Colors.white70,
                  height: 1.0,
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                ),
                GestureDetector(
                  child: const Text("Open Gallery"),
                  onTap: openGallery,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future openCamera() async {
    Navigator.of(context).pop();
    var imageFrmCamera = await _picker.getImage(source: ImageSource.camera);
    setState(() {
      _selectedImage = File(imageFrmCamera!.path);
      fileName = _selectedImage!.path.split('/').last;
      print(fileName);
    });
    //if (mounted) Navigator.of(context).pop();
  }

  //Gallery method
  Future openGallery() async {
    Navigator.of(context).pop();
    var pickedFile = await _picker.getImage(source: ImageSource.gallery);
    setState(() {
      _selectedImage = File(pickedFile!.path);
      fileName = _selectedImage!.path.split('/').last;
      print(fileName);
    });
    // if (mounted) Navigator.of(context).pop();
  }
  //update screen
  updateprofile(String id, String name, String email, String address) async {
    var url = Uri.parse(baseUrl+'customer/update');
    var body = {
      'id':id,
      'name': name,
      'email': email,
      'address': address,
    };
    var headerList =  {
      "Content-Type": "application/json",
      "accept": "application/json",
      "Access-Control-Allow-Origin": "*"
    };
    var req = http.MultipartRequest('POST', url);
    req.headers.addAll(headerList);
    req.fields.addAll(body);
    var res = await req.send();
    final resBody = await res.stream.bytesToString();
    if (res.statusCode >= 200 && res.statusCode < 300) {
      var data = json.decode(resBody);
      if(data['status']==true){
        print(data['message']);
        var actualdata = data['data'];
        var username = actualdata['name']; var useremail = actualdata['email'];
        setState(() {
          Constant.username= username.toString();
          Constant.useremail = useremail;
        });
        await HelperFunctions.saveUserEmailSF(useremail);
        await HelperFunctions.saveUserNameSF(username);
        Fluttertoast.showToast(
          msg: data['message'],
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );
        Navigator.of(context).pushNamedAndRemoveUntil(
            Profile.routeName, (route) => false);
      }
      else{
        Fluttertoast.showToast(
          msg: data['message'],
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );
      }
    }
    else {
      Fluttertoast.showToast(
        msg: "Something is wrong..",
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
    }

  }
}
