// import 'package:flutter/material.dart';
//
// import '../../constant/constui.dart';
// class Paymentmethod extends StatefulWidget {
//   const Paymentmethod({Key? key}) : super(key: key);
//
//   @override
//   State<Paymentmethod> createState() => _PaymentmethodState();
// }
//
// class _PaymentmethodState extends State<Paymentmethod> {
//   var _value = 1;
//   @override
//   Widget build(BuildContext context) {
//     return   Scaffold(
//       body: Container(
//           child: Padding(
//             padding: const EdgeInsets.all(15.0),
//             child: Column(
//               children: [
//                 Padding(
//                   padding: const EdgeInsets.all(8.0),
//                   child: Text('Choose payment Method : ',
//                       style:
//                       TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
//                 ),
//                 Center(
//                   child: Container(
//                     height: MediaQuery.of(context).size.height * 0.1,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(color: Colors.grey)),
//                     child: RadioListTile(
//                         title: Padding(
//                           padding: const EdgeInsets.only(left: 10),
//                           child: Text(
//                             "Pay with Google",
//                             style: TextStyle(
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.w500,
//                                 fontFamily: "Inter"),
//                           ),
//                         ),
//                         activeColor: kPrimaryColor,
//                         value: 1,
//                         groupValue: _value,
//                         onChanged: (value) {
//                           setState(() {
//                             _value = value!;
//                           });
//                         }),
//                   ),
//                 ),
//                 SizedBox(
//                   height: 10,
//                 ),
//                 Center(
//                   child: Container(
//                     height: MediaQuery.of(context).size.height * 0.1,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(color: Colors.grey)),
//                     child: RadioListTile(
//                         title: Padding(
//                           padding: const EdgeInsets.only(left: 10),
//                           child: Text(
//                             "Pay with Stripe",
//                             style: TextStyle(
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.w500,
//                                 fontFamily: "Inter"),
//                           ),
//                         ),
//                         activeColor: kPrimaryColor,
//                         value: 2,
//                         groupValue: _value,
//                         onChanged: (value) {
//                           setState(() {
//                             _value = value!;
//                           });
//                         }),
//                   ),
//                 ),
//                 SizedBox(
//                   height: 10,
//                 ),
//                 Center(
//                   child: Container(
//                     height: MediaQuery.of(context).size.height * 0.1,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(color: Colors.grey)),
//                     child: RadioListTile(
//                         title: Padding(
//                           padding: const EdgeInsets.only(left: 10),
//                           child: Text(
//                             "Pay on Cash",
//                             style: TextStyle(
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.w500,
//                                 fontFamily: "Inter"),
//                           ),
//                         ),
//                         activeColor: kPrimaryColor,
//                         value: 3,
//                         groupValue: _value,
//                         onChanged: (value) {
//                           setState(() {
//                             _value = value!;
//                           });
//                         }),
//                   ),
//                 ),
//                 SizedBox(
//                   height: 10,
//                 ),
//                 Center(
//                   child: Container(
//                     height: MediaQuery.of(context).size.height * 0.1,
//                     decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(10),
//                         border: Border.all(color: Colors.grey)),
//                     child: RadioListTile(
//                         title: Padding(
//                           padding: const EdgeInsets.only(left: 10),
//                           child: Text(
//                             "Pay with Crypto",
//                             style: TextStyle(
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.w500,
//                                 fontFamily: "Inter"),
//                           ),
//                         ),
//                         activeColor: kPrimaryColor,
//                         value: 4,
//                         groupValue: _value,
//                         onChanged: (value) {
//                           setState(() {
//                             _value = value!;
//                           });
//                         }),
//                   ),
//                 ),
//                 SizedBox(height: 20),
//
//
//               ],
//             ),
//           ),
//
//       ),
//     );
//   }
// }
import 'package:book_services/constant/constui.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';

class PaymentMethod extends StatefulWidget {
  const PaymentMethod({Key? key}) : super(key: key);
  @override
  State<PaymentMethod> createState() => _PaymentMethodState();
}

class _PaymentMethodState extends State<PaymentMethod> {
  final TextEditingController _textFieldController = TextEditingController();
  final List<String> _list = [
    "Pay with Cheque",
    "Cash in person",
    "Bank Transfer",
    "Crypto Pay",
  ];
  int _value = 0;
  @override
  void initState() {
    _textFieldController.text='TGXsi3PrSkhRaFnZJ8aUNjVxJ2bccUnVBm';
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30.0),
                  child: Container(
                    decoration:
                        BoxDecoration(borderRadius: BorderRadius.circular(2)),
                    child: Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Payment method",
                                  style: TextStyle(fontSize: 18),
                                ),
                                IconButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    icon: Icon(
                                      Icons.cancel,
                                      color: kPrimaryColor,
                                      size: 30,
                                    ))
                              ],
                            ),
                          ),
                          Divider(
                            color: kPrimaryColor,
                            thickness: 1,
                          ),
                          ListView.builder(
                              itemCount: _list.length,
                              shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              physics: const ScrollPhysics(),
                              itemBuilder: (context, index) {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 20),
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: Colors.grey)),
                                    child: RadioListTile(
                                        activeColor: kPrimaryColor,
                                        title: Text(_list[index]),
                                        value: index,
                                        groupValue: _value,
                                        onChanged: (ind) {
                                          setState(() {
                                            _value = ind!;
                                          });
                                        }),
                                  ),
                                );
                              }),
                          Center(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: kPrimaryColor,
                                  side:
                                      BorderSide(color: Colors.white, width: 2),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5))),
                              onPressed: () {
                                if (_value == 0) {
                                  // Navigator.pop(context);
                                  showAlertDialog(
                                      context,
                                      'Assign Cheque with below details: ',
                                      '\"Al Khail Al Aswad Technical Services\"',
                                      '\n\n Amount : AED 40');
                                } else if (_value == 2) {
                                  showAlertDialog(
                                      context,
                                      'Bank Transfer Details: ',
                                      '  Bank Name :\n Account Number : \n SWIFT Code: \n IBAN Number: ',
                                      '\n Service Price AED: 40');
                                } else if (_value == 3) {
                                  showAlertDialog2(
                                      context, 'Scan or copy ');
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 10.0, horizontal: 20),
                                child: Text(
                                  "Continue",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  showAlertDialog(
      BuildContext context, String title, String message, String price) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: TextStyle(color: kPrimaryColor),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(title),
      content: RichText(
        text: TextSpan(
          text: message,
          style: TextStyle(color: Colors.black54, fontSize: 16),
          children: <TextSpan>[
            TextSpan(
                text: price,
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.orange)),
          ],
        ),
      ),
      actions: [
        okButton,
      ],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog2(BuildContext context, String title, ) {
    // set up the button
    // Widget okButton = TextButton(
    //   child: Text(
    //     "OK",
    //     style: TextStyle(color: kPrimaryColor),
    //   ),
    //   onPressed: () {
    //     Navigator.pop(context);
    //   },
    // );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title),
          IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.close,color: Colors.red,))
        ],
      ),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('USDT -TRC20'),
        Container(
          child: Image.asset("assets/images/bar.png"),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 30.0),
          child: TextField(
            enabled: false,
            controller: _textFieldController,
            decoration: InputDecoration(
            ),
          ),
        ),
    SizedBox(height: 5,),
    TextButton.icon(
    style: TextButton.styleFrom(primary: kPrimaryColor,side:BorderSide(width: 1,color: kPrimaryColor),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
      label: Text(
        "Copy",
        style: TextStyle(color: kPrimaryColor),
      ),
      icon: Icon(Icons.copy_outlined,color: kPrimaryColor,),
      onPressed: ()async {
          await Clipboard.setData(ClipboardData(text:_textFieldController.text)).then((value) =>  Fluttertoast.showToast(
            msg: " Copied Successfully!",
            backgroundColor: Colors.black54,
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.CENTER,
          )
          );
          // copied successfully
      },
    ),
      ]),
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
