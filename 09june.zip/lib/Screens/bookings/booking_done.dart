import 'package:book_services/Screens/write_us/write_us.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/size_config.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../data_repo/saveratings.dart';
import '../../persisit/constantdata.dart';
import '../../widgets/ratingbar.dart';

class BookingDone extends StatefulWidget {
  static String routeName = "/bookingdone";
  final bookingdata;
  const BookingDone({Key? key, this.bookingdata}) : super(key: key);
  @override
  State<BookingDone> createState() => _BookingDoneState();
}

class _BookingDoneState extends State<BookingDone> {
  double rating = 3.5;
  TextEditingController feedbackcontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        titleSpacing: 2,
        backgroundColor: kPrimaryColor,
        automaticallyImplyLeading: true,
        leadingWidth: 40,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ], ////change your color here
        ),
        title: ListTile(
          title: const Text(
            'Kitchen Cleaning',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              shadows: [
                Shadow(
                  blurRadius: 1.0, // shadow blur
                  color: Colors.black, // shadow color
                  offset: Offset(0.5, 0.5), // how much shadow will be shown
                ),
              ],
            ),
          ),
          subtitle: const Text(
            'id :#85676525',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              shadows: [
                Shadow(
                  blurRadius: 1.0, // shadow blur
                  color: Colors.black, // shadow color
                  offset: Offset(0.5, 0.5), // how much shadow will be shown
                ),
              ],
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _orderdone(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _orderdone() {
    return Card(
        child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(children: [
              ExpansionTile(
                collapsedTextColor: kPrimaryColor,
                collapsedIconColor: kPrimaryColor,
                textColor: kPrimaryColor,
                iconColor: kPrimaryColor,
                childrenPadding:
                    EdgeInsets.only(left: 0, right: 0, top: 0, bottom: 0),
                title: Text('Booking Details : ',
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: "Inter",
                        fontWeight: FontWeight.w600)),
                // Contents
                children: [
                  Divider(
                    thickness: 1,
                    color: kPrimaryColor,
                    endIndent: 0,
                    indent: 0,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Booking Id:",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Inter"),
                      ),
                      Text(
                        '#' + widget.bookingdata['id'].toString(),
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            fontFamily: "Inter"),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Service: ",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Inter"),
                      ),
                      Container(
                          width: 100,
                          child: Text(
                            widget.bookingdata['service'],
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                fontFamily: "Inter"),
                            maxLines: 2,
                          )),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Invoice no:",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Inter"),
                      ),
                      Text(
                        widget.bookingdata['invoice_no'].toString() == 'null'
                            ? 'Not created'
                            : widget.bookingdata['invoice_no'].toString(),
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            fontFamily: "Inter"),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Contact: ",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Inter"),
                      ),
                      Text(
                        widget.bookingdata['mobile'].toString(),
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w400,
                            fontFamily: "Inter"),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Service Date :",
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Inter"),
                      ),
                      Text(
                        widget.bookingdata['date'],
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Inter"),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Divider(
                thickness: 1,
                color: kPrimaryColor,
                endIndent: 0,
                indent: 0,
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Sumit kumar",
                    style: TextStyle(
                        fontSize: 17,
                        fontFamily: "Inter",
                        fontWeight: FontWeight.w600),
                  ),
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: kPrimaryColor)),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Text(
                        "Completed",
                        style: TextStyle(
                            fontSize: 15,
                            fontFamily: "Inter",
                            color: kPrimaryColor,
                            fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    "10 March, 2023",
                    style: TextStyle(
                        fontFamily: "Inter",
                        fontSize: 12,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.grey),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Row(
                        children: [
                          Icon(
                            Icons.star,
                            size: 20,
                            color: Colors.orange,
                          ),
                          Text(
                            "4.7 ",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: "Inter",
                                fontWeight: FontWeight.w200),
                          ),
                          Text(
                            "(180) Ratings",
                            style: TextStyle(
                                fontSize: 13,
                                fontFamily: "Inter",
                                fontWeight: FontWeight.w200),
                          )
                        ],
                      ),
                    ),
                  ),
                  CircleAvatar(
                    backgroundColor: kPrimaryColor.withOpacity(0.3),
                    radius: 20,
                    child: Icon(
                      Icons.person,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  Flexible(
                      child: Text(
                    "Job Completed on saturday 11 March 2023",
                    style: TextStyle(
                      fontFamily: "Inter",
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                    maxLines: 2,
                  )),
                ],
              ),
              Divider(
                thickness: 1,
                color: kPrimaryColor,
                endIndent: 0,
                indent: 0,
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Rate Now : ",
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: "Inter",
                        fontWeight: FontWeight.w600),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: StarRating(
                      color: Colors.orange,
                      rating: rating,
                      onRatingChanged: (rating) =>
                          setState(() => this.rating = rating),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                child: TextField(
                  minLines: 5,
                  maxLines: 5,
                  controller: feedbackcontroller,
                  keyboardType: TextInputType.multiline,
                  style: TextStyle(color: Colors.black, fontSize: 16),
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    labelStyle: TextStyle(fontSize: 15, color: kPrimaryColor),
                    labelText: "Feedback : ",
                    hintStyle:
                        TextStyle(fontSize: 13, fontWeight: FontWeight.w300),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: kPrimaryColor),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: Colors.red),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: kPrimaryColor,
                        side: BorderSide(color: Colors.white, width: 2),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5))),
                    onPressed: () {
                      feedbackcontroller.text.isEmpty
                          ? Fluttertoast.showToast(
                              msg: 'Please write Feedback first',
                              backgroundColor: Colors.black,
                              toastLength: Toast.LENGTH_LONG,
                              gravity: ToastGravity.CENTER,
                            )
                          : sendratings(Constant.userId.toString(),widget.bookingdata['id'].toString(),widget.bookingdata['service_engineer']['id'].toString(),rating.toStringAsFixed(2),feedbackcontroller.text).then((value) =>value? showAlertDialog(context,'Feedback Submitted'):   Fluttertoast.showToast(
                        msg: 'Something Error',
                        backgroundColor: Colors.black,
                        toastLength: Toast.LENGTH_LONG,
                        gravity: ToastGravity.CENTER,
                      ));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Text(
                        "Sumit Feedback",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
            ])));
  }
  showAlertDialog(BuildContext context,String message) {
    // set up the button
    Widget okButton = TextButton(
      child: Text("OK",style: TextStyle(color: kPrimaryColor),),
      onPressed: () {
       setState(() {
         feedbackcontroller.clear();
       });
       Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Message"),
      content: Text(message),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

}
