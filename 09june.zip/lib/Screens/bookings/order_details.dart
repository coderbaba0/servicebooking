import 'dart:async';

import 'package:book_services/Screens/bookings/paymetmethod.dart';
import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/showprogress.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/utils/services.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../constant/loader.dart';
import '../../data_repo/cancelbooking.dart';
import '../../persisit/constantdata.dart';
import 'booking_list.dart';
class OrderDetails extends StatefulWidget {
  static String routeName = "/orderdetails";
  const OrderDetails({Key? key, @required this.bookingdata}) : super(key: key);
  final bookingdata;
  @override
  State<OrderDetails> createState() => _OrderDetailsState();
}
class _OrderDetailsState extends State<OrderDetails> {
  var _value = 1;

  bool _isloading=false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        titleSpacing: 2,
        backgroundColor: kPrimaryColor,
        automaticallyImplyLeading: true,
        leadingWidth: 40,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],////change your color here
        ),
        title: ListTile(
          title:  Text(
            widget.bookingdata['service'],
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 16,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
          subtitle:  Text(
            'id :#'+widget.bookingdata['id'].toString(),
            style: TextStyle(color: Colors.white,fontSize: 12,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
        ),
        actions:  [
          widget.bookingdata['service_engineer'].toString()=='null'?Container():InkWell(
            onTap: ()
            async{
              Uri phoneno = Uri.parse(widget.bookingdata['service_engineer']['phone'].toString());
              (await launchUrl(phoneno));
              Fluttertoast.showToast(
                msg: "Dialer is Opening..",
                backgroundColor: Colors.black,
                toastLength: Toast.LENGTH_LONG,
                gravity: ToastGravity.CENTER,
              );

            },
            child: Padding(
              padding: EdgeInsets.only(right: 20),
              child: CircleAvatar(
                backgroundColor: Colors.white54,
                  radius: 20,
                  child: Icon(Icons.dialer_sip_outlined,color: Colors.white,size: 20,)),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _orderdetails(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }
  _orderdetails() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Assigned to :',style: TextStyle(fontSize: 17,fontFamily: "Inter",fontWeight: FontWeight.w600),),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(widget.bookingdata['service_engineer'].toString()=='null'?'Not Assigned':widget.bookingdata['service_engineer']['name']!.toString(),style: TextStyle(fontSize: 17,fontFamily: "Inter",fontWeight: FontWeight.w600),),
                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: kPrimaryColor)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Text(widget.bookingdata['status'],style: TextStyle(fontSize: 15,fontFamily: "Inter",color: kPrimaryColor,fontWeight: FontWeight.w500),),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                   widget.bookingdata['service_engineer'].toString()=='null'?Container():Text( 'Mob : ' +widget.bookingdata['service_engineer']['phone'].toString(),style: TextStyle(fontFamily: "Inter",fontSize: 12,fontWeight: FontWeight.w500),),
              ],
            ),
            SizedBox(height: 20,),
            Container(
              color: kPrimaryColor.withOpacity(0.1),
              child: DottedBorder(
                radius: Radius.circular(100),
                color: Colors.black,//color of dotted/dash line
                strokeWidth: 1, //thickness of dash/dots
                dashPattern: [5,6],
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 10),
                      Text("Cancellation policy: ",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),),
                      SizedBox(height: 5,),
                      Text("If you cancel a Booking or don't show up, any cancellation/no-show fee and any refund will depend on the Service Provider's cancellation/no-show policy.",style: TextStyle(fontSize: 14,fontWeight: FontWeight.w100,fontFamily: "Inter",overflow: TextOverflow.visible),)
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 15,),
            Container(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.2),
                  border: Border.all(color: kPrimaryColor,width: 1),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      RichText(
                        text: TextSpan(
                          text: 'Payment Status:',
                          style: TextStyle(color: Colors.black54,fontSize: 16),
                          children: const <TextSpan>[
                            TextSpan(text: ' Pending', style: TextStyle(fontWeight: FontWeight.bold,color: Colors.orange)),
                          ],
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(primary: kPrimaryColor,side:BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),
                        onPressed: (){
                          showDialog(context: context, builder: (context)=>Center(child: PaymentMethod()));
                        },child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text("Pay now ",style: TextStyle(fontSize: 16,color: Colors.white),),
                      ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text("Booking Details : ",style: TextStyle(fontSize: 17,fontFamily: "Inter",fontWeight: FontWeight.w600),),
              ],
            ),

            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),

            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Booking Id:",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),),
                Text('#'+widget.bookingdata['id'].toString(),style: TextStyle(fontSize: 15,fontWeight: FontWeight.w600,fontFamily: "Inter"),)
              ],
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Service: ",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),),

                Flexible(child: Text(widget.bookingdata['service'],style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),maxLines: 2,)),


              ],

            ),

            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Invoice no:",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),),

                Text(widget.bookingdata['invoice_no'].toString()=='null'?'Not created':widget.bookingdata['invoice_no'].toString(),style: TextStyle(fontSize: 14,fontWeight: FontWeight.w400,fontFamily: "Inter"),),

              ],

            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Contact: ",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['mobile'].toString(),
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Service Date :",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['date'],
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Time Slot :",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['time'],
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Address: ",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),),

                Container(width:100,child: Text(widget.bookingdata['location_for'],style: TextStyle(fontSize: 13,fontFamily: "Inter"),maxLines: 3,)),
              ],

            ),
            SizedBox(height: 10,),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(height: 5,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: kPrimaryColor,side:BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),
                  onPressed: (){
                    showModalBottomSheet(
                        shape: RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.vertical(top: Radius.circular(25))),
                        context: (context),
                        builder: (BuildContext context) {
                          return SizedBox(
                            height: 250,
                            child: Center(
                              child: Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 40),
                                    child: Text(
                                      "Please, Confirm!",
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Text(
                                    "Are you sure to Cancel this booking? ",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                  SizedBox(
                                    height: 30,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    children: [
                                      ElevatedButton(
                                          style: ElevatedButton.styleFrom(primary: Colors.grey,side: BorderSide(color: Colors.white,width: 1,),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),

                                          onPressed: () {
                                            Navigator.pop(context);
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(10.0),
                                            child: Text("No",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),),
                                          )),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      ElevatedButton(
                                          style: ElevatedButton.styleFrom(primary: kPrimaryColor,side: BorderSide(color: Colors.white,width: 1,),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),
                                          onPressed: () {
                                            cancelbooking(widget.bookingdata['id'].toString()).then((value) =>value? Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) => AllBookings(),
                                                )):'');
                                            // Navigator.pop(context);
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.all(10.0),
                                            child: Text(
                                                "Yes",style: TextStyle(fontWeight: FontWeight.w500,fontSize: 15)
                                            ),
                                          )),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          );
                        });

                  },child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text("Cancel Booking",style: TextStyle(fontSize: 16,color: Colors.white),),
                  ),
                ),
                _isloading?Container(width:40,height:40,child: ColorLoader2()):Container(),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: Colors.grey,side:BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),
                  onPressed: () async{
                    setState(() {
                      _isloading=true;
                    });
                    await DatabaseService(uid:widget.bookingdata['id'].toString()).createbookings(Constant.usermobile.toString(),Constant.userId.toString(),widget.bookingdata['service']).then((value) =>
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              ChatScreen(
                                bookingdata: widget.bookingdata,
                              ),
                        ))).then((value) => setState(() {
                      _isloading=false;
                    }));
                    // _isloading? Constants.showProgressDialog(context,'Please,wait..'):Container();
                  },child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Text("Chat Now",style: TextStyle(fontSize: 16,color: Colors.white),),
                ),
                ),
              ],
            ),
            SizedBox(height: 5,),

          ],
        ),
      ),
    );

  }

}
