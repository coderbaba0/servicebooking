import 'dart:convert';

import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/loader.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/utils/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../persisit/constantdata.dart';
class EngNotifications extends StatefulWidget {
  static String routeName = "/notifications";

  const EngNotifications({Key? key,})
      : super(key: key);
  @override
  State<EngNotifications> createState() => _EngNotificationsState();
}
class _EngNotificationsState extends State<EngNotifications>
    with TickerProviderStateMixin {
  Stream<QuerySnapshot>? notifications;
  bool _isloading = false;
  @override
  void initState() {
    super.initState();
    getnotifications();
    // init();
  }
  getnotifications() {
    DatabaseService().getNotifications(Constant.userId.toString()).then((val) {
      setState(() {
        notifications = val;
      });
    });
  }
  //
  // init() async {
  //   Constant.sharedPreference = await SharedPreferences.getInstance();
  //   Constant.sharedPreferenceMessages =
  //       Constant.sharedPreference!.getStringList("messages") ?? [];
  //   Constant.sharedPreferenceMessages.forEach((element) {
  //     Map<String, dynamic> messageMap =
  //         Map<String, dynamic>.from(json.decode(element));
  //     Constant.messagesForUI.add(messageMap);
  //   });
  //   // print(Constant.messagesForUI.length);
  // }
  @override
  Widget build(BuildContext context) {
    TabController tabController = TabController(length: 1, vsync: this);
    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ], //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          'Notifications',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: true,
        actions: [
          InkWell(
            onTap: () async
               {
              await DatabaseService(uid: Constant.userId.toString()).deletedoc(Constant.userId.toString());
              // await DatabaseService(uid: Constant.userId.toString()).deletenotifications(Constant.userId.toString());
              },
            child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Text(
                    'Clear All',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w500),
                  ),
                )),
          )
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 2.0, right: 2.0),
                    child: Column(
                      children: [
                        SizedBox(
                          height: 5,
                        ),
                        Container(
                          height: SizeConfig.screenHeight * 0.04,
                          decoration: BoxDecoration(
                              borderRadius:
                              BorderRadius.all(Radius.circular(50.0))),
                          child: TabBar(
                            labelStyle: TextStyle(
                                fontWeight: FontWeight.w500, fontSize: 15),
                            labelColor: Colors.black,
                            controller: tabController,
                            indicatorColor: Colors.transparent,
                            indicator: BoxDecoration(
                              border: Border.all(
                                color: Colors.black54,
                                width: 1.0,
                              ),
                              borderRadius:
                              BorderRadius.circular(50), // Creates border
                            ),
                            tabs: [
                              Tab(
                                text: "Bookings",
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              Container(
                                height:
                                MediaQuery.of(context).size.height * 0.75,
                                child: TabBarView(
                                  physics: NeverScrollableScrollPhysics(),
                                  controller: tabController,
                                  children: [
                                    // _isloading?Container(width:40,height:40,child: ColorLoader2()):Container(),
                                    //
                                    // Constant.messagesForUI.isEmpty
                                    //     ? Row(
                                    //   // mainAxisAlignment: MainAxisAlignment.center,
                                    //       mainAxisAlignment: MainAxisAlignment.center,
                                    //       children: [
                                    //         Text("No notifications"),
                                    //       ],
                                    //     )
                                    //
                                    //     : ListView.builder(
                                    //     physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                                    //     shrinkWrap:true,
                                    //     itemCount: Constant.messagesForUI.length,
                                    //     itemBuilder: (context,index){
                                    //       final Map<String, dynamic> message = Constant.messagesForUI.reversed.toList()[index];
                                    //       return Padding(
                                    //         padding: const EdgeInsets.only(top: 10.0),
                                    //         child: Card(
                                    //           child: ListTile(
                                    //             onTap: () async {
                                    //               setState(() {
                                    //                 _isloading=true;
                                    //               });
                                    //               await DatabaseService(uid:message['id']).createbookings(Constant.usermobile.toString(),Constant.userId.toString(),message['service']).then((value) =>
                                    //                   Navigator.push(
                                    //                       context,
                                    //                       MaterialPageRoute(
                                    //                         builder: (context) =>
                                    //                             ChatScreen(
                                    //                               bookingdata: message,
                                    //                             ),
                                    //                       ))).then((value) => setState(() {
                                    //                 _isloading=false;
                                    //               }));
                                    //             },
                                    //             leading: CircleAvatar(
                                    //                 radius: 20,
                                    //                 backgroundColor: kPrimaryColor.withOpacity(0.5),
                                    //                 child: const Icon(
                                    //                   Icons.notifications_active_outlined,
                                    //                   color: Colors.white,
                                    //                 )),
                                    //             title: Text(message['title'],
                                    //                 style: TextStyle(inherit: true,overflow: TextOverflow.visible,
                                    //                     fontSize: 15, color: Colors.black,fontWeight: FontWeight.w300)),
                                    //             subtitle: Padding(
                                    //               padding: const EdgeInsets.only(top: 5.0),
                                    //               child: Text(message['body'].toString().substring(0,16)),
                                    //             ),
                                    //             selectedTileColor: kPrimaryColor.withOpacity(0.5),
                                    //           ),
                                    //
                                    //
                                    //         ),
                                    //       );
                                    //     }),
                                    StreamBuilder(
                                        stream: notifications,
                                        builder:
                                            (context, AsyncSnapshot snapshot) {
                                          if (snapshot.hasData) {
                                            return ListView.builder(
                                                physics:
                                                const BouncingScrollPhysics(
                                                    parent:
                                                    AlwaysScrollableScrollPhysics()),
                                                shrinkWrap: true,
                                                itemCount:
                                                snapshot.data.docs.length,
                                                itemBuilder: (context,int index) {
                                                  return Padding(
                                                    padding:
                                                    const EdgeInsets.only(
                                                        top: 10.0),
                                                    child: Card(
                                                      child: ListTile(
                                                        onLongPress: (){

                                                        },
                                                        onTap: () async {
                                                          await DatabaseService(uid: Constant.userId.toString()).updateNotifications(snapshot.data.docs[snapshot.data.docs.length - 1 - index].reference.id.toString());
                                                          await DatabaseService(
                                                              uid: snapshot
                                                                  .data
                                                                  .docs[snapshot.data.docs.length - 1 - index]
                                                              ['id'])
                                                              .createbookings(
                                                              Constant
                                                                  .usermobile
                                                                  .toString(),
                                                              Constant
                                                                  .userId
                                                                  .toString(),
                                                              snapshot.data
                                                                  .docs[snapshot.data.docs.length - 1 - index]
                                                              [
                                                              'service'])
                                                              .then((value) =>
                                                              Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder:
                                                                        (context) =>
                                                                        ChatScreen(
                                                                          bookingdata: snapshot
                                                                              .data
                                                                              .docs[snapshot.data.docs.length - 1 - index],
                                                                        ),
                                                                  )));
                                                        },
                                                        leading: CircleAvatar(
                                                            radius: 20,
                                                            backgroundColor:
                                                            kPrimaryColor
                                                                .withOpacity(
                                                                0.5),
                                                            child: (snapshot.data
                                                                .docs[snapshot.data.docs.length - 1 - index]
                                                            ['read']==false)? Icon(
                                                              Icons
                                                                  .notifications_on_sharp,
                                                              color:
                                                              Colors.black,
                                                            ):Icon(
                                                              Icons
                                                                  .notifications_active_outlined,
                                                              color:
                                                              Colors.white,
                                                            )),
                                                        title: (snapshot.data
                                                            .docs[snapshot.data.docs.length - 1 - index]
                                                        ['read']==false)?
                                                        Text(
                                                            snapshot.data
                                                                .docs[snapshot.data.docs.length - 1 - index]
                                                            ['body'],
                                                            style: TextStyle(
                                                                inherit: true,
                                                                overflow:
                                                                TextOverflow
                                                                    .visible,
                                                                fontSize: 14,
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                FontWeight
                                                                    .w600)): Text(
                                                            snapshot.data
                                                                .docs[snapshot.data.docs.length - 1 - index]
                                                            ['body'],
                                                            style: TextStyle(
                                                                inherit: true,
                                                                overflow:
                                                                TextOverflow
                                                                    .visible,
                                                                fontSize: 14,
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                FontWeight
                                                                    .w300)),
                                                        subtitle: Padding(
                                                          padding:
                                                          const EdgeInsets
                                                              .all(8.0),
                                                          child: Text(snapshot
                                                              .data
                                                              .docs[snapshot.data.docs.length - 1 - index]
                                                          ['time']
                                                              .toString()
                                                              .substring(
                                                              0, 16)),
                                                        ),
                                                        selectedTileColor:
                                                        kPrimaryColor
                                                            .withOpacity(
                                                            0.5),
                                                      ),
                                                    ),
                                                  );
                                                });
                                          } else {
                                            return Center(child: Container(width:30,height:30,child: ColorLoader2()));
                                          }
                                        }),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

}
