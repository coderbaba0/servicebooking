import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/Screens/walkthrough/WalkthroughScreen.dart';
import 'package:book_services/persisit/helperfunctions.dart';
import 'package:flutter/material.dart';
import 'dart:async';

import '../../persisit/constantdata.dart';
import '../Register/service_engineer.dart';
import '../bookings/accepted_booking.dart';

class SplashScreen extends StatefulWidget {
  static String routeName = "/splash";
  const SplashScreen({Key? key}) : super(key: key);
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  bool _isSignedIn = false;
  @override
  void initState() {
    super.initState();
    getLoggedInStatus();
  }
  getLoggedInStatus() async {
    await HelperFunctions.getUserLoggedInStatus().then((value) {
      if (value != null) {
        setState(() {
          _isSignedIn = value;
        });
      }
    });
    await HelperFunctions.getUserMobileFromSF().then((value) {
      if (value != null) {
        setState(() {
          Constant.usermobile = value;
        });
      }
    });
    await HelperFunctions.getUserIdFromSF().then((value) {
      if (value != null) {
        setState(() {
          Constant.userId = value;
        });
      }
    });
    await HelperFunctions.getUserNameFromSF().then((value) {
      if (value != null) {
        setState(() {
          Constant.username = value;
        });
      }
    });
    await HelperFunctions.getUserEmailFromSF().then((value) {
      if (value != null) {
        setState(() {
          Constant.useremail = value;
        });
      }
    });
  }
  _SplashScreenState(){
    Timer(const Duration(milliseconds: 3000), () {
      setState(() {
        _isSignedIn?
        // Navigator.of(context).pushNamedAndRemoveUntil(
        //     AceeptedBookings.routeName, (route) => false)
        //     :Navigator.of(context).pushNamedAndRemoveUntil(
        //     Service_engineer.routeName, (route) => false);
            Navigator.of(context).pushNamedAndRemoveUntil(
            HomeScreen.routeName, (route) => false)
            :Navigator.of(context).pushNamedAndRemoveUntil(
            WalkthroughScreen.routeName, (route) => false);
      }
      );
    });
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(image: AssetImage('assets/images/k2.png'),fit: BoxFit.cover),
        // gradient: LinearGradient(
        //   colors: <Color>[
        //     Color.fromARGB(255, 83, 217, 193),
        //     Color.fromARGB(255, 83, 217, 193),
        //   ],
        //   begin: Alignment.centerRight,
        //   end: Alignment.centerLeft,
        // ),
      ),
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              radius: 100,
              backgroundColor: Colors.black.withOpacity(0.7),
              child: CircleAvatar(
                backgroundColor: Color.fromARGB(100, 132, 132, 134),
                radius: 100,
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: Image.asset('assets/images/icon.png',height: 200,width: 200,)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top:15),
              child: Container(
                 height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 2,color: Colors.white,)),
            ),
          ]
      ),
    );
  }
}

