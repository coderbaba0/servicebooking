
import 'dart:convert';
import 'package:book_services/helper/global.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/models/All_category.dart';

Future<dynamic> Allcat() async {
  final response = await http.get(
    Uri.parse(baseUrl+'categories'),
  );
  var data = jsonDecode(response.body.toString());
  // print(data);
  if (response.statusCode == 200) {
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}