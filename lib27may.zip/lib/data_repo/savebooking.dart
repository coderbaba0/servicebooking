
import 'dart:convert';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';
Future<bool> savebooking(String userid,String serviceid,String hourneed,String issue,String customerhave,String bookingdate,String timeslot,String address, String conatctname,String Contactno,String serviceprice,String paymentid,) async {
  var url = Uri.parse(baseUrl + 'bookService');
  var body = {
    'user_id': userid,
    'service':serviceid,
    'serviceid':hourneed,
    'issues':issue,
    'last_name':customerhave,
    'date':bookingdate,
    'time':timeslot,
    'location_for':address,
    'first_name':conatctname,
    'mobile':Contactno,
    'price':serviceprice,
    'Invoice_no':paymentid,
    'location':"12",


  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
  // print(resBody);
  if (res.statusCode >= 200 && res.statusCode < 300) {
    // print(resBody);
    var data = json.decode(resBody);
    if (data['user_id'].toString() == userid) {
      Fluttertoast.showToast(
        msg: 'Service booked Sucessfully!',
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
      return true;

    } else {
      Fluttertoast.showToast(
        msg: 'Somthing error occurred',
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
return false;
    }
  } else {
    Fluttertoast.showToast(
      msg: "Something is wrong..",
      backgroundColor: Colors.black,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
    );
    return false;

  }
}