import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:book_services/Screens/services/bookings_step/stripepay.dart';
import 'package:book_services/Screens/services/bookings_step/sucess.dart';
import 'package:book_services/Screens/services/bookings_step/failed.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/showprogress.dart';
import 'package:book_services/data_repo/favorite.dart';
import 'package:book_services/data_repo/savebooking.dart';
import 'package:book_services/helper/global.dart';
import 'package:book_services/size_config.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_places_picker_refractored/google_maps_places_picker_refractored.dart';
import '../../../persisit/constantdata.dart';
List<String> list = <String>['Choose Category', 'Issue1', 'Issue2 ', 'Issue3'];
List<String> list2 = <String>[];

class FavServiceDetails extends StatefulWidget {
  static String routeName = "/favservicedetails";
  static const kInitialPosition = LatLng(-33.8567844, 151.213108);
  FavServiceDetails({Key? key, @required this.servicedata}) : super(key: key);
  final servicedata;
  @override
  State<FavServiceDetails> createState() => _FavServiceDetailsState();
}
class _FavServiceDetailsState extends State<FavServiceDetails>
    with TickerProviderStateMixin {
  Random random = new Random();

  //for customerhave
  String? codeDialog;
  String? valueText;
  final TextEditingController _textFieldController = TextEditingController();
  // for contact details
  final _formKey = GlobalKey<FormState>();
  TextEditingController mobilecontroller = TextEditingController();
  TextEditingController addresscontroller = TextEditingController();
  TextEditingController namecontroller = TextEditingController();
  // for choose payment method
  var _value = 1;
  var _select = 1;
  var _subtotal = 486, _vat = 5 / 100, _total = 0;
  // for location
  //for fav
  bool _isfav = true;
  void toggelefav() {
    setState(() {
      if (_isfav) {
        _isfav = false;
      } else {
        _isfav = true;
      }
    });
  }
  PickResult? selectedPlace;
  // for schedule
  int selectedIndex = 10;
  List<String> _time = [
    '12:00 AM-01:00AM',
    '01:00 AM-02:00AM',
    '02:00 AM-03:00AM',
    '03:00 AM-04:00AM',
    '04:00 AM-05:00AM',
    '05:00 AM-06:00AM',
    '06:00 AM-07:00AM',
    '07:00 AM-08:00AM',
    '08:00 AM-09:00AM',
    '09:00 AM-10:00AM',
    '10:00 AM-11:00AM',
    '11:00 AM-12:00PM',
    '12:00 PM-01:00PM',
    '01:00 PM-02:00PM',
    '02:00 PM-03:00PM',
    '03:00 PM-04:00PM',
    '04:00 PM-05:00PM',
    '05:00 PM-06:00PM',
    '06:00 PM-07:00PM',
    '07:00 PM-08:00PM',
    '08:00 PM-09:00PM',
    '09:00 PM-10:00PM',
    '10:00 PM-11:00PM',
    '11:00 PM-12:00PM'
  ];
  List<String> _time2 = [
    '12:00 PM-01:00PM',
    '01:00 PM-02:00PM',
    '02:00 PM-03:00PM',
    '03:00 PM-04:00PM',
    '04:00 PM-05:00PM',
    '05:00 PM-06:00PM',
    '06:00 PM-07:00PM',
    '07:00 PM-08:00PM',
    '08:00 PM-09:00PM',
    '09:00 PM-10:00PM',
    '10:00 PM-11:00PM',
    '11:00 PM-12:00PM'
  ];
  DateTime _selectedDate = DateTime.now();
  List<DateTime> _calendarDays = [];
  final List<String> daysOfWeek = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun'
  ];
  void initState() {
    super.initState();
    list2 = List<String>.from(json.decode(widget.servicedata['issues_values']));

    _calendarDays = _generateCalendar(_selectedDate.year, _selectedDate.month);
  }

  //genrate cal
  List<DateTime> _generateCalendar(int year, int month) {
    List<DateTime> daysInMonth = [];
    DateTime date = DateTime(year, month, 1);
    int firstWeekdayOfMonth = date.weekday;
    int daysBefore = (firstWeekdayOfMonth - 1) % 7;
    DateTime startDate = date.subtract(Duration(days: daysBefore));
    for (int i = 0; i < 42; i++) {
      daysInMonth.add(startDate.add(Duration(days: i)));
    }

    return daysInMonth;
  }

  // check month

//
  String dropdownValue = list.first;
  TabController? tabController2;
  var serviceprice = 0;
  var _counter = 1;
  void _increamentcounter() {
    setState(() {
      _counter++;
    });
  }
  void _decreamentcounter() {
    setState(() {
      if (_counter < 2) {
        return;
      }
      _counter--;
    });
  }

  int activeStep = 0;
  @override
  Widget build(BuildContext context) {
    TabController tabController = TabController(length: 2, vsync: this);
    serviceprice = (widget.servicedata['price_per_unit'] * _counter);
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 50,
        elevation: 2,
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          widget.servicedata['name'],
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: false,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(2)),
                Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: EasyStepper(
                            enableStepTapping: false,
                            showLoadingAnimation: true,
                            activeStepIconColor: kPrimaryColor,
                            lineColor: kPrimaryColor,
                            stepRadius: 20,
                            lineType: LineType.dotted,
                            activeStep: activeStep,
                            direction: Axis.horizontal,
                            activeStepTextColor: kPrimaryColor,
                            finishedStepTextColor: kPrimaryColor,
                            activeStepBorderColor: kPrimaryColor,
                            unreachedStepIconColor: Colors.white,
                            unreachedStepBorderColor: Colors.black54,
                            finishedStepBackgroundColor: kPrimaryColor,
                            unreachedStepBackgroundColor: Colors.black12,
                            showTitle: true,
                            onStepReached: (index) => setState(() {
                              activeStep = index;
                              tabController2 = tabController;
                            }),
                            steps: const [
                              EasyStep(
                                icon: Icon(Icons.remove_red_eye_outlined),
                                title: 'View',
                                activeIcon: Icon(Icons.done),
                              ),
                              EasyStep(
                                icon: Icon(Icons.calendar_month_outlined),
                                activeIcon: Icon(Icons.done),
                                title: 'Schedule',
                              ),
                              EasyStep(
                                icon: Icon(Icons.location_on),
                                activeIcon: Icon(Icons.done),
                                title: 'Location',
                              ),
                              EasyStep(
                                icon: Icon(Icons.checklist),
                                activeIcon: Icon(Icons.done),
                                title: 'Confirmation',
                              ),
                              EasyStep(
                                icon: Icon(Icons.money),
                                activeIcon: Icon(Icons.done),
                                title: 'Payment',
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: getProportionateScreenWidth(1)),
                _body(),
              ],
            ),
          ),
        ),
      ),
    );
  }
  _body() {
    if (activeStep == 1) {
      return Column(children: [
        Container(
          height: 20,
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  size: 20,
                  color: kPrimaryColor,
                ),
                onPressed: () {
                  setState(() {
                    _selectedDate = DateTime(
                        _selectedDate.year, _selectedDate.month - 1, 1);
                    _calendarDays = _generateCalendar(
                        _selectedDate.year, _selectedDate.month);
                  });
                },
              ),
              Text(
                (DateFormat('MMMM, yyyy').format(_selectedDate)),
                // '${_selectedDate.year} ${_selectedDate.month}',
                style: TextStyle(fontSize: 16),
              ),
              IconButton(
                icon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                  color: kPrimaryColor,
                ),
                onPressed: () {
                  setState(() {
                    _selectedDate = DateTime(
                        _selectedDate.year, _selectedDate.month + 1, 1);
                    _calendarDays = _generateCalendar(
                        _selectedDate.year, _selectedDate.month);
                  });
                },
              ),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 15),
          child: Row(
            children: daysOfWeek.map((day) {
              return Expanded(
                child: Container(
                  alignment: Alignment.center,
                  child: Text(
                    day,
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        GridView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            physics: ScrollPhysics(),
            padding: EdgeInsets.all(8),
            itemCount: _calendarDays.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
            ),
            itemBuilder: (context, index) {
              DateTime date = _calendarDays[index];
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedDate = date;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _selectedDate == date
                        ? kPrimaryColor
                        : kPrimaryColor.withOpacity(0.2),
                  ),
                  child: Center(
                    child: Text(
                      '${date.day}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: _selectedDate == date ? Colors.white : null,
                      ),
                    ),
                  ),
                ),
              );
            }),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            'Choose Time Slot:',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
          ),
        ),
        Divider(
          color: kPrimaryColor,
          thickness: 1,
          indent: 50,
          endIndent: 50,
        ),
        SizedBox(
          // Horizontal ListView
          height: 50,
          child: ListView.builder(
            itemCount: _time.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 2.0, right: 2.0),
                child: ChoiceChip(
                  selectedColor: kPrimaryColor,
                  backgroundColor: kPrimaryColor.withOpacity(0.2),
                  label: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(_time[index]),
                  ),
                  labelStyle: TextStyle(color: Colors.black),
                  selected: selectedIndex == index,
                  onSelected: (bool value) {
                    setState(() {
                      selectedIndex = index;
                    });
                  },
                ),
              );
            },
          ),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          // Horizontal ListView
          height: 50,
          child: ListView.builder(
            reverse: true,
            itemCount: _time.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 2.0, right: 2.0),
                child: ChoiceChip(
                  selectedColor: kPrimaryColor,
                  backgroundColor: kPrimaryColor.withOpacity(0.2),
                  label: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(_time[index]),
                  ),
                  labelStyle: TextStyle(color: Colors.black),
                  selected: selectedIndex == index,
                  onSelected: (bool value) {
                    setState(() {
                      selectedIndex = index;
                    });
                  },
                ),
              );
            },
          ),
        ),
        SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.black12.withOpacity(0.05)),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 18.0, right: 18, top: 5, bottom: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.white54
                    ),
                    child: IconButton(onPressed: (){
                      setState(() {
                        activeStep = activeStep - 1;
                      });
                    }, icon: Icon(Icons.arrow_back,color: kPrimaryColor,)),
                  ),
                  // Text(
                  //   "Price : AED " + serviceprice.toString(),
                  //   style: TextStyle(
                  //       fontSize: 16,
                  //       fontWeight: FontWeight.w600,
                  //       fontFamily: "Inter"),
                  // ),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: kPrimaryColor,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30))),
                      onPressed: () {
                        setState(() {
                          activeStep = activeStep + 1;
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          "Continue",
                          style: TextStyle(fontSize: 16),
                        ),
                      ))
                ],
              ),
            ),
          ),
        ),
      ]);
    } else if (activeStep == 2) {
      return Padding(
        padding: const EdgeInsets.only(left: 0.0, right: 0.0, bottom: 8),
        child: Column(
          children: [
            SizedBox(
              height: 1,
            ),
            Container(
              height: MediaQuery.of(context).size.height * 0.30,
              width: double.infinity,
              decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: kPrimaryColor,
                  )),
              child: PlacePicker(
                apiKey: 'AIzaSyAbN1uulBVvR6GkHkJUniPC9nkQ7yYcXAo',
                initialPosition: FavServiceDetails.kInitialPosition,
                useCurrentLocation: true,
                selectInitialPosition: true,
                height: 40.0,
                usePlaceDetailSearch: true,
                onPlacePicked: (result) {
                  selectedPlace = result;
                  addresscontroller.text =
                      selectedPlace!.formattedAddress.toString();
                },
                //forceSearchOnZoomChanged: true,
                automaticallyImplyAppBarLeading: false,
                //autocompleteLanguage: "ko",
                //region: 'au',
                //selectInitialPosition: true,
                // selectedPlaceWidgetBuilder: (_, selectedPlace, state, isSearchBarFocused) {
                //   print("state: $state, isSearchBarFocused: $isSearchBarFocused");
                //   return isSearchBarFocused
                //       ? Container()
                //       : FloatingCard(
                //           bottomPosition: 0.0, // MediaQuery.of(context) will cause rebuild. See MediaQuery document for the information.
                //           leftPosition: 0.0,
                //           rightPosition: 0.0,
                //           width: 500,
                //           borderRadius: BorderRadius.circular(12.0),
                //           child: state == SearchingState.Searching
                //               ? Center(child: CircularProgressIndicator())
                //               : RaisedButton(
                //                   child: Text("Pick Here"),
                //                   onPressed: () {
                //                     // IMPORTANT: You MUST manage selectedPlace data yourself as using this build will not invoke onPlacePicker as
                //                     //            this will override default 'Select here' Button.
                //                     print("do something with [selectedPlace] data");
                //                     Navigator.of(context).pop();
                //                   },
                //                 ),
                //         );
                // },
                // pinBuilder: (context, state) {
                //   if (state == PinState.Idle) {
                //     return Icon(Icons.favorite_border);
                //   } else {
                //     return Icon(Icons.favorite);
                //   }
                // },
              ),
            ),
            SizedBox(
              height: 0,
            ),
            Container(
              width: double.infinity,
              child: Card(
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 10, top: 10, bottom: 10),
                        child: Text(
                          "Address:",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w500),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Container(
                          width: double.infinity,
                          child: TextFormField(
                            controller: addresscontroller,
                            minLines: 2,
                            maxLines: 3,
                            onSaved: (newValue) => newValue!,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please, enter Address!';
                              } else {
                                return null;
                              }
                            },
                            cursorColor: kPrimaryColor,
                            decoration: InputDecoration(
                                contentPadding:
                                EdgeInsets.only(top: 10, left: 10),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: kPrimaryColor,
                                    )),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      width: 0.5,
                                    )),
                                hintText: "Enter your correct address..",
                                hintStyle: TextStyle(fontSize: 14),
                                border: OutlineInputBorder()),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 2,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 10, top: 10, bottom: 10),
                        child: Text(
                          "Contact Name:",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w500),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Container(
                          width: MediaQuery.of(context).size.width * 0.9,
                          child: TextFormField(
                            controller: namecontroller,
                            onSaved: (newValue) => newValue!,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please, enter name!';
                              } else {
                                return null;
                              }
                            },
                            cursorColor: kPrimaryColor,
                            decoration: InputDecoration(
                                contentPadding:
                                EdgeInsets.only(top: 10, left: 10),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: kPrimaryColor,
                                    )),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      width: 0.5,
                                    )),
                                hintText: "Enter your name..",
                                hintStyle: TextStyle(fontSize: 14),
                                border: OutlineInputBorder()),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 2,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 10, top: 10, bottom: 10),
                        child: Text(
                          "Contact No :",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w500),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Container(
                          width: double.infinity,
                          child: TextFormField(
                            controller: mobilecontroller,
                            onSaved: (newValue) => newValue!,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Please, enter mobile!';
                              } else if (value.length > 10) {
                                return 'Mobile number must be equal to 10 digit.';
                              } else {
                                return null;
                              }
                            },
                            keyboardType: TextInputType.phone,
                            cursorColor: kPrimaryColor,
                            decoration: InputDecoration(
                                contentPadding:
                                EdgeInsets.only(top: 10, left: 10),
                                focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: kPrimaryColor,
                                    )),
                                enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      width: 0.5,
                                    )),
                                hintText: "Enter Contact no..",
                                hintStyle: TextStyle(fontSize: 14),
                                border: OutlineInputBorder()),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 5, right: 5),
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.black12.withOpacity(0.05)),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                left: 18.0, right: 18, top: 5, bottom: 5),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(50),
                                      color: Colors.white54
                                  ),
                                  child: IconButton(onPressed: (){
                                    setState(() {
                                      activeStep = activeStep - 1;
                                    });
                                  }, icon: Icon(Icons.arrow_back,color: kPrimaryColor,)),
                                ),
                                // Text(
                                //   "Price : AED " + serviceprice.toString(),
                                //   style: TextStyle(
                                //       fontSize: 16,
                                //       fontWeight: FontWeight.w600,
                                //       fontFamily: "Inter"),
                                // ),
                                ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                        primary: kPrimaryColor,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                            BorderRadius.circular(30))),
                                    onPressed: () {
                                      if (_formKey.currentState!.validate()) {
                                        _formKey.currentState!.save();
                                        setState(() {
                                          activeStep = activeStep + 1;
                                        });
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Text(
                                        "Save",
                                        style: TextStyle(fontSize: 16),
                                      ),
                                    ))
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    } else if (activeStep == 3) {
      return Card(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Confirm your Details: ',
                      style:
                      TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            Text('Service Details: ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ListTile(
              leading: Image.network(imgUrl + widget.servicedata['image'],
                  height: 50, width: 50),
              title: Text(widget.servicedata['name']),
              subtitle: Text('AED ' + serviceprice.toString()),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            Text('Schedule Details : ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ListTile(
              title:
              Text(DateFormat('EEEE, MMM d, yyyy').format(_selectedDate)),
              subtitle: Text(_time.elementAt(selectedIndex)),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            Text('Address & contact details : ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ListTile(
              title: Text('Address & contact: '),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(addresscontroller.text),
                  Text(namecontroller.text),
                  Text(mobilecontroller.text)
                ],
              ),
              // trailing: TextButton.icon(
              //     label: Text('Edit'),
              //     style: TextButton.styleFrom(
              //       primary: kPrimaryColor,
              //     ),
              //     icon: Icon(Icons.edit),
              //     onPressed: () {
              //       setState(() {
              //         activeStep = activeStep - 1;
              //       });
              //     }),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(left: 15, right: 15, bottom: 30),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.black12.withOpacity(0.05)),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 18.0, right: 18, top: 5, bottom: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            color: Colors.white54
                        ),
                        child: IconButton(onPressed: (){
                          setState(() {
                            activeStep = activeStep - 1;
                          });
                        }, icon: Icon(Icons.arrow_back,color: kPrimaryColor,)),
                      ),
                      // Text(
                      //   "AED " + serviceprice.toString(),
                      //   style: TextStyle(
                      //       fontSize: 15,
                      //       fontWeight: FontWeight.w600,
                      //       fontFamily: "Inter"),
                      // ),
                      ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              primary: kPrimaryColor,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30))),
                          onPressed: () {
                            _showbottom();
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Text(
                              "Continue",
                              style: TextStyle(fontSize: 16),
                            ),
                          ))
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    } else if (activeStep == 4) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Choose payment Method : ',
                    style:
                    TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)),
                  child: RadioListTile(
                      title: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Pay with Google",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                      activeColor: kPrimaryColor,
                      value: 1,
                      groupValue: _value,
                      onChanged: (value) {
                        setState(() {
                          _value = value!;
                        });
                      }),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)),
                  child: RadioListTile(
                      title: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Pay with Stripe",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                      activeColor: kPrimaryColor,
                      value: 2,
                      groupValue: _value,
                      onChanged: (value) {
                        setState(() {
                          _value = value!;
                        });
                      }),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)),
                  child: RadioListTile(
                      title: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Pay on Cash",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                      activeColor: kPrimaryColor,
                      value: 3,
                      groupValue: _value,
                      onChanged: (value) {
                        setState(() {
                          _value = value!;
                        });
                      }),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)),
                  child: RadioListTile(
                      title: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Pay with Crypto",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                      activeColor: kPrimaryColor,
                      value: 4,
                      groupValue: _value,
                      onChanged: (value) {
                        setState(() {
                          _value = value!;
                        });
                      }),
                ),
              ),
              SizedBox(height: 20),

              Padding(
                padding: const EdgeInsets.only(left: 15, right: 15, bottom: 30),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black12.withOpacity(0.05)),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 18.0, right: 18, top: 5, bottom: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              color: Colors.white54
                          ),
                          child: IconButton(onPressed: (){
                            setState(() {
                              activeStep = activeStep - 1;
                            });
                          }, icon: Icon(Icons.arrow_back,color: kPrimaryColor,)),
                        ),
                        Text('AED: ' +
                            (serviceprice + (serviceprice * (5 / 100)))
                                .toDouble()
                                .toStringAsFixed(0),style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            fontFamily: "Inter"),),
                        ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: kPrimaryColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            onPressed: () {
                              savebooking(
                                  Constant.userId.toString(),
                                  widget.servicedata['name'].toString(),
                                  _counter.toString(),
                                  'issue1',
                                  'Noname',
                                  (DateFormat('EEEE, MMM d, yyyy').format(_selectedDate)).toString(),
                                  _time.elementAt(selectedIndex).toString(),
                                  addresscontroller.text,
                                  namecontroller.text,
                                  mobilecontroller.text,
                                  serviceprice.toString(),
                                  'Paymentid_123450').then((value) =>showDialog(
                                barrierDismissible: false,
                                context: context,
                                builder: (_) => value.toString()=='true'? Sucess() : Failed() ,)
                              );
                              if (_value == 2) {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => StripePay(
                                        title: widget.servicedata['name'],
                                        serviceprice: serviceprice,
                                      ),
                                    ));
                              }
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Text(
                                "Pay now",
                                style: TextStyle(fontSize: 16),
                              ),
                            ))
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      return Column(
        children: [
          Container(
            // width: MediaQuery.of(context).size.width * 0.9,
            // height: MediaQuery.of(context).size.height * 0.17,
              child: CarouselSlider(
                options: CarouselOptions(
                  viewportFraction: 1,
                  autoPlay: true,
                  height: SizeConfig.screenHeight * 1 / 5.0,
                ),
                items: [1, 2].map((i) {
                  return Builder(
                    builder: (BuildContext context) {
                      return Stack(children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.symmetric(horizontal: 5.0),
                          decoration: BoxDecoration(
                            border: Border.all(width: 1, color: kPrimaryColor),
                            borderRadius: BorderRadius.circular(5),
                            image: DecorationImage(
                              image: NetworkImage(
                                  imgUrl + widget.servicedata['image']),
                              fit: BoxFit.cover,
                            ),
                          ),
                          // child: Center(
                          //   child: Text(
                          //     'Image $i',
                          //   ),
                          // )
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(50),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Text(
                                  'Description : $i',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ]);
                    },
                  );
                }).toList(),
              )),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15.0),
                    child: Row(
                      children: [
                        Icon(Icons.star_half,color: Colors.orange,),
                        SizedBox(width: 5,),
                        Text('4.5  ('+(random.nextInt(90) + 50).toString()+')'),

                      ],
                    ),
                  ),


                ],
              ),

              Row(
                children: [
                  Text(
                    _isfav == false?'Add':'Remove ',
                    style: TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w400),
                  ),
                  IconButton(
                      onPressed: () {
                        toggelefav();
                        if (_isfav == true) {
                          addfavorite(Constant.userId.toString(),
                              widget.servicedata['id'].toString());
                        } else {
                          addfavorite(Constant.userId.toString(),
                              widget.servicedata['id'].toString());
                        }
                      },
                      icon: _isfav
                          ? Icon(
                        Icons.favorite,
                        color: Colors.orange,
                        size: 30,
                      )
                          : Icon(Icons.favorite_border,size: 28,)),
                ],
              ),
            ],
          ),

          Card(
            child: Padding(
              padding: const EdgeInsets.only(left:8.0,right: 8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ExpansionTile(
                    collapsedTextColor: kPrimaryColor,
                    collapsedIconColor: kPrimaryColor,
                    textColor: kPrimaryColor,
                    iconColor: kPrimaryColor,
                    childrenPadding: EdgeInsets.only(
                        left: 10, right: 10, top: 0, bottom: 10),
                    title: Text(
                      'Service Details',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                      ),
                    ),
                    // Contents
                    children: [
                      Text(widget.servicedata['description']),
                    ],
                  ),
                  Divider(
                    indent: 0,
                    endIndent: 0,
                    color: kPrimaryColor,
                    thickness: 0.8,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10, left: 15),
                    child: Text(
                      widget.servicedata['issues_title'],
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 10, right: 15, top: 15),
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.black12.withOpacity(0.03)),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        hint: Text("Choose issue"),
                        icon: Icon(
                          Icons.arrow_drop_down_sharp,
                          size: 30,
                        ),
                        onChanged: (String? newvalue) {
                          setState(() {
                            dropdownValue = newvalue!;
                            print(jsonDecode(
                                widget.servicedata['issues_values']));
                          });
                        },
                        value: dropdownValue,
                        items:
                        list.map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem(
                            value: value,
                            child: Padding(
                              padding:  EdgeInsets.only(left: 20),
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 14),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0, bottom: 10),
                    child: Text(
                      "Numbers of hours needed ?",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 10.0, right: 10.0, top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                                radius: 17,
                                backgroundColor: Colors.green,
                                child: Center(
                                  child: IconButton(
                                      onPressed: () {
                                        _decreamentcounter();
                                      },
                                      icon: Icon(
                                        Icons.remove,
                                        color: Colors.white,
                                        size: 17,
                                      )),
                                )),
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20),
                              child: Text(
                                "$_counter",
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                            CircleAvatar(
                              radius: 17,
                              backgroundColor: Colors.red,
                              child: Center(
                                child: IconButton(
                                    onPressed: () {
                                      _increamentcounter();
                                    },
                                    icon: Icon(
                                      Icons.add,
                                      size: 17,
                                      color: Colors.white,
                                    )),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 10.0, bottom: 20, top: 5),
                    child: Text(
                      widget.servicedata['customer_have'],
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            primary: kPrimaryColor),
                        onPressed: () {},
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            "Yes",
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)),
                              primary: Colors.white),
                          onPressed: () {
                            _displayTextInputDialog(context);
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text(
                              "No",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 5, right: 5),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.black12.withOpacity(0.05)),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 18.0, right: 18, top: 5, bottom: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              " AED " + serviceprice.toString(),
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: "Inter"),
                            ),
                            ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    primary: kPrimaryColor,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(30))),
                                onPressed: () {
                                  setState(() {
                                    activeStep = activeStep + 1;
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Text(
                                    "Book Now",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ))
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      );
    }
  }
  // for customer have page
  Future<void> _displayTextInputDialog(BuildContext context) async {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Please, mention your info',style: TextStyle(fontSize: 15),),
            content: TextField(
              minLines: 3,
              maxLines: 3,
              onChanged: (value) {
                setState(() {
                  valueText = value;
                });
              },
              controller: _textFieldController,
              decoration:
              const InputDecoration(hintText: "Write here"),
            ),
            actions: <Widget>[
              MaterialButton(
                color: Colors.red.withOpacity(0.5),
                textColor: Colors.white,
                child: const Text('CANCEL'),
                onPressed: () {
                  setState(() {
                    Navigator.pop(context);
                  });
                },
              ),
              MaterialButton(
                color: kPrimaryColor,
                textColor: Colors.white,
                child: const Text('Submit'),
                onPressed: () {
                  setState(() {
                    codeDialog = valueText;
                    Navigator.pop(context);
                  });
                },
              ),
            ],
          );
        });
  }


  Future _showbottom() {
    return showModalBottomSheet(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
        context: (context),
        builder: (BuildContext context) {
          return SizedBox(
            height: 300,
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20, left: 40),
                    child: Text(
                      "Order Summary",
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          fontFamily: "Inter"),
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Divider(
                    thickness: 1,
                    color: kPrimaryColor,
                    indent: 20,
                    endIndent: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Text(
                          "Subtotal",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "Inter"),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Text(
                          'AED: ' + serviceprice.toString(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 40, top: 10),
                        child: Text(
                          "VAT 5%",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "Inter"),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Text(
                          'AED: ' +
                              (serviceprice * (5 / 100))
                                  .toDouble()
                                  .toStringAsFixed(0),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Inter"),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Divider(
                    thickness: 1,
                    color: kPrimaryColor,
                    indent: 20,
                    endIndent: 20,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Text(
                          "TOTAL",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "Inter"),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Text(
                          'AED: ' +
                              (serviceprice + (serviceprice * (5 / 100)))
                                  .toDouble()
                                  .toStringAsFixed(0),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Inter"),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 40,
                  ),
                  Center(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(200, 40),
                        primary: kPrimaryColor,
                      ),
                      onPressed: () {
                        setState(() {
                          activeStep = activeStep + 1;
                        });
                        Navigator.pop(context);
                      },
                      child: Text(
                        "Checkout",
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

}
