import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final String? uid;

  DatabaseService({this.uid});

  // reference for our collections
  final CollectionReference userCollection =
  FirebaseFirestore.instance.collection("user");
  final CollectionReference bookingCollection =
  FirebaseFirestore.instance.collection("bookings");

  // saving the userdata
  Future savingUserData(String mobile, String uid) async {
    return await userCollection.doc(uid).set({
      "mobile": mobile,
      "uid": uid,
      "bookings": [],
    });
  }

  // getting user data
  Future gettingUserData(String mobile) async {
    QuerySnapshot snapshot =
    await userCollection.where("mobile", isEqualTo: mobile).get();
    return snapshot;
  }
  // get user bookings
  getUserbookings() async {
    return userCollection.doc(uid).snapshots();
  }

  // creating bookings
  Future createbookings(String mobile, String id, String servicename) async {
     await bookingCollection.doc(uid).set({
      "servicename": servicename,
      "admin": "${id}_$mobile",
      "users": [],
      "bookingId": "",
      "recentMessage": "",
      "recentMessageSender": "",
    });
    // update the users
    DocumentReference bookingDocumentReference =  bookingCollection.doc(uid);
    await bookingDocumentReference.update({
      "users": FieldValue.arrayUnion(["${uid}_$mobile"]),
      "bookingId": bookingDocumentReference.id,
    });
    DocumentReference userDocumentReference = userCollection.doc(id);
    return await userDocumentReference.update({
      "bookings":
      FieldValue.arrayUnion(["${bookingDocumentReference.id}_$servicename"])
    });
  }
  //booking delete
  deletebooking(String bookingId) async{
    bookingCollection.doc(bookingId).delete().then(
          (doc) => print("booking deleted"),
      onError: (e) => print("Error updating document $e"),
    );
  }
  // getting the chats
  getChats(String bookingid) async {
    return bookingCollection
        .doc(bookingid)
        .collection("messages")
        .orderBy("time")
        .snapshots();
  }
  // send message
  sendMessage(String bookingId, Map<String, dynamic> chatMessageData) async {
    bookingCollection.doc(bookingId).collection("messages").add(chatMessageData);
    bookingCollection.doc(bookingId).update({
      "recentMessage": chatMessageData['message'],
      "recentMessageSender": chatMessageData['sender'],
      "recentMessageTime": chatMessageData['time'].toString(),
    });
  }
}
