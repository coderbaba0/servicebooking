
import 'dart:convert';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

Future<dynamic>getfavlist(String userid) async {
  var uri = baseUrl + 'getfavourites/'+userid;
  final response = await http.get(Uri.parse(uri),);
  var data = jsonDecode(response.body.toString());
  if (response.statusCode == 200) {
    print('hum hai fav data $data');
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}
addfavorite(String userid,String serviceid) async {
  var url = Uri.parse(baseUrl + 'favourites');
  var body = {
    'user_id': userid,
    'service_id':serviceid
  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
  // print(resBody);
  if (res.statusCode >= 200 && res.statusCode < 300) {
    print(resBody);
    var data = json.decode(resBody);
    if (data['status'].toString() == 'success') {
      Fluttertoast.showToast(
        msg: data['message'],
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
    } else {
      Fluttertoast.showToast(
        msg:"Something is wrong..",
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );

    }
  } else {
    Fluttertoast.showToast(
      msg: "Something is wrong..",
      backgroundColor: Colors.black,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
    );
  }
}