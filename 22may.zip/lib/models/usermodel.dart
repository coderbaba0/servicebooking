class UserModel {
  String? _id;
  late String _name;
  late int _mobile;
  late String _email;
  late String _address;
  late String _photoUrl;

  //constructor for add
  UserModel(this._mobile, this._id);

  //Constructor for edit
  UserModel.withId(this._id, this._name, this._mobile, this._email,
      this._address, this._photoUrl);
  //getters
  String? get id => _id;
  String get Name => _name;
  int get mobile => _mobile;
  String get email => _email;
  String get address => _address;
  String get photoUrl => _photoUrl;

  //Setters
  set setame(String Name) {
    _name = Name;
  }

  set setPhone(int mobile) {
    _mobile = mobile;
  }

  set setEmail(String email) {
    _email = email;
  }

  set setaddress(String address) {
    _address = address;
  }

  set setPhotoUrl(String photoUrl) {
    _photoUrl = photoUrl;
  }
}
