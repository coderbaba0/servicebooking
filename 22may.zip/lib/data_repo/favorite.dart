
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

Future<dynamic>getfavlist(String userid) async {
  var uri = baseUrl + 'getfavourites/'+userid;
  final response = await http.get(Uri.parse(uri),);
  var data = jsonDecode(response.body.toString());
  if (response.statusCode == 200) {
    print('hum hai fav data $data');
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}