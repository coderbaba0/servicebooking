import 'package:book_services/Screens/chat/chat_widget/message_tile.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/persisit/constantdata.dart';
import 'package:book_services/utils/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';
import '../../constant/loader.dart';
class ChatScreen extends StatefulWidget {
  static String routeName = "/chat";
  const ChatScreen({Key? key}) : super(key: key);
  @override
  MyChatUIState createState() => MyChatUIState();
}
class MyChatUIState extends State<ChatScreen> {
  bool isLoading =false;
  Stream<QuerySnapshot>? chats;
  final ImagePicker _picker = ImagePicker();
  File? _selectedImage;
  String imageUrl = "";
  String? fileName;
  var controller = TextEditingController();
  ScrollController scrollController = ScrollController();
  var message = '';
  @override
  void initState() {
    getChat();
    scrollController.addListener(_scrollListener);
    super.initState();
  }
  getChat() {
    DatabaseService().getChats('6').then((val) {
      setState(() {
        chats = val;
      });
    });
  }
  _scrollListener() {
    if (scrollController.offset >=
        scrollController.position.maxScrollExtent &&
        !scrollController.position.outOfRange) {
      setState(() {
        // _limit += _limitIncrement;
      });
    }
  }
  Future<void> uploadImageFile(File image, String filename) async {
    final storageRef = FirebaseStorage.instance.ref();
    final reference = storageRef.child('chatsimage/$filename');
    UploadTask uploadTask = reference.putFile(image);
    try {
      TaskSnapshot snapshot = await uploadTask;
      imageUrl = await snapshot.ref.getDownloadURL();
      setState(() {
        isLoading = false;
        sendMessage(MessageType.image);
      });
    } on FirebaseException catch (e) {
      setState(() {
        isLoading = false;
      });
      //
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F5F3),
      appBar: AppBar(
        elevation: 2,
        titleSpacing: 2,
        backgroundColor: kPrimaryColor,
        automaticallyImplyLeading: true,
        leadingWidth: 30,
        iconTheme: IconThemeData(
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],
          color: Colors.white, //change your color here
        ),
        title: ListTile(
          leading: CircleAvatar(
            backgroundImage: NetworkImage('https://picsum.photos/400/400/'),
          ),
          title: const Text(
            'Kitchen Cleaning',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 16,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
          subtitle: const Text(
            'id :#85676525',
            style: TextStyle(color: Colors.white,fontSize: 12,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
        ),
        actions:  [

          InkWell(
            onTap: ()
            async{
              Uri phoneno = Uri.parse('tel:+97798345348734');
              Fluttertoast.showToast(
                msg: "Dialer is Opening..",
                backgroundColor: Colors.black,
                toastLength: Toast.LENGTH_LONG,
                gravity: ToastGravity.CENTER,
              );
              (await launchUrl(phoneno));
            },
            child: Padding(
              padding: EdgeInsets.only(right: 20),
              child: CircleAvatar(
                  backgroundColor: Colors.white54,
                  radius: 20,
                  child: Icon(Icons.dialer_sip_outlined,color: Colors.white,size: 20,)),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: Container(child: chatMessages(),)),
          Container(
            alignment: Alignment.center,
            color: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: (){
                      _optionsDialogBox();
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(bottom: 5.0, left: 8,right: 4),
                      child: Icon(
                        Icons.camera_alt,
                        color: kPrimaryColor,
                        size: 35,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: kPrimaryColor.withOpacity(0.2),
                          borderRadius: BorderRadius.all(Radius.circular(25))),
                      child: TextFormField(
                        maxLines: 6,
                        minLines: 1,
                        keyboardType: TextInputType.multiline,
                        controller: controller,
                        onFieldSubmitted: (value) {
                          controller.text = value;
                        },
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.only(left: 8),
                          border: InputBorder.none,
                          focusColor: Colors.white,
                          hintText: 'Type your issue..',
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12, right: 10),
                    child: Transform.rotate(
                      angle: 45,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      if(controller.text.isEmpty)
                        {
                          Fluttertoast.showToast(
                            msg: "Please type your issue!",
                            backgroundColor: Colors.black,
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                          );
                        }
                      else{
                        sendMessage(MessageType.text);
                      }
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(bottom: 5, right: 8),
                      child: CircleAvatar(
                        backgroundColor: kPrimaryColor,
                        child: Icon(
                          Icons.send,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
  // chat message view
  chatMessages() {
    return StreamBuilder(
      stream: chats,
      builder: (context, AsyncSnapshot snapshot) {
        return snapshot.hasData
            ? Column(
             children: [
             Expanded(
              child: ListView.builder(
                controller: scrollController,
                shrinkWrap: true,
                reverse: true,
                itemCount: snapshot.data.docs.length,
                itemBuilder: (context, index) {
                  final incomingDate2 =
                  DateTime.fromMillisecondsSinceEpoch(
                      int.parse(snapshot.data.docs[
                      snapshot.data.docs.length -
                          1 -
                          index]['time']),
                      isUtc: false)
                      .toIso8601String()
                      .toString();
                  final dateValue2 = DateTime.parse(incomingDate2);
                  final formatted2 = DateFormat('dd MMM HH:mm a')
                      .format(dateValue2.toLocal());
                  final formatted1 =
                  DateFormat('HH:mm a').format(dateValue2.toLocal());
                  bool isToday(DateTime dateValue2) {
                    final DateTime localDate = dateValue2.toLocal();
                    final now = DateTime.now();
                    final diff = now.difference(localDate).inDays;
                    return diff == 0 && now.day == localDate.day;
                  }
                  bool isyesterday(DateTime dateValue2) {
                    final DateTime localDate = dateValue2.toLocal();
                    final now = DateTime.now();
                    final diff = now.difference(localDate).inDays;
                    return  now.day-1 == localDate.day;
                  };
                  return MessageTile(
                    messagetype: snapshot.data
                        .docs[snapshot.data.docs.length - 1 - index]
                    ['messagetype'],
                    message: snapshot.data
                        .docs[snapshot.data.docs.length - 1 - index]
                    ['message'],
                    sender: snapshot.data
                        .docs[snapshot.data.docs.length - 1 - index]
                    ['sender'],
                    sentByMe:Constant.userId.toString() ==
                        snapshot.data.docs[snapshot.data.docs.length -
                            1 -
                            index]['sender'],
                    time: isToday(dateValue2) ? formatted1 : formatted2, );
                },
              ),
            ),
            isLoading
                ? Padding(
              padding: const EdgeInsets.only(right: 15.0,bottom: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: kPrimaryColor,
                      border: Border.all(color: Colors.transparent),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                        topLeft: Radius.circular(20),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 8,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left:15,right: 15,bottom: 15),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.white),
                              borderRadius: BorderRadius.all(Radius.circular(2)),
                            ),
                            child:Center(
                              child: ColorLoader2(),
                            ),
                            height: 180,
                            width: 180,
                          ),
                        ),
                      ],
                    ),

                  ),

                ],
              ),

            )
                : Container(),
          ],
        )
            : Container();
      },
    );
  }
  Future<void> _optionsDialogBox() {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Choose Source'),
          contentPadding: const EdgeInsets.all(20.0),
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                GestureDetector(
                  child: const Text("Take a Picture"),
                  onTap: openCamera,
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                ),
                const Divider(
                  color: Colors.white70,
                  height: 1.0,
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                ),
                GestureDetector(
                  child: const Text("Open Gallery"),
                  onTap: openGallery,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  Future openCamera() async {
    Navigator.of(context).pop();
    var imageFrmCamera = await _picker.getImage(source: ImageSource.camera);
    setState(() {
      _selectedImage = File(imageFrmCamera!.path);
      fileName = _selectedImage!.path.split('/').last;
      // print(fileName);
      if (_selectedImage != null) {
        setState(() {
          isLoading = true;
        });
        uploadImageFile(_selectedImage!,fileName!);
      }
    });
    //if (mounted) Navigator.of(context).pop();
  }
  //Gallery method
  Future openGallery() async {
    Navigator.of(context).pop();
    var pickedFile = await _picker.getImage(source: ImageSource.gallery);
    setState(() {
      _selectedImage = File(pickedFile!.path);
      fileName = _selectedImage!.path.split('/').last;
      // print(fileName);
      if (_selectedImage != null) {
        setState(() {
          isLoading = true;
        });
        uploadImageFile(_selectedImage!,fileName!);
      }

    });
    // if (mounted) Navigator.of(context).pop();
  }
  sendMessage(int type) {
    if (type == MessageType.text && controller.text.isNotEmpty) {
      Map<String, dynamic> chatMessageMap = {
        "message": controller.text,
        "sender": Constant.userId,
        "time": DateTime.now().millisecondsSinceEpoch.toString(),
        "messagetype": type,
      };
      DatabaseService().sendMessage('6', chatMessageMap);
      setState(() {
        controller.clear();
      });
    } else{
      Map<String, dynamic> chatMessageMap = {
        "message": imageUrl,
        "sender": Constant.userId,
        "time": DateTime.now().millisecondsSinceEpoch.toString(),
        "messagetype": type,
      };
      DatabaseService().sendMessage('6', chatMessageMap);
    }
  }
}

class MessageType {
  static const text = 0;
  static const image = 1;
}
