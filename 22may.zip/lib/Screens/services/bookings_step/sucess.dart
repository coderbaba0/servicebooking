
import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/constant/constui.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
class Sucess extends StatefulWidget {
  const Sucess({Key? key}) : super(key: key);
  @override
  State<Sucess> createState() => _SucessState();
}
class _SucessState extends State<Sucess> with SingleTickerProviderStateMixin{
  AnimationController? _animationController;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _animationController=AnimationController(vsync: this);
  }
  @override
  void dispose() {
    _animationController!.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white54,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(left:15.0,right:15,top:0,bottom:50),
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10)
              ),
              width:double.infinity,
              height:400,
              child: Column(
                children: [
                  SizedBox(height: 0,),
                  Lottie.asset('assets/images/95-success.json', controller: _animationController,repeat: true,height: 200,width: 200,
                    onLoaded: (com) {
                      // Configure the AnimationController with the duration of the
                      // Lottie file and start the animation.
                      _animationController!
                        ..duration = com.duration

                        ..forward();
                    },),

                  Text("Your Service Has been",style: TextStyle(fontSize: 20,fontFamily: "Inter",fontWeight: FontWeight.w500),),
                  SizedBox(height: 10,),
                  Text("Booked!",style: TextStyle(fontSize: 20,color: Colors.black,fontFamily: "Inter",fontWeight: FontWeight.w600),),
                  SizedBox(height: 20,),
                  Container(
                      height: 45,
                      decoration: BoxDecoration(

                      ),
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(primary: kPrimaryColor,side: BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                          onPressed: (){
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => HomeScreen(),
                                ));
                          }, child: Text("Back to Home",style: TextStyle(fontSize: 16,color: Colors.white),))),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
