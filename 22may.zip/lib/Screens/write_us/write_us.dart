import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
List<String> list = <String>['Choose Category', 'Related to Service', 'Related to Service Worker', 'Related to payment'];

class Suggestion extends StatefulWidget {
  static String routeName = "/suggestion";
  const Suggestion({Key? key}) : super(key: key);

  @override
  State<Suggestion> createState() => _SuggestionState();
}

class _SuggestionState extends State<Suggestion> {
  int _value=1;
  int myIndex=0;
  String dropdownValue = list.first;
  TextEditingController messagecontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.suggestions),
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        title: Text('Write Us',style: TextStyle(color: Colors.white,fontSize: 18,shadows: [
          Shadow(
            blurRadius: 1.0, // shadow blur
            color: Colors.black, // shadow color
            offset:
            Offset(0.5, 0.5), // how much shadow will be shown
          ),
        ],),),
        centerTitle: true,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
               _writeus(),
                SizedBox(height: getProportionateScreenWidth(8)),

              ],
            ),
          ),

        ),
      ),
    );
  }
  _writeus() {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.only(top: 30.0,left: 25,bottom: 20.0,right: 25),
          child: Column(
            children: [

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Radio(
                          activeColor: kPrimaryColor,
                          value: 1, groupValue: _value, onChanged: (value){
                        setState(() {
                          _value= value!;
                        });

                      }),
                      Text("Suggestion",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w300),),

                    ],
                  ),
                  Row(
                    children: [
                      Radio(
                          activeColor: kPrimaryColor,
                          value: 2, groupValue: _value, onChanged: (value){
                        setState(() {
                          _value= value!;
                        });
                      }),
                      Text("Complaints",style: TextStyle(fontSize: 15,color: Colors.black,fontWeight: FontWeight.w200),)

                    ],
                  ),
                ],
              ),
              SizedBox(height: 10,),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black,width: 1)
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton(
                    icon: Icon(Icons.arrow_drop_down_sharp,size: 30,),
                    onChanged: ( String? newvalue){
                      setState(() {
                        dropdownValue=newvalue!;
                      });
                    },
                    value: dropdownValue,
                    items: list.map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem(
                        value: value,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Text(value),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Text('Note: Please, Mention your Suggesions or any type of Complaints in the below box.',style: TextStyle(fontSize: 12,fontWeight: FontWeight.w200),),
              SizedBox(height: 20,),
              Container(
                width: double.infinity,
                child: TextField(
                  controller: messagecontroller,
                  minLines: 10,
                  maxLines: 10,
                  keyboardType: TextInputType.multiline,
                  style: TextStyle(color: Colors.black,fontSize: 16),
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.only(left: 15,top: 15),
                    hintText: "Message..",
                    hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: kPrimaryColor),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(color: Colors.red),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20,),
              Container(
                  height: 50,
                  width: double.infinity,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(primary: kPrimaryColor,side: BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                      onPressed: (){
                        if(messagecontroller.text.isEmpty){
                          Fluttertoast.showToast(
                            msg: "Please type your Message!",
                            backgroundColor: Colors.black,
                            toastLength: Toast.LENGTH_LONG,
                            gravity: ToastGravity.CENTER,
                          );
                        }
                        else{
                          // send data to admin
                        }
                      }, child: Text("Submit",style: TextStyle(fontSize: 18,color: Colors.white),))),
            SizedBox(height: 20,),
            ],
          ),
      ),
    )
    );
  }
}