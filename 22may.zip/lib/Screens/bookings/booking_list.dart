import 'package:book_services/Screens/bookings/booking_done.dart';
import 'package:book_services/Screens/bookings/order_details.dart';
import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/loader.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/persisit/constantdata.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';

import '../../data_repo/userbooking.dart';

class AllBookings extends StatefulWidget {
  static String routeName = "/allbooking";
  const AllBookings({Key? key}) : super(key: key);
  @override
  State<AllBookings> createState() => _AllBookingsState();
}

class _AllBookingsState extends State<AllBookings>
    with TickerProviderStateMixin {
  bool _isanybooking = true;
  @override
  Widget build(BuildContext context) {
    TabController tabController = TabController(length: 3, vsync: this);
    return Scaffold(
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.bookings),
      appBar: AppBar(
        elevation: 2,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ], //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          'Booking Summary',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _isanybooking
                    ? Card(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 2.0, right: 2.0),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                height: SizeConfig.screenHeight * 0.06,
                                decoration: BoxDecoration(
                                    color: kPrimaryColor.withOpacity(0.5),
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(50.0))),
                                child: TabBar(
                                  controller: tabController,
                                  indicatorColor: Colors.transparent,
                                  indicator: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                          50), // Creates border
                                      color: kPrimaryColor),
                                  tabs: [
                                    Tab(
                                      text: "Active",
                                    ),
                                    Tab(
                                      text: "Completed",
                                    ),
                                    Tab(
                                      text: "Cancelld",
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                height: MediaQuery.of(context).size.height*0.75,
                                child: TabBarView(
                                  physics: NeverScrollableScrollPhysics(),
                                  controller: tabController,
                                  children: [
                                    FutureBuilder<dynamic>(
                                        future: getbookingslist(
                                            '60'),
                                        builder: (context, snapshot) {
                                          if (snapshot.hasData) {
                                            if(snapshot.data.length!=0){
                                              return ListView.builder(
                                                  scrollDirection: Axis.vertical,
                                                  physics: BouncingScrollPhysics(),
                                                  shrinkWrap: true,
                                                  itemCount: snapshot.data.length,
                                                  itemBuilder:
                                                      (context, index) {
                                                    return InkWell(
                                                      onTap: () {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) =>
                                                                  OrderDetails(
                                                                    bookingdata: snapshot.data[index],
                                                                  ),
                                                            ));
                                                      },
                                                      child: Card(
                                                        child: Stack(
                                                          children: [
                                                            Padding(
                                                              padding: const EdgeInsets
                                                                  .only(
                                                                  left:
                                                                  10.0,
                                                                  right: 10,
                                                                  top: 20,
                                                                  bottom:
                                                                  20),
                                                              child: Column(
                                                                  crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                                  children: [
                                                                    Text(
                                                                      "Order Id:#"+ snapshot.data[index]['id'].toString(),
                                                                      style:
                                                                      TextStyle(
                                                                        fontSize:
                                                                        10,
                                                                      ),
                                                                    ),
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.spaceBetween,
                                                                      children: [
                                                                        Text(
                                                                          snapshot.data[index]['service'],
                                                                          style: TextStyle(fontSize: 15, fontFamily: "Inter", fontWeight: FontWeight.w800),
                                                                        ),
                                                                        Container(
                                                                          alignment: Alignment.center,
                                                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: Colors.orange.withOpacity(0.6)),
                                                                          child: Padding(
                                                                            padding: const EdgeInsets.all(8.0),
                                                                            child: Text(
                                                                              snapshot.data[index]['status'],
                                                                              style: TextStyle(fontSize: 13, fontFamily: "Inter", color: Colors.white, fontWeight: FontWeight.w500),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          'AED: '+snapshot.data[index]['price'],
                                                                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Text(
                                                                      snapshot.data[index]['created_at'].toString(),
                                                                      style: TextStyle(
                                                                          fontFamily: "Inter",
                                                                          fontSize: 12,
                                                                          fontWeight: FontWeight.w300),
                                                                    ),
                                                                    SizedBox(
                                                                      height:
                                                                      5,
                                                                    ),
                                                                    Divider(
                                                                      thickness:
                                                                      1,
                                                                      endIndent:
                                                                      2,
                                                                      indent:
                                                                      2,
                                                                      color:
                                                                      kPrimaryColor,
                                                                    ),
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment.spaceBetween,
                                                                      children: [
                                                                        Text(
                                                                          snapshot.data[index]['service_engineer'].toString()=='null'?'Not Assigned':snapshot.data[index]['service_engineer']['name']!.toString(),
                                                                          style: TextStyle(fontSize: 16, fontFamily: "Inter", fontWeight: FontWeight.w600),
                                                                        ),
                                                                        CircleAvatar(
                                                                          backgroundColor: kPrimaryColor.withOpacity(0.3),
                                                                          radius: 20,
                                                                          child: Icon(
                                                                            Icons.person_sharp,
                                                                            size: 30,
                                                                            color: Colors.white,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                  ]),
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                    );
                                                  });
                                            }
                                            else{
                                              return Center(
                                                child: _emptybookings(),
                                              );
                                            }

                                          }
                                          else {
                                            return Center(
                                              child:
                                                  ColorLoader2(),
                                            );
                                          }
                                        }),
                                    ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: 20,
                                        itemBuilder: (context, index) {
                                          return InkWell(
                                            onTap: () {
                                              Navigator.of(context)
                                                  .pushNamedAndRemoveUntil(
                                                      BookingDone
                                                          .routeName,
                                                      (route) => true);
                                            },
                                            child: Card(
                                              child: Stack(
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets
                                                                .only(
                                                            left: 10.0,
                                                            right: 10,
                                                            top: 20,
                                                            bottom: 20),
                                                    child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            "Order Id:#13453",
                                                            style:
                                                                TextStyle(
                                                              fontSize:
                                                                  10,
                                                            ),
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                "Carpenter",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        15,
                                                                    fontFamily:
                                                                        "Inter",
                                                                    fontWeight:
                                                                        FontWeight.w800),
                                                              ),
                                                              Container(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                decoration: BoxDecoration(
                                                                    borderRadius: BorderRadius.circular(
                                                                        20),
                                                                    color: Colors
                                                                        .green
                                                                        .withOpacity(0.6)),
                                                                child:
                                                                    Padding(
                                                                  padding:
                                                                      const EdgeInsets.all(8.0),
                                                                  child:
                                                                      Text(
                                                                    "Completed",
                                                                    style: TextStyle(
                                                                        fontSize: 13,
                                                                        fontFamily: "Inter",
                                                                        color: Colors.white,
                                                                        fontWeight: FontWeight.w500),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                "₹ 900",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        18,
                                                                    fontWeight:
                                                                        FontWeight.w800),
                                                              ),
                                                            ],
                                                          ),
                                                          Text(
                                                            "10 March,12:00PM",
                                                            style: TextStyle(
                                                                fontFamily:
                                                                    "Inter",
                                                                fontSize:
                                                                    12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300),
                                                          ),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          Divider(
                                                            thickness: 1,
                                                            endIndent: 2,
                                                            indent: 2,
                                                            color: Colors
                                                                .green
                                                                .withOpacity(
                                                                    0.6),
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                "Sumit Kumar",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16,
                                                                    fontFamily:
                                                                        "Inter",
                                                                    fontWeight:
                                                                        FontWeight.w600),
                                                              ),
                                                              CircleAvatar(
                                                                backgroundColor:
                                                                    kPrimaryColor
                                                                        .withOpacity(0.3),
                                                                radius:
                                                                    20,
                                                                child:
                                                                    Icon(
                                                                  Icons
                                                                      .person_sharp,
                                                                  size:
                                                                      30,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              )
                                                            ],
                                                          ),
                                                          Row(
                                                            children: const [
                                                              Text(
                                                                "Rate Now: ",
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style:
                                                                    TextStyle(
                                                                  fontSize:
                                                                      13,
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight:
                                                                      FontWeight.w300,
                                                                ),
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .star,
                                                                color: Colors
                                                                    .orange,
                                                                size: 15,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .star,
                                                                color: Colors
                                                                    .orange,
                                                                size: 15,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .star,
                                                                color: Colors
                                                                    .orange,
                                                                size: 15,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .star_half,
                                                                color: Colors
                                                                    .orange,
                                                                size: 15,
                                                              ),
                                                              Icon(
                                                                Icons
                                                                    .star,
                                                                color: Colors
                                                                    .grey,
                                                                size: 15,
                                                              ),
                                                            ],
                                                          ),
                                                        ]),
                                                  )
                                                ],
                                              ),
                                            ),
                                          );
                                        }),
                                    ListView.builder(
                                        shrinkWrap: true,
                                        itemCount: 20,
                                        itemBuilder: (context, index) {
                                          return InkWell(
                                            onTap: () {
                                              Navigator.of(context)
                                                  .pushNamedAndRemoveUntil(
                                                      OrderDetails
                                                          .routeName,
                                                      (route) => true);
                                            },
                                            child: Card(
                                              child: Stack(
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets
                                                                .only(
                                                            left: 10.0,
                                                            right: 10,
                                                            top: 20,
                                                            bottom: 20),
                                                    child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            "Order Id:#15453",
                                                            style:
                                                                TextStyle(
                                                              fontSize:
                                                                  10,
                                                            ),
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                "Electrician Work",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        15,
                                                                    fontFamily:
                                                                        "Inter",
                                                                    fontWeight:
                                                                        FontWeight.w800),
                                                              ),
                                                              InkWell(
                                                                onTap:
                                                                    () {},
                                                                child:
                                                                    Container(
                                                                  alignment:
                                                                      Alignment.center,
                                                                  decoration: BoxDecoration(
                                                                      borderRadius:
                                                                          BorderRadius.circular(20),
                                                                      color: Colors.red.withOpacity(0.4)),
                                                                  child:
                                                                      Padding(
                                                                    padding:
                                                                        const EdgeInsets.all(8.0),
                                                                    child:
                                                                        Text(
                                                                      "Book Now",
                                                                      style: TextStyle(
                                                                          fontSize: 13,
                                                                          fontFamily: "Inter",
                                                                          color: Colors.white,
                                                                          fontWeight: FontWeight.w500),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Text(
                                                                "₹ 800",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        18,
                                                                    fontWeight:
                                                                        FontWeight.w800),
                                                              ),
                                                            ],
                                                          ),
                                                          Text(
                                                            "10 March,12:00PM",
                                                            style: TextStyle(
                                                                fontFamily:
                                                                    "Inter",
                                                                fontSize:
                                                                    12,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300),
                                                          ),
                                                          SizedBox(
                                                            height: 5,
                                                          ),
                                                          Divider(
                                                            thickness: 1,
                                                            endIndent: 2,
                                                            indent: 2,
                                                            color: Colors
                                                                .red
                                                                .withOpacity(
                                                                    0.4),
                                                          ),
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                            children: [
                                                              Text(
                                                                "Rajesh kumar",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        16,
                                                                    fontFamily:
                                                                        "Inter",
                                                                    fontWeight:
                                                                        FontWeight.w600),
                                                              ),
                                                              CircleAvatar(
                                                                backgroundColor:
                                                                    kPrimaryColor
                                                                        .withOpacity(0.3),
                                                                radius:
                                                                    20,
                                                                child:
                                                                    Icon(
                                                                  Icons
                                                                      .person_sharp,
                                                                  size:
                                                                      30,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              )
                                                            ],
                                                          ),
                                                        ]),
                                                  )
                                                ],
                                              ),
                                            ),
                                          );
                                        }),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      )
                    : _emptybookings(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _emptybookings() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 150),
          child: Container(
              height: MediaQuery.of(context).size.width * 0.28,
              width: MediaQuery.of(context).size.width * 0.28,
              decoration: BoxDecoration(),
              child: Image.asset(
                "assets/images/cal.png",
                height: 50,
                width: 50,
              )),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Text(
            "Booking Status",
            style: TextStyle(
                fontSize: 20, fontFamily: "Inter", fontWeight: FontWeight.w500),
          ),
        ),
        Text(
          "You have not booked any \n service yet!",
          style: TextStyle(
              fontSize: 15, fontWeight: FontWeight.w100, fontFamily: "Inter"),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20),
          child: Container(
              height: 40,
              width: MediaQuery.of(context).size.width * 0.5,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: kPrimaryColor,
                      side: BorderSide(
                        color: Colors.white,
                        width: 2,
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15))),
                  onPressed: () {
                    Navigator.of(context)
                        .pushNamedAndRemoveUntil(HomeScreen.routeName, (route) => false);
                  },
                  child: Text(
                    "Book Now",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ))),
        )
      ],
    );
  }
}
