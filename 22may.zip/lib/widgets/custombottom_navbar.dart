import 'package:book_services/Screens/bookings/booking_list.dart';
import 'package:book_services/Screens/fav_product/favpro.dart';
import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/Screens/profile/profile.dart';
import 'package:book_services/Screens/write_us/write_us.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:flutter/material.dart';

class CustomBottomNavBar extends StatelessWidget {
  const CustomBottomNavBar({
    Key? key,
    required this.selectedMenu,
  }) : super(key: key);
  final MenuState selectedMenu;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, 5),
            blurRadius: 10,
            color: const Color(0xA8252527).withOpacity(1),
          ),
        ],
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(2),
          topRight: Radius.circular(2),
        ),
      ),
      child: SafeArea(
          top: false,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          HomeScreen.routeName, (route) => true);
                    },
                    child: CircleAvatar(
                      radius: 20,
                      backgroundColor: MenuState.home == selectedMenu
                          ? kPrimaryColor.withOpacity(0.2)
                          : Colors.transparent,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image.asset('assets/images/Home.png',height: 30,width: 30,),
                        )
                    ),
                  ),
                  Container(
                    child: MenuState.home == selectedMenu
                        ? const Visibility(
                      child: Text(
                        "Home",
                        style: TextStyle(color: kPrimaryColor,fontWeight: FontWeight.w500,fontSize: 12),
                      ),
                      visible: true,
                    )
                        : const Visibility(
                      child: Text("Home",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12)),
                      visible: true,
                    ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          FavPro.routeName, (route) => true);
                    },
                    child: CircleAvatar(
                        radius: 20,
                        backgroundColor: MenuState.favorites == selectedMenu
                            ? kPrimaryColor.withOpacity(0.2)
                            :Colors.transparent,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image.asset('assets/images/fav.png',height: 30,width: 30,),
                        )
                    ),
                  ),
                  Container(
                    child: MenuState.favorites == selectedMenu
                        ? const Visibility(
                      child: Text(
                        "Favorite",
                        style: TextStyle(color: kPrimaryColor,fontWeight: FontWeight.w500,fontSize: 12),
                      ),
                      visible: true,
                    )
                        : const Visibility(
                      child: Text("Favorite",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12)),
                      visible: true,
                    ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          AllBookings.routeName, (route) => true);
                    },
                    child: CircleAvatar(
                        radius: 20,
                        backgroundColor: MenuState.bookings == selectedMenu
                            ? kPrimaryColor.withOpacity(0.2)
                            : Colors.transparent,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image.asset('assets/images/order.png',height: 30,width: 30,),
                        )
                    ),
                  ),
                  Container(
                    child: MenuState.bookings == selectedMenu
                        ? const Visibility(
                      child: Text(
                        "Booking",
                        style: TextStyle(color: kPrimaryColor,fontWeight: FontWeight.w500,fontSize: 12),
                      ),
                      visible: true,
                    )
                        : const Visibility(
                      child: Text("Booking",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12)),
                      visible: true,
                    ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          Suggestion.routeName, (route) => true);
                    },
                    child: CircleAvatar(
                        radius: 20,
                        backgroundColor: MenuState.suggestions == selectedMenu
                            ? kPrimaryColor.withOpacity(0.2)
                            : Colors.transparent,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(15),
                          child: Image.asset('assets/images/Hint.png',height: 40,width: 30,),
                        )
                    ),
                  ),
                  Container(
                    child: MenuState.suggestions == selectedMenu
                        ? const Visibility(
                            child: Text(
                              "Write us",
                              style: TextStyle(color: kPrimaryColor,fontWeight: FontWeight.w500,fontSize: 12),
                            ),
                            visible: true,
                          )
                        : const Visibility(
                            child: Text("Write us",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12)),
                            visible: true,
                          ),
                  ),
                ],
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  InkWell(
                    onTap: (){
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          Profile.routeName, (route) => true);
                    },
                    child: CircleAvatar(
                        radius: 20,
                        backgroundColor: MenuState.profile == selectedMenu
                            ? kPrimaryColor.withOpacity(0.2)
                            : Colors.transparent,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(1),
                          child: Image.asset('assets/images/Customer.png',height: 20,width: 20,),
                        )
                    ),
                  ),
                  Container(
                    child: MenuState.profile == selectedMenu
                        ? const Visibility(
                      child: Text(
                        "Profile",
                        style: TextStyle(color: kPrimaryColor,fontWeight: FontWeight.w500,fontSize: 12),
                      ),
                      visible: true,
                    )
                        : const Visibility(
                      child: Text("Profile",style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,fontSize: 12),),
                      visible: true,
                    ),
                  ),
                ],
              ),
            ],
          )),
    );
  }
}
