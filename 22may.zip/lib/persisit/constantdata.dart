
 class Constant{
  static String usermobile = "";
  static String useremail = "";
  static String username = "";
 static String userId = "";
}