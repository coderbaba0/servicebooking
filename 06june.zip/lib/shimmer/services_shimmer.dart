import 'package:flutter/material.dart';

import '../size_config.dart';
import 'for_shimmer.dart';

class Skeleton extends StatelessWidget {
  const Skeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 8.0, left: 0.0),
          child: SizedBox(
            width: SizeConfig.screenWidth * 0.48,
            height: SizeConfig.screenHeight * 0.27,
            child: Card(
              elevation: 0,
              child: Column(
                children: [
                  Expanded(
                      child: Container(
                          decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(5),
                                  topRight: Radius.circular(5))))),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 8.0, bottom: 10.0, right: 8.0, top: 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: SizeConfig.screenWidth * 0.80,
                            height: SizeConfig.screenHeight * 0.17,
                            // color:Colors.orange.shade100,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.04),
                              borderRadius: BorderRadius.all(
                                  Radius.circular(5)),
                            ),
                          ),
                          SizedBox(height: 5),
                          Padding(
                              padding: EdgeInsets.only(top: 8.0),
                              child: Container(
                                width: 100,
                                height: 20,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.04),
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(defaultPadding)),
                                ),
                              )),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Container(
                                height: 15,
                                width: 50,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.04),
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(defaultPadding)),
                                ),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class CircleSkeleton extends StatelessWidget {
  const CircleSkeleton({Key? key, this.size = 50}) : super(key: key);

  final double? size;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          backgroundColor: Colors.white,
          radius: 30,
          child: Container(
            height: size,
            width: size,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.04),
              shape: BoxShape.circle,
            ),
          ),
        ),
        // const SizedBox(height: 2),
        // Container(
        //   height: 2,
        //   width: 40,
        //   decoration: BoxDecoration(
        //     color: Colors.black.withOpacity(0.04),
        //     borderRadius: BorderRadius.circular(5.0),
        //   ),
        // )
      ],
    );
  }
}

class other extends StatelessWidget {
  const other({Key? key, this.height, this.width}) : super(key: key);

  final double? height, width;

  @override
  Widget build(BuildContext context) {
    return
      Card(
        elevation: 2,
        child: Column(
          children: [
            Expanded(
                child: Container(
                    decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.04),
                        borderRadius: const BorderRadius
                            .only(
                            topLeft: Radius.circular(5),
                            topRight:
                            Radius.circular(5))))),
            Align(
              alignment: Alignment.bottomLeft,
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 8.0,
                    right: 8.0,
                    bottom: 10.0,
                    top: 5),
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 5),
                    Padding(
                        padding: EdgeInsets.only(top: 8.0),
                        child: Container(
                          width: 100,
                          height: 20,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.04),
                            borderRadius: BorderRadius.all(
                                Radius.circular(defaultPadding)),
                          ),
                        )),
                    SizedBox(height: 5),
                    Row(
                      children: [
                        Container(
                          height: 15,
                          width: 50,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.04),
                            borderRadius: BorderRadius.all(
                                Radius.circular(defaultPadding)),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
  }
}
