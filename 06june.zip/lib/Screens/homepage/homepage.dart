import 'dart:convert';
import 'dart:io';

import 'package:book_services/Screens/homepage/component/body.dart';
import 'package:book_services/Screens/homepage/component/notifications.dart';
import 'package:book_services/Screens/homepage/component/search.dart';
import 'package:book_services/Screens/profile/profile.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:book_services/utils/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../notifications.dart';
import '../../persisit/constantdata.dart';

class HomeScreen extends StatefulWidget {
  static String routeName = "/home";
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  NotificationServices notificationServices = NotificationServices();
  Stream<AggregateQuerySnapshot>? notificationcount;
  int _totalNotifications=0;
  String ?title;
  String ?body;
  String? time;
@override
void initState() {
   getnotificationcount();
  notificationServices.requestNotificationPermission();
  notificationServices.firebaseInit(context);
  notificationServices.setupInteractMessage(context);
  notificationServices.isTokenRefresh();
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    // print('Got a message whilst in the foreground!');
    // print('Message data: ${message.data}');
    // if(message.data['id']=='71'){
    //   print('Message also contained a data: ${message.data['id']}');
    // }
    if (message.notification != null) {
      // print('Message also contained a notification: ${message.notification!.title}');
      // print('Message also contained a data: ${message.data['servicename']}');
      //save to sf
      // DatabaseService(uid: Constant.userId).saveNotifications(message.notification!.body.toString(),message.sentTime!.toString(),message.data['servicename'],message.data['id'].toString(),).then((value) => debugPrint('saved'));
      // Map<String, dynamic> newMessage = {"title":  message.notification!.body, "body": message.sentTime!.toString(),"id":message.data['id'],'service':message.data['servicename']};
      // Constant.messagesForUI.add(newMessage);
      // String newMessageJson = json.encode(newMessage);
      // // print(newMessageJson);
      // Constant.sharedPreferenceMessages.add(newMessageJson);
      // Constant.sharedPreference!.setStringList("messages", Constant.sharedPreferenceMessages);
      //

// setState(() {
//   _totalNotifications++;
//
// });
    }

  });
  super.initState();
  }
  getnotificationcount() {
    DatabaseService().getNotificationscount(Constant.userId.toString()).then((val) {
      setState(() {
        _totalNotifications = val.count;
        // print('_totalNotifications');
      });
    });
  }
   @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(90.0),
        child: AppBar(
          automaticallyImplyLeading: false,
          elevation: 2,
          backgroundColor: kPrimaryColor,
          toolbarHeight: SizeConfig.screenHeight * 0.2,
          centerTitle: false,
          title: Padding(
            padding: const EdgeInsets.only(top: 25.0,left: 0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 40, left: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: CircleAvatar(
                          radius: 20,
                          backgroundImage:
                              ExactAssetImage('assets/images/icon.png'),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 40,
                           // width: MediaQuery.of(context).size.width/1.48,
                          decoration: BoxDecoration(
                            // ignore: prefer_const_constructors
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: TextFormField(
                            //
                            textAlignVertical: TextAlignVertical.center,
                            style: TextStyle(
                                fontSize: 14.0,
                                height: 1.0,
                                color: Colors.white),
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const SearchScreen()));
                            },
                            cursorColor: Colors.white,
                            cursorHeight: 15,
                            keyboardType: TextInputType.text,
                            showCursor: true,
                            // onSaved:,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Enter Query";
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              prefix: Padding(
                                padding: EdgeInsets.only(
                                  top: 30,
                                ),
                              ),
                              prefixIcon: Padding(
                                padding: const EdgeInsets.only(left: 0.0),
                                child: Icon(
                                  Icons.do_not_disturb_on_total_silence_sharp,
                                  color: Colors.transparent,
                                ),
                              ),
                              prefixIconConstraints:
                                  BoxConstraints(maxWidth: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide(color: Colors.white38),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide.none,
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide(color: Colors.white),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide(color: Colors.red),
                              ),
                              labelStyle: const TextStyle(
                                color: kPrimaryColor,
                              ),
                              focusColor: kTextColorSecondary.withOpacity(0.2),
                              hintText: "Search Services..",
                              fillColor: Colors.white54.withOpacity(0.3),
                              filled: true,
                              suffixIcon: const Icon(
                                Icons.camera_alt_outlined,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),

                      Badge(
                        isLabelVisible: true,
                        largeSize: 15,
                        alignment: Alignment.topRight,
                        backgroundColor: _totalNotifications==0?Colors.transparent:Colors.red,
                        label: Text(_totalNotifications.toString(),style: TextStyle(color: _totalNotifications==0?Colors.transparent:Colors.white),),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0,bottom: 7.0),
                          child: IconButton(
                            visualDensity:  VisualDensity(
                                      horizontal: -4.0, vertical: -4.0),
                            onPressed: () {
                              // setState(() {
                              //   _totalNotifications=0;
                              // });
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => Notifications(title: title,body: body,time: time,),
                                  ));
                            },
                            icon: Icon(Icons.notifications_active_outlined,color: Colors.white,size: 30,weight: 5,),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Profile(),
                        ));
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(40, 0, 0, 50),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.person,
                          color: Colors.white,
                          size: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: Text(
                            Constant.username.isEmpty
                                ? 'Hello, Guest'
                                : 'Hi , ' + Constant.username.toString().toUpperCase(),
                            // box!.get("Address"),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 14),
                          ),
                        ),
                            Icon(Icons.arrow_drop_down),
                        // Text(
                        //   'Edit',
                        //   // box!.get("Address"),
                        //   overflow: TextOverflow.ellipsis,
                        //   maxLines: 1,
                        //   style: const TextStyle(color: Colors
                        //       .black54, fontSize: 14),
                        // ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: const Body(),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.transparent,
        splashColor: Colors.transparent,
        focusColor: Colors.transparent,
        child: Center(
          child: Column(
            children: [
              CircleAvatar(
                  radius: 25,
                  backgroundColor: kPrimaryColor.withOpacity(0.4),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      'assets/images/WhatsApp.png',
                      height: 40,
                      width: 40,
                    ),
                  )),
              // Text('Send',style: TextStyle(color: Colors.green,fontSize: 15,fontWeight: FontWeight.w500),)
            ],
          ),
        ),
        elevation: 0,
        onPressed: () {
          openWhatsapp(context: context, number: '+971507832292');
        },
        tooltip: 'Send',
      ),
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.home),
    );
  }
  void openWhatsapp (
      {required BuildContext context,
        // required String text,
        required String number}) async {
    var whatsapp = number; //+91xx enter like this
    var whatsappURlAndroid =
        "whatsapp://send?phone=" + whatsapp ;
    // + "&text=$text";
    // var whatsappURLIos = "https://wa.me/$whatsapp?text=${Uri.tryParse(text)}";
    if (Platform.isAndroid) {
      // for android phone only
      if (await canLaunchUrl(Uri.parse(whatsappURlAndroid))) {
        await launchUrl(Uri.parse(
          whatsappURlAndroid,
        ));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Whatsapp not installed")));
      }
    }

  }
}
