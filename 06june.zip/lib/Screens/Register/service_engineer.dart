import 'dart:convert';
import 'package:book_services/constant/showprogress.dart';
import 'package:book_services/persisit/helperfunctions.dart';
import 'package:book_services/utils/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/helper/global.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../constant/constui.dart';
import '../../constant/loader.dart';
import '../../data_repo/senftoken.dart';
import '../../persisit/constantdata.dart';
import '../../size_config.dart';
import '../bookings/accepted_booking.dart';
import 'RegisterScreen.dart';

class Service_engineer extends StatefulWidget {
  static String routeName = "/serviceengineer";
  const Service_engineer({Key? key}) : super(key: key);
  @override
  State<Service_engineer> createState() => _Service_engineerState();
}

class _Service_engineerState extends State<Service_engineer>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  bool isloading =false;
  String? engineerid;
  String ?pass;
  final _formKey = GlobalKey<FormState>();
  TextEditingController mobilecontroller = TextEditingController();
  TextEditingController namecontroller = TextEditingController();
  String? mtoken = " ";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getDeviceToken();
    _animationController = AnimationController(vsync: this);
  }
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  //get device token
  Future<void> getDeviceToken() async {
    await FirebaseMessaging.instance.getToken().then((token) {
      setState(() {
        mtoken = token;
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[
              Color.fromARGB(255, 83, 217, 193),
              Color(0xae089d82),
            ],
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(
                10, MediaQuery.of(context).size.height * 0.1, 20, 0),
            child: Column(
              children: [
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.start,
                //   children: [
                //     IconButton(
                //       icon: Icon(
                //         Icons.arrow_back,
                //         size: 30,
                //         color: Colors.white,
                //       ),
                //       onPressed: () {
                //         Navigator.pop(context);
                //       },
                //     ),
                //   ],
                // ),
                SizedBox(
                  height: 20,
                ),
                Lottie.asset(
                  "assets/images/ser_eng.json",
                  controller: _animationController,
                  height: 200,
                  onLoaded: (com) {
                    // Configure the AnimationController with the duration of the
                    // Lottie file and start the animation.
                    _animationController
                      ..duration = com.duration
                      ..forward();
                  },
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 50,top: 15),
                  child: Text(
                    "Please enter Login credentials!",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w400,
                        color: Colors.white),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                Form(
                  key: _formKey,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 15.0, right: 15),
                    child: Column(
                      children: [

                        TextFormField(
                          onSaved: (newValue) => engineerid = newValue!,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, enter User id!';
                            } else {
                              return null;
                            }
                          },
                          style: TextStyle(color: Colors.white),
                          cursorColor: Colors.white,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white60),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            labelStyle: const TextStyle(color: kPrimaryColor),
                            focusColor: kTextColorSecondary.withOpacity(0.2),
                            hintText: "Enter User id",
                            hintStyle: TextStyle(color: Colors.white),
                            fillColor: Colors.white,
                            filled: false,

                          ),
                          controller: mobilecontroller,
                          keyboardType: TextInputType.text,
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          obscureText: true,
                          enableSuggestions: false,
                          autocorrect: false,
                          onSaved: (newValue) => pass = newValue!,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, enter Your Password!';
                            }  else {
                              return null;
                            }
                          },
                          style: TextStyle(color: Colors.white),
                          cursorColor: Colors.white,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white60),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            labelStyle: const TextStyle(color: kPrimaryColor),
                            focusColor: kTextColorSecondary.withOpacity(0.2),
                            hintText: "Enter Your Password",
                            hintStyle: TextStyle(color: Colors.white),
                            fillColor: Colors.white,
                            filled: false,
                          ),
                          controller: namecontroller,
                          keyboardType: TextInputType.text,
                        ),

                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 50,
                  width: double.infinity,
                  margin: EdgeInsets.only(
                    left: 20,
                    right: 20,
                  ),
                  // decoration: BoxDecoration(
                  //   borderRadius: BorderRadius.circular(10),
                  //
                  // ),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white24,
                        side: BorderSide(
                          color: Colors.white,
                          width: 2,
                        ),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20))),
                    onPressed: () async{
                      setState(() {
                        isloading = true;
                      });

                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        service_engineer(engineerid!,pass!).then((value) => setState(() {
                          isloading = false;
                        }));
                      }
                    },
                    child: Text(
                      "Login",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                isloading?
                Container(width:40,height:40,child: ColorLoader2()):Container(),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );

  }
  Future service_engineer(String email,String pass) async {
    var url = Uri.parse(baseUrl + 'service_engineer_login');
    var body = {
      'email': email,
      'password': pass,
    };
    var headerList = {
      "Content-Type": "application/json",
      "accept": "application/json",
      "Access-Control-Allow-Origin": "*"
    };
    var req = http.MultipartRequest('POST', url);
    req.headers.addAll(headerList);
    req.fields.addAll(body);
    var res = await req.send();
    final resBody = await res.stream.bytesToString();
    print(resBody);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      print(resBody);
      var data = json.decode(resBody);
      if (data['status'] == 'success') {
        print(data['message']);
        var actualdata = data['data'];
        var userid = actualdata['id'];
        var usermobile = actualdata['phone'];
        var username = actualdata['name'];
        var useremail = actualdata['email'];

        setState(() {
          Constant.userId = userid.toString();
          Constant.usermobile = usermobile;
          Constant.username = username;
          Constant.useremail = useremail;
        }
        );
        await HelperFunctions.saveUserLoggedInStatus(true);
        await HelperFunctions.saveUserIdSF(userid.toString());
        await HelperFunctions.saveuserMobileSF(usermobile.toString());
        await HelperFunctions.saveUserNameSF(username.toString());
        // await HelperFunctions.saveUserEmailSF(useremail);

        Fluttertoast.showToast(
          msg: data['message'],
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );
        await DatabaseService(uid: Constant.userId)
            .savingUserData(usermobile, userid.toString());
        sendtoken(Constant.userId,mtoken);
        Navigator.of(context).pushNamedAndRemoveUntil(
            AceeptedBookings.routeName, (route) => false);
      } else {
        setState(() {
          isloading = false;
        });
        Fluttertoast.showToast(
          msg: data['message'],
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );

      }
    } else {
      setState(() {
        isloading = false;
      });
      Fluttertoast.showToast(
        msg: "Something is wrong..",
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
    }
  }
}
