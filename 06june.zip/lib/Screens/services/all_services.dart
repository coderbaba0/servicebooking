import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/loader.dart';
import 'package:book_services/helper/global.dart';
import 'package:book_services/size_config.dart';
import 'package:flutter/material.dart';
import '../../data_repo/serviceprovider.dart';
import '../../data_repo/services_by_rating.dart';
import '../../shimmer/services_shimmer.dart';
import 'bookings_step/service_details.dart';

class AllServices extends StatefulWidget {
  static String routeName = "/all";
  var title;
  var id;
  AllServices({Key? key, @required this.title, @required this.id})
      : super(key: key);
  @override
  State<AllServices> createState() => _AllServicesState();
}

class _AllServicesState extends State<AllServices> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          widget.title,
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(10)),
                // Column(
                //   children: [
                //     Padding(
                //       padding: const EdgeInsets.only(left: 5.0),
                //       child: Row(
                //         children: [
                //           Container(
                //             height: SizeConfig.screenHeight * 0.05,
                //             width: SizeConfig.screenWidth * 0.8,
                //             child: TextFormField(
                //               style: TextStyle(
                //                   fontSize: 13.0,
                //                   height: 1.0,
                //                   color: Colors.black54),
                //               onTap: () {},
                //               cursorColor: kPrimaryColor,
                //               cursorHeight: 16,
                //               keyboardType: TextInputType.text,
                //               showCursor: true,
                //               // onSaved:,
                //               validator: (value) {
                //                 if (value!.isEmpty) {
                //                   return "Enter Query";
                //                 }
                //                 return null;
                //               },
                //               decoration: InputDecoration(
                //                 contentPadding: EdgeInsets.all(10),
                //                 prefixIcon: Icon(
                //                   Icons.search,
                //                   color: kPrimaryColor,
                //                 ),
                //                 isDense: true,
                //                 enabledBorder: OutlineInputBorder(
                //                   borderRadius: BorderRadius.circular(12.0),
                //                   borderSide: BorderSide(color: Colors.black),
                //                 ),
                //                 disabledBorder: OutlineInputBorder(
                //                   borderRadius: BorderRadius.circular(12.0),
                //                   borderSide: BorderSide.none,
                //                 ),
                //                 focusedBorder: OutlineInputBorder(
                //                   borderRadius: BorderRadius.circular(12.0),
                //                   borderSide: BorderSide(color: kPrimaryColor),
                //                 ),
                //                 errorBorder: OutlineInputBorder(
                //                   borderRadius: BorderRadius.circular(12.0),
                //                   borderSide: BorderSide(color: Colors.red),
                //                 ),
                //                 labelStyle: const TextStyle(
                //                   color: kPrimaryColor,
                //                 ),
                //                 focusColor:
                //                     kTextColorSecondary.withOpacity(0.2),
                //                 hintText: "Search Services..",
                //                 fillColor: Colors.white54.withOpacity(0.3),
                //                 filled: true,
                //                 suffixIcon: const Icon(
                //                   Icons.camera_alt_outlined,
                //                   color: Colors.white,
                //                 ),
                //               ),
                //             ),
                //           ),
                //           Center(
                //             child: IconButton(
                //                 onPressed: () {},
                //                 icon: Icon(
                //                   Icons.filter_alt_off_sharp,
                //                   size: 25,
                //                   color: Colors.black87,
                //                 )),
                //           )
                //         ],
                //       ),
                //     ),
                //   ],
                // ),
                // SizedBox(height: getProportionateScreenWidth(8)),
                _allserv(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _allserv() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
            child: FutureBuilder<dynamic>(
                future: getbestservices(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.75,
                      ),
                      itemCount: snapshot.data.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(3, 5, 3, 5),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ServiceDetails(
                                      servicedata: snapshot.data[index],
                                    ),
                                  ));
                            },
                            child: SizedBox(
                              width: SizeConfig.screenWidth / 2.5,
                              height: SizeConfig.screenWidth / 3.5,
                              child: Card(
                                elevation: 2,
                                child: Column(
                                  children: [
                                    Expanded(
                                        child: Container(
                                            decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  image: NetworkImage(imgUrl +
                                                      snapshot.data[index]
                                                          ['image']),
                                                  fit: BoxFit.cover,
                                                ),
                                                borderRadius: const BorderRadius
                                                        .only(
                                                    topLeft: Radius.circular(5),
                                                    topRight:
                                                        Radius.circular(5))))),
                                    Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 8.0,
                                            right: 8.0,
                                            bottom: 10.0,
                                            top: 0),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              snapshot.data[index]['name'],
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            const SizedBox(height: 3),
                                            Row(
                                              children: [
                                                Icon(
                                                  Icons.star,
                                                  color: Colors.orange,
                                                  size: 15,
                                                ),
                                                Icon(
                                                  Icons.star,
                                                  color: Colors.orange,
                                                  size: 15,
                                                ),
                                                Icon(
                                                  Icons.star,
                                                  color: Colors.orange,
                                                  size: 15,
                                                ),
                                                Icon(
                                                  Icons.star_half,
                                                  color: Colors.orange,
                                                  size: 15,
                                                ),
                                                Text(
                                                  snapshot.data[index]
                                                              ['rating_average']
                                                          .toString() +
                                                      ' ( ' +
                                                      snapshot.data[index]
                                                              ['rating_users']
                                                          .toString() +
                                                      ' ) ',
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    color: Colors.orange,
                                                    fontWeight: FontWeight.w300,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 3),
                                            // Row(
                                            //   children: [
                                            //     Text(
                                            //       "Now at : ",
                                            //       textAlign: TextAlign.center,
                                            //       style: TextStyle(
                                            //           fontSize: 12,
                                            //           color: Colors.black87,
                                            //           fontWeight:
                                            //               FontWeight.bold),
                                            //     ),
                                            //     Text(
                                            //       "AED " +
                                            //           snapshot.data[index]
                                            //                   ['price_per_unit']
                                            //               .toString(),
                                            //       textAlign: TextAlign.center,
                                            //       style: TextStyle(
                                            //           fontSize: 12,
                                            //           color: Colors.orange,
                                            //           fontWeight:
                                            //               FontWeight.bold),
                                            //     ),
                                            //   ],
                                            // ),
                                            const SizedBox(height: 8),
                                            Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      border: Border.all(
                                                          color:
                                                              Colors.black45),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              5)),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            6.0),
                                                    child: const Text(
                                                      "Book Now",
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(width: 1),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  } else {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.75,
                          ),
                          itemCount: 4,
                          itemBuilder: (BuildContext context, int index) {
                            return Padding(
                              padding: const EdgeInsets.fromLTRB(3, 5, 3, 5),
                              child: SizedBox(
                                width: SizeConfig.screenWidth / 2.5,
                                height: SizeConfig.screenWidth / 3.5,
                                child: other(),
                              ),
                            );
                          },
                        ),
                        Center(
                            child: Container(
                                height: 30, width: 30, child: ColorLoader2())),
                      ],
                    );
                  }
                })),
      ],
    );
  }
}
