
import 'dart:convert';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

addrating(String userid,String serviceengineerid,String serviceid,String rating,String comment) async {
  var url = Uri.parse(baseUrl + 'saverating');
  var body = {
    'user_id': userid,
    'service_engineer':serviceengineerid,
    'service_id':serviceid,
    'rating':rating,
    'comment': comment
  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
  // print(resBody);
  if (res.statusCode >= 200 && res.statusCode < 300) {
    // print(resBody);
    var data = json.decode(resBody);
    if (data['user_id'].toString() == userid) {
      Fluttertoast.showToast(
        msg: 'Rating Added',
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
    } else {
      Fluttertoast.showToast(
        msg:"Something is wrong..",
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );

    }
  } else {
    Fluttertoast.showToast(
      msg: "Something is wrong..",
      backgroundColor: Colors.black,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
    );
  }
}