
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

Future<bool>sendwriteus(String userid,String querytype,String servicedate ,String message) async {
  var url = Uri.parse(baseUrl + 'write_us');
  var body = {
    'user_id': userid,
    'querytype':querytype,
    'servicedate':servicedate,
    'message':message
  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
   // print(resBody);
  if (res.statusCode == 200) {
return true;
  }
  else {

    return false;
  }
}
Future<bool>sendsupport(String userid,String name,String issue ) async {
  var url = Uri.parse(baseUrl + 'support');
  var body = {
    'user_id': userid,
    'Name':name,
    'Issue':issue,
  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
  print(resBody);
  if (res.statusCode == 200) {
    return true;
  }
  else {

    return false;
  }
}