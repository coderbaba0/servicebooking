
import 'package:book_services/Screens/chat/chat_widget/imageview.dart';
import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/constant/constui.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:url_launcher/url_launcher.dart';
class MessageTile extends StatefulWidget {
  final message;
  final String sender;
  final bool sentByMe;
  final String time;
  final int messagetype;
  const MessageTile({
    Key? key,
    required this.time,
    required this.message,
    required this.sender,
    required this.sentByMe,
    required this.messagetype,
  }) : super(key: key);
  @override
  State<MessageTile> createState() => _MessageTileState();
}
class _MessageTileState extends State<MessageTile> {
  String filepath = '';
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          top: 4,
          bottom: 4,
          left: widget.sentByMe ? 0 : 24,
          right: widget.sentByMe ? 24 : 0),
      alignment: widget.sentByMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Column(
        children: [
          Container(
            margin: widget.sentByMe
                ? const EdgeInsets.only(left: 30)
                : const EdgeInsets.only(right: 30),
            padding:
             const EdgeInsets.only(top: 10, bottom: 10, left: 10, right: 10),
            decoration: BoxDecoration(
                border: Border.all(width: 1,color: kPrimaryColor,),
                borderRadius: widget.sentByMe
                    ? const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                  bottomLeft: Radius.circular(20),
                )
                    : const BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
                color: widget.sentByMe ?  kPrimaryColor:Colors.black.withOpacity(0.9)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 2,
                ),
                 widget.messagetype == MessageType.file
                    ? InkWell(
                     onTap: ()async {
                       Uri _url = Uri.parse(widget.message);
                       if (await launchUrl(_url)) {
                         await launchUrl(_url,mode: LaunchMode.externalApplication);
                       } else {
                         throw 'Could not launch $_url';
                       }
                     },
                      child: Container(
                        width: 200,
                        height: 30,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.picture_as_pdf,color: Colors.red,),
                            SizedBox(width: 10,),
                            Text('View Pdf Attachment',
                             textAlign: TextAlign.start,
                             style: const TextStyle(
                                 fontStyle: FontStyle.normal,
                               decoration: TextDecoration.underline,
                               fontSize: 14, color: Colors.white,)),
                          ],
                        ),
                      ),
                    ):
                 widget.messagetype == MessageType.text
                     ? Text(widget.message,
                    textAlign: TextAlign.start,
                    style: const TextStyle(
                        shadows: <Shadow>[
                          Shadow(
                            offset: Offset(0.9, 0.9),
                            blurRadius: 1.0,
                            color: Colors.black45,
                          ),
                        ],
                        fontStyle: FontStyle.normal,
                        fontSize: 16, color: Colors.white,fontWeight: FontWeight.w300))
                    : Container(
                  decoration: BoxDecoration(
                    border:
                    Border.all(width: 1.0, color: Colors.white),
                    borderRadius:
                    BorderRadius.all(Radius.circular(2)),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              FullImageView(url: widget.message),
                        ),
                      );
                    },
                    child: Image.network(
                      widget.message,
                      fit: BoxFit.cover,
                      loadingBuilder: (BuildContext ctx, Widget child,
                          ImageChunkEvent? loadingProgress) {
                        if (loadingProgress == null) return child;
                        return Center(
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 1.0,
                            value:
                            loadingProgress.expectedTotalBytes !=
                                null &&
                                loadingProgress
                                    .expectedTotalBytes !=
                                    null
                                ? loadingProgress
                                .cumulativeBytesLoaded /
                                loadingProgress
                                    .expectedTotalBytes!
                                : null,
                          ),
                        );
                      },
                      errorBuilder: (_, __, ___) => Center(
                        child: Icon(
                          Icons.signal_wifi_connected_no_internet_4,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ),
                  height: 180,
                  width: 180,
                ),
              ],
            ),
          ),
          Text(widget.time,
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 13, color: Colors.black54)),
        ],
      ),
    );
  }

}
//unimplemented