
import 'package:book_services/Screens/homepage/component/service_bycategory.dart';
import 'package:book_services/Screens/services/all_services.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/data_repo/categorydata.dart';
import 'package:book_services/helper/global.dart';
import 'package:flutter/material.dart';

import '../../../constant/loader.dart';

class Allcategory extends StatefulWidget {

  const Allcategory({Key? key}) : super(key: key);
  @override
  State<Allcategory> createState() => _AllcategoryState();
}
class _AllcategoryState extends State<Allcategory> with SingleTickerProviderStateMixin{
  AnimationController? _animationController;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // Allcat();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white54,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(left:15.0,right:15,top:0,bottom:50),
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)
              ),
              width:double.infinity,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(
                          Icons.cancel,
                          size: 30,
                          color: kPrimaryColor,
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 0,),
                  MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: FutureBuilder<dynamic>(
                          future:Allcat(),
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              return GridView.builder(
                                  shrinkWrap: true,
                                  // scrollDirection: Axis.vertical,
                                  physics: const NeverScrollableScrollPhysics(),
                                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 4, mainAxisSpacing: 1),
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    return InkWell(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(builder: (context) => servicesbycategory(title: snapshot.data![index]['name'],id:snapshot.data![index]['id'])),
                                        );
                                      },
                                      child: Column(
                                        children: [
                                          Container(
                                              height: 50,
                                              width: 50,
                                              decoration: BoxDecoration(
                                                color: Colors.black12,
                                                  border: Border.all(
                                                      color: Colors.black54,
                                                      width: 1),
                                                  image: DecorationImage(
                                                    image: NetworkImage(
                                                        imgUrl+snapshot.data![index]['icon']),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  shape: BoxShape.circle)),
                                          const SizedBox(height: 5),
                                          Text(
                                            snapshot.data![index]['name'],
                                            // snapshot.data!.name,
                                            style: TextStyle(fontSize: 10),
                                            textAlign: TextAlign.center,
                                            maxLines: 3,
                                          )
                                        ],
                                      ),
                                    );
                                  });
                            }
                            else{
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 20.0),
                                child: Center(child: ColorLoader2()),
                              );
                            }
                          }
                      )
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
