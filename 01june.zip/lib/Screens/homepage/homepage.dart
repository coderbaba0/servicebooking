import 'package:book_services/Screens/homepage/component/body.dart';
import 'package:book_services/Screens/homepage/component/notifications.dart';
import 'package:book_services/Screens/homepage/component/search.dart';
import 'package:book_services/Screens/profile/profile.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';

import '../../persisit/constantdata.dart';

class HomeScreen extends StatefulWidget {
  static String routeName = "/home";
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(90.0),
        child: AppBar(
          automaticallyImplyLeading: false,
          elevation: 2,
          backgroundColor: kPrimaryColor,
          toolbarHeight: SizeConfig.screenHeight * 0.2,
          centerTitle: false,
          title: Padding(
            padding: const EdgeInsets.only(top: 25.0,left: 0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 40, left: 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    // crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0),
                        child: CircleAvatar(
                          radius: 20,
                          backgroundImage:
                              ExactAssetImage('assets/images/icon.png'),
                        ),
                      ),
                      Container(
                        height: 40,
                         width: MediaQuery.of(context).size.width/1.48,
                        decoration: BoxDecoration(
                          // ignore: prefer_const_constructors
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: TextFormField(
                          //
                          textAlignVertical: TextAlignVertical.center,
                          style: TextStyle(
                              fontSize: 14.0,
                              height: 1.0,
                              color: Colors.white),
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const SearchScreen()));
                          },
                          cursorColor: Colors.white,
                          cursorHeight: 15,
                          keyboardType: TextInputType.text,
                          showCursor: true,
                          // onSaved:,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Enter Query";
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            prefix: Padding(
                              padding: EdgeInsets.only(
                                top: 30,
                              ),
                            ),
                            prefixIcon: Padding(
                              padding: const EdgeInsets.only(left: 0.0),
                              child: Icon(
                                Icons.do_not_disturb_on_total_silence_sharp,
                                color: Colors.transparent,
                              ),
                            ),
                            prefixIconConstraints:
                                BoxConstraints(maxWidth: 15),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.white38),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            labelStyle: const TextStyle(
                              color: kPrimaryColor,
                            ),
                            focusColor: kTextColorSecondary.withOpacity(0.2),
                            hintText: "Search Services..",
                            fillColor: Colors.white54.withOpacity(0.3),
                            filled: true,
                            suffixIcon: const Icon(
                              Icons.camera_alt_outlined,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      Badge(
                        isLabelVisible: true,
                        largeSize: 15,
                        alignment: Alignment.topRight,
                        backgroundColor: Colors.red,
                        label: Text('9'),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0,bottom: 7.0),
                          child: IconButton(
                            visualDensity:  VisualDensity(
                                      horizontal: -4.0, vertical: -4.0),
                            onPressed: () {
                              Navigator.of(context).pushNamedAndRemoveUntil(
                                            Notifications.routeName, (route) => true);
                            },
                            icon: Icon(Icons.notifications_active_outlined,color: Colors.white,size: 30,weight: 5,),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Profile(),
                        ));
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(40, 0, 0, 50),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.person,
                          color: Colors.white,
                          size: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: Text(
                            Constant.username.isEmpty
                                ? 'Hello, Guest'
                                : 'Hi , ' + Constant.username.toString().toUpperCase(),
                            // box!.get("Address"),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 14),
                          ),
                        ),
                            Icon(Icons.arrow_drop_down),
                        // Text(
                        //   'Edit',
                        //   // box!.get("Address"),
                        //   overflow: TextOverflow.ellipsis,
                        //   maxLines: 1,
                        //   style: const TextStyle(color: Colors
                        //       .black54, fontSize: 14),
                        // ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: const Body(),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.transparent,
        splashColor: Colors.transparent,
        focusColor: Colors.transparent,
        child: Center(
          child: Column(
            children: [
              CircleAvatar(
                  radius: 25,
                  backgroundColor: kPrimaryColor.withOpacity(0.4),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      'assets/images/WhatsApp.png',
                      height: 40,
                      width: 40,
                    ),
                  )),
              // Text('Send',style: TextStyle(color: Colors.green,fontSize: 15,fontWeight: FontWeight.w500),)
            ],
          ),
        ),
        elevation: 0,
        onPressed: () {},
        tooltip: 'Send',
      ),
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.home),
    );
  }
}
