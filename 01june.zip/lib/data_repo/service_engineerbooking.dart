import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';
import 'package:book_services/models/ServiceCategory.dart';
Future<dynamic> serviceengineerbooking(String engineerid) async {
  final response = await http.get(
    Uri.parse(baseUrl+'service_engineer/mybookings/'+engineerid),
  );
  var data = jsonDecode(response.body.toString());
  // print(data);
  if (response.statusCode == 200) {
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}