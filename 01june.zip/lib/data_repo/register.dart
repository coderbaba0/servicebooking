import 'dart:developer';
import 'dart:async';
import 'dart:convert';
import 'package:book_services/helper/global.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/All_category.dart';
// class HomePageProvider with ChangeNotifier {
//   AllCategory responseData = AllCategory();
//   bool isLoading = false;
//   getMyData() async {
//     isLoading = true;
//     responseData = await getAllData();
//     isLoading = false;
//     notifyListeners();
//   }
//   Future<AllCategory> getAllData() async {
//     try {
//       final response = await http.get(
//         Uri.parse(baseUrl+'categories'),
//       );
//       if (response.statusCode == 200) {
//         final item = json.decode(response.body);
//         print(item);
//         responseData = AllCategory.fromJson(item);
//         notifyListeners();
//       } else {
//         print("else");
//       }
//     } catch (e) {
//       log(e.toString());
//     }
//     return responseData;
//   }
// }