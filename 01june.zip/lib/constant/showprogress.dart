import 'package:book_services/constant/loader.dart';
import 'package:flutter/material.dart';
import 'package:book_services/constant/constui.dart';

 class Constants {
static showProgressDialog(BuildContext context, String title) {
  try {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            content: Flex(
              direction: Axis.horizontal,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left:8.0),
                  child: Container(
                      height:20,width:20,
                      child: ColorLoader2()),
                ),
                Padding(padding: EdgeInsets.only(left: 25),),
                Flexible(
                    flex: 8,
                    child: Text(
                      title,
                      style: TextStyle(
                          fontSize: 14, fontWeight: FontWeight.bold),
                    )),
              ],
            ),
          );
        });
  } catch (e) {
    print(e.toString());
  }
}
}