class userbookingmodel {
  int? id;
  String? firstName;
  String? lastName;
  String? mobile;
  String? email;
  String? location;
  String? service;
  String? price;
  String? issues;
  String? status;
  String? assigned;
  String? invoiceNo;
  String? createdAt;
  String? updatedAt;
  String? date;
  String? time;
  String? locationFor;
  Null? maxDiscount;
  Null? tax;
  int? userId;
  ServiceEngineer? serviceEngineer;

  userbookingmodel(
      {this.id,
        this.firstName,
        this.lastName,
        this.mobile,
        this.email,
        this.location,
        this.service,
        this.price,
        this.issues,
        this.status,
        this.assigned,
        this.invoiceNo,
        this.createdAt,
        this.updatedAt,
        this.date,
        this.time,
        this.locationFor,
        this.maxDiscount,
        this.tax,
        this.userId,
        this.serviceEngineer});

  userbookingmodel.fromMap(Map<String, dynamic> json) {
    id = json['id'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    mobile = json['mobile'];
    email = json['email'];
    location = json['location'];
    service = json['service'];
    price = json['price'];
    issues = json['issues'];
    status = json['status'];
    assigned = json['assigned'];
    invoiceNo = json['invoice_no'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    date = json['date'];
    time = json['time'];
    locationFor = json['location_for'];
    maxDiscount = json['max_discount'];
    tax = json['tax'];
    userId = json['user_id'];
    serviceEngineer = json['service_engineer'] != null
        ? new ServiceEngineer.fromJson(json['service_engineer'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['mobile'] = this.mobile;
    data['email'] = this.email;
    data['location'] = this.location;
    data['service'] = this.service;
    data['price'] = this.price;
    data['issues'] = this.issues;
    data['status'] = this.status;
    data['assigned'] = this.assigned;
    data['invoice_no'] = this.invoiceNo;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['date'] = this.date;
    data['time'] = this.time;
    data['location_for'] = this.locationFor;
    data['max_discount'] = this.maxDiscount;
    data['tax'] = this.tax;
    data['user_id'] = this.userId;
    if (this.serviceEngineer != null) {
      data['service_engineer'] = this.serviceEngineer!.toJson();
    }
    return data;
  }
}

class ServiceEngineer {
  int? id;
  String? category;
  String? name;
  String? email;
  String? phone;
  String? address;
  String? status;
  String? createdAt;
  String? updatedAt;

  ServiceEngineer(
      {this.id,
        this.category,
        this.name,
        this.email,
        this.phone,
        this.address,
        this.status,
        this.createdAt,
        this.updatedAt});

  ServiceEngineer.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    category = json['category'];
    name = json['name'];
    email = json['email'];
    phone = json['phone'];
    address = json['address'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['category'] = this.category;
    data['name'] = this.name;
    data['email'] = this.email;
    data['phone'] = this.phone;
    data['address'] = this.address;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}