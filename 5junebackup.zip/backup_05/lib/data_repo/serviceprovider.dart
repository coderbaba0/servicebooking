import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';
import 'package:book_services/models/ServiceCategory.dart';

Future<dynamic> getservicebycategory(String catid) async {
  final response = await http.get(
    Uri.parse(baseUrl+'services_by_category/'+catid),
  );
  var data = jsonDecode(response.body.toString());
  // print(data);
  if (response.statusCode == 200) {
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}
Future<dynamic> getdicountservices() async {
  final response = await http.get(
    Uri.parse(baseUrl+'offerApplicable'),
  );
  var data = jsonDecode(response.body.toString());
  // print(data);
  if (response.statusCode == 200) {
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}