import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
// var list = [
//   "http://192.168.1.11:9000/api/crousel",
//   'http://192.168.1.11:9000/api/recommended',
//   "http://192.168.1.11:9000/api/offerApplicable",
// ];
// Future<dynamic> makeMultipleRequests() async {
//   await Future.forEach(list, (url) async{
//     await fetchData(url);
//   });
// }
//  Future<dynamic> fetchData(String url) async {
//   var response = await http.get(Uri.parse(url));
//   // print(response.body);
//   return response.body.toString();
// }
