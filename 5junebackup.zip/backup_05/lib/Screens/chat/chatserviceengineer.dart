
import 'dart:convert';
import 'dart:typed_data';
import 'package:book_services/Screens/chat/chat_widget/message_tile.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/persisit/constantdata.dart';
import 'package:book_services/utils/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import 'package:url_launcher/url_launcher.dart';
import '../../constant/loader.dart';
import '../../constant/showprogress.dart';
import '../../helper/global.dart';
import 'package:http/http.dart' as http;

import '../../notifications.dart';
class ChatServiceengineer extends StatefulWidget {
  static String routeName = "/chat";
  final bookingdata;
  const ChatServiceengineer({Key? key, this.bookingdata}) : super(key: key);
  @override
  MyChatUIState createState() => MyChatUIState();
}
class MyChatUIState extends State<ChatServiceengineer> {
  NotificationServices notificationServices = NotificationServices();
// String sendtoken= 'dwvXlZUgRBC8XPDwUDWWGW:APA91bG0T0_PMKhRl9REB96spJFiKMOtTwrCtOfJX761Rkp0K6KlrDL_IeSF0po8H-sB3p0elMH4d1mIkNoh6kbVQXOl9X66kGBKwUvPtenjdgdhDekeN2ZtZwqmNIPPPvLY1_P7jnid';
//
// // 'cIhvBMBdSu-7nyXVO7E8s8:APA91bFJJ3Mq6UZXgf60eHe7i26BXl0eacQS7-PcHiE8ICX5Q_-WxPj1MtfDXxMDS07HbeiJbszlJjoaA6zmVxj093ZBrNIJ_WY9zrjD_OZv_5YaFuGpPuzZm3mUfqBDUn_qoKvNskYl';
//     // 'dwvXlZUgRBC8XPDwUDWWGW:APA91bG0T0_PMKhRl9REB96spJFiKMOtTwrCtOfJX761Rkp0K6KlrDL_IeSF0po8H-sB3p0elMH4d1mIkNoh6kbVQXOl9X66kGBKwUvPtenjdgdhDekeN2ZtZwqmNIPPPvLY1_P7jnid';
//   String sendtoken2= 'cifsyKPzTn28Djk7r303MY:APA91bGWRt4ViKzD4VKebfgpoUJr9sH0p5T_JEam9eN_IgCyAOpMmSOwGknRyASn8d--bHCzF9kUr1Z2BE1vbDLnTnrM1OVsPVg8aoJjiLsx7GtUNEDN-G-no9RxNGqS7a4i7zdpzA0Y';
// //
  Offset _tapPosition = Offset.zero;
  void _getTapPosition(TapDownDetails details) {
    final RenderBox referenceBox = context.findRenderObject() as RenderBox;
    setState(() {
      _tapPosition = referenceBox.globalToLocal(details.globalPosition);
    });
  }
  void _showContextMenu(BuildContext context, var delete ) async {
    final RenderObject? overlay =
    Overlay.of(context).context.findRenderObject();
    final result = await showMenu(
        context: context,
        // Show the context menu at the tap location
        position: RelativeRect.fromRect(
            Rect.fromLTWH(_tapPosition.dx, _tapPosition.dy, 30, 30),
            Rect.fromLTWH(0, 0, overlay!.paintBounds.size.width,
                overlay.paintBounds.size.height)),
        // set a list of choices for the context menu
        items: [
          const PopupMenuItem(
            value: 'delete',
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Icon(Icons.delete,color: Colors.red,),
                Text('Delete',style: TextStyle(color: Colors.red),),
              ],
            ),
          ),
          const PopupMenuItem(
            value: 'exit',
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Icon(Icons.dangerous_outlined,color: Colors.green,),
                Text('Exit',style: TextStyle(color: Colors.green),),
              ],
            ),
          ),
        ]);
    // Implement the logic for each choice here
    switch (result) {
      case 'delete':
        await FirebaseFirestore.instance.runTransaction((Transaction myTransaction) async {
          await myTransaction.delete(delete.reference);});
        break;
      case 'exit':
        break;
    }
  }
  //
  bool isLoading2 =false;
  bool isLoading =false;
  Stream<QuerySnapshot>? chats;
  final ImagePicker _picker = ImagePicker();
  File? _selectedImage;
  String imageUrl = "";
  String fileUrl ="";
  String? fileName;
  var controller = TextEditingController();
  ScrollController scrollController = ScrollController();
  var message = '';
  @override
  void initState() {
    notificationServices.requestNotificationPermission();
    notificationServices.firebaseInit(context);
    notificationServices.setupInteractMessage(context);
    notificationServices.isTokenRefresh();
    getChat();
    scrollController.addListener(_scrollListener);
    super.initState();
  }
  getChat() {
    DatabaseService().getChats(widget.bookingdata['id'].toString()).then((val) {
      setState(() {
        chats = val;
      });
    });
  }
  _scrollListener() {
    if (scrollController.offset >=
        scrollController.position.maxScrollExtent &&
        !scrollController.position.outOfRange) {
      setState(() {
        // _limit += _limitIncrement;
      });
    }
  }
  Future<void> uploadImageFile(File image, String filename) async {
    final storageRef = FirebaseStorage.instance.ref();
    final reference = storageRef.child('chatsimage/$filename');
    UploadTask uploadTask = reference.putFile(image);
    try {
      TaskSnapshot snapshot = await uploadTask;
      imageUrl = await snapshot.ref.getDownloadURL();
      setState(() {
        isLoading = false;
        sendMessage(MessageType.image);
      });
    } on FirebaseException catch (e) {
      setState(() {
        isLoading = false;
      });
      //
    }
  }
  Future<void> uploadFile(File file, String filename) async {
    final storageRef = FirebaseStorage.instance.ref();
    final reference = storageRef.child('document/$filename');
    UploadTask uploadTask = reference.putFile(file);
    try {
      TaskSnapshot snapshot = await uploadTask;
      fileUrl = await snapshot.ref.getDownloadURL();
      setState(() {
        isLoading2 = false;
        sendMessage(MessageType.file);
      });
    } on FirebaseException catch (e) {
      setState(() {
        isLoading2 = false;
      });
      //
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffF5F5F3),
      appBar: AppBar(
        elevation: 2,
        titleSpacing: 2,
        backgroundColor: kPrimaryColor,
        automaticallyImplyLeading: true,
        leadingWidth: 30,
        iconTheme: IconThemeData(
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],
          color: Colors.white, //change your color here
        ),
        title: ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.black12,
            child: Icon(Icons.person),
          ),
          title:  Text(
            widget.bookingdata['service'].toString(),
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 16,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
          subtitle:  Text(
            'id :#'+widget.bookingdata['id'].toString(),
            style: TextStyle(color: Colors.white,fontSize: 12,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
        ),
        actions:  [
          IconButton(onPressed: (){}, icon: Icon(Icons.more_vert_outlined))
          // widget.bookingdata['service_engineer'].toString()=='null'?Container():InkWell(
          //   onTap: ()
          //   async{
          //     Uri phoneno = Uri.parse(widget.bookingdata['service_engineer']['phone'].toString());
          //     Fluttertoast.showToast(
          //       msg: "Dialer is Opening..",
          //       backgroundColor: Colors.black,
          //       toastLength: Toast.LENGTH_LONG,
          //       gravity: ToastGravity.CENTER,
          //     );
          //     (await launchUrl(phoneno));
          //   },
          //   child: Padding(
          //     padding: EdgeInsets.only(right: 20),
          //     child: CircleAvatar(
          //         backgroundColor: Colors.white54,
          //         radius: 20,
          //         child: Icon(Icons.dialer_sip_outlined,color: Colors.white,size: 20,)),
          //   ),
          // ),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: Container(child: chatMessages(),)),
          Container(
            alignment: Alignment.center,
            color: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: (){
                      _optionsDialogBox();
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(bottom: 5.0, left: 8,right: 4),
                      child: Icon(
                        Icons.camera_alt,
                        color: kPrimaryColor,
                        size: 35,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          color: kPrimaryColor.withOpacity(0.2),
                          borderRadius: BorderRadius.all(Radius.circular(25))),
                      child: TextFormField(
                        maxLines: 6,
                        minLines: 1,
                        keyboardType: TextInputType.multiline,
                        controller: controller,
                        onFieldSubmitted: (value) {
                          controller.text = value;
                        },
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.only(left: 8),
                          border: InputBorder.none,
                          focusColor: Colors.white,
                          hintText: 'Type your issue..',
                        ),
                      ),
                    ),
                  ),

                  Transform.rotate(
                    angle: 45,
                    child:    IconButton(onPressed: (){
                      pickfile();
                    }, icon: Icon(Icons.attach_file)),
                  ),
                  GestureDetector(
                    onTap: () {
                      if(controller.text.isEmpty)
                      {
                        Fluttertoast.showToast(
                          msg: "Please type your issue!",
                          backgroundColor: Colors.black,
                          toastLength: Toast.LENGTH_LONG,
                          gravity: ToastGravity.CENTER,
                        );
                      }
                      else{
                        sendMessage(MessageType.text);
                      }
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(bottom: 5, right: 8),
                      child: CircleAvatar(
                        backgroundColor: kPrimaryColor,
                        child: Icon(
                          Icons.send,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
  // chat message view
  chatMessages() {
    return StreamBuilder(
      stream: chats,
      builder: (context, AsyncSnapshot snapshot) {
        return snapshot.hasData
            ? Column(
          children: [
            Expanded(
              child: ListView.builder(
                controller: scrollController,
                shrinkWrap: true,
                reverse: true,
                itemCount: snapshot.data.docs.length,
                itemBuilder: (context, index) {
                  final incomingDate2 =
                  DateTime.fromMillisecondsSinceEpoch(
                      int.parse(snapshot.data.docs[
                      snapshot.data.docs.length -
                          1 -
                          index]['time']),
                      isUtc: false)
                      .toIso8601String()
                      .toString();
                  final dateValue2 = DateTime.parse(incomingDate2);
                  final formatted2 = DateFormat('dd MMM HH:mm a')
                      .format(dateValue2.toLocal());
                  final formatted1 =
                  DateFormat('HH:mm a').format(dateValue2.toLocal());
                  bool isToday(DateTime dateValue2) {
                    final DateTime localDate = dateValue2.toLocal();
                    final now = DateTime.now();
                    final diff = now.difference(localDate).inDays;
                    return diff == 0 && now.day == localDate.day;
                  }
                  bool isyesterday(DateTime dateValue2) {
                    final DateTime localDate = dateValue2.toLocal();
                    final now = DateTime.now();
                    final diff = now.difference(localDate).inDays;
                    return  now.day-1 == localDate.day;
                  };
                  return InkWell(
                    onTapDown: (details) => _getTapPosition(details),
                    onLongPress:  () => _showContextMenu(context, snapshot.data.docs[snapshot.data.docs.length - 1 - index] ),
                    // {

                    //     });
                    // },
                    child: MessageTile(
                      messagetype: snapshot.data
                          .docs[snapshot.data.docs.length - 1 - index]
                      ['messagetype'],
                      message: snapshot.data
                          .docs[snapshot.data.docs.length - 1 - index]
                      ['message'],
                      sender: snapshot.data
                          .docs[snapshot.data.docs.length - 1 - index]
                      ['sender'],
                      sentByMe:Constant.userId.toString() ==
                          snapshot.data.docs[snapshot.data.docs.length -
                              1 -
                              index]['sender'],
                      time: isToday(dateValue2) ? formatted1 : formatted2, ),
                  );
                },
              ),
            ),
            isLoading
                ? Padding(
              padding: const EdgeInsets.only(right: 15.0,bottom: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: kPrimaryColor,
                      border: Border.all(color: Colors.transparent),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                        topLeft: Radius.circular(20),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 8,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left:15,right: 15,bottom: 15),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.white),
                              borderRadius: BorderRadius.all(Radius.circular(2)),
                            ),
                            child:Center(
                              child: Container(width:30,height:30,child: ColorLoader2()),
                            ),
                            height: 180,
                            width: 180,
                          ),
                        ),
                      ],
                    ),

                  ),

                ],
              ),

            )
                : Container(),
            isLoading2?Container(width:30,height:30,child: ColorLoader2()):Container()

          ],
        )
            : Container();
      },
    );
  }
  Future<void> _optionsDialogBox() {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Choose Source'),
          contentPadding: const EdgeInsets.all(20.0),
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                GestureDetector(
                  child: const Text("Take a Picture"),
                  onTap: openCamera,
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                ),
                const Divider(
                  color: Colors.white70,
                  height: 1.0,
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                ),
                GestureDetector(
                  child: const Text("Open Gallery"),
                  onTap: openGallery,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  Future openCamera() async {
    Navigator.of(context).pop();
    var imageFrmCamera = await _picker.getImage(source: ImageSource.camera);
    setState(() {
      _selectedImage = File(imageFrmCamera!.path);
      fileName = _selectedImage!.path.split('/').last;
      // print(fileName);
      if (_selectedImage != null) {
        setState(() {
          isLoading = true;
        });
        uploadImageFile(_selectedImage!,fileName!);
      }
    });
    //if (mounted) Navigator.of(context).pop();
  }
  //Gallery method
  Future openGallery() async {
    Navigator.of(context).pop();
    var pickedFile = await _picker.getImage(source: ImageSource.gallery);
    setState(() {
      _selectedImage = File(pickedFile!.path);
      fileName = _selectedImage!.path.split('/').last;
      // print(fileName);
      if (_selectedImage != null) {
        setState(() {
          isLoading = true;
        });
        uploadImageFile(_selectedImage!,fileName!);
      }

    });
    // if (mounted) Navigator.of(context).pop();
  }
  Future pickfile()async{
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom,allowedExtensions: ['pdf']);
    if (result != null) {
      setState(() {
        isLoading2 =true;
      });
      File file = File(result.files.single.path!);
      Uint8List? fileBytes = result.files.first.bytes;
      String fileName = result.files.first.name;
      // Upload file
      uploadFile(file,fileName);
    }
  }
  sendMessage(int type) {
    if (type == MessageType.text && controller.text.isNotEmpty) {
      Map<String, dynamic> chatMessageMap = {
        "message": controller.text.trim(),
        "sender": Constant.userId,
        "time": DateTime.now().millisecondsSinceEpoch.toString(),
        "messagetype": type,
      };
      DatabaseService().sendMessage(widget.bookingdata['id'].toString(), chatMessageMap);
      sendPushMessage2(controller.text.trim(),'📨 New Messages from Al KHAIL Services',widget.bookingdata['user_token']['token']);
      setState(() {
        controller.clear();
      });
    }else if(type==MessageType.file){
      Map<String, dynamic> chatMessageMap={
        "message": fileUrl,
        "sender": Constant.userId,
        "time": DateTime.now().millisecondsSinceEpoch.toString(),
        "messagetype": type,
      };
      DatabaseService().sendMessage(widget.bookingdata['id'].toString(), chatMessageMap);
      DatabaseService(uid: Constant.userId).saveNotifications('📑 Pdf Attachment Received Regarding your '+widget.bookingdata['service'],DateTime.now().toString(),widget.bookingdata['service'],widget.bookingdata['id'].toString(),widget.bookingdata['user_token']['token']);
      sendPushMessage2('📑 Pdf Attachment Received Regarding your '+widget.bookingdata['service'],'Al KHAIL Services',widget.bookingdata['user_token']['token']);
    }
    else{
      Map<String, dynamic> chatMessageMap = {
        "message": imageUrl,
        "sender": Constant.userId,
        "time": DateTime.now().millisecondsSinceEpoch.toString(),
        "messagetype": type,
      };
      DatabaseService().sendMessage(widget.bookingdata['id'].toString(), chatMessageMap);
      DatabaseService(uid: Constant.userId).saveNotifications('🖼️ Media File Received Regarding your '+widget.bookingdata['service'],DateTime.now().toString(),widget.bookingdata['service'],widget.bookingdata['id'].toString(),widget.bookingdata['user_token']['token']);
      sendPushMessage2('🖼️ Media File Received','Al KHAIL Services',widget.bookingdata['user_token']['token'],imageUrl);
    }
  }
  void sendPushMessage2(String body, String title, String token, [String? image]) async {
    try {
      await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String> {
          'Content-Type': 'application/json',
          'Authorization':
          'key=AAAADB4KFTg:APA91bEvM5SNQSW6uMOzwTf55zi7mMX33_cJAl0NNrsz_RdzRbLGrXX-rO78yLifC7r2r0wWZiwVyiZqf8Fc1GcmJkE-lkavC4uHwT13FymMihi_W4CUKVzcbMJsUkAvQ2Ec1yDbGPyb',
        },
        body: jsonEncode (
          <String, dynamic> {
            'notification': <String, dynamic>{
              'body': body,
              'title': title,
              'color' : '#eeeeee',
              "image": image,
              'count' : 10,
              'notification_count' : 10,
              'badge' : 10,
            },
            'priority': 'high',
            'data': <String, dynamic>{
              'click_action': 'FLUTTER_NOTIFICATION_CLICK',
              'id': widget.bookingdata['id'].toString(),
              'servicename': widget.bookingdata['service'],
              'status': 'done',
            },
            "to": token,
          },
        ),
      );
      print(' send done');
    } catch (e) {
      print("error push notification");
    }
  }
}
class MessageType {
  static const text = 0;
  static const image = 1;
  static const file = 2;
}
