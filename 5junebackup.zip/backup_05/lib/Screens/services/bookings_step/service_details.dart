import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:book_services/Screens/services/bookings_step/failed.dart';
import 'package:book_services/Screens/services/bookings_step/sucess.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/data_repo/favorite.dart';
import 'package:book_services/helper/global.dart';
import 'package:book_services/size_config.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_places_picker_refractored/google_maps_places_picker_refractored.dart';
import 'package:time_range_picker/time_range_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../data_repo/savebooking.dart';
import '../../../persisit/constantdata.dart';
import 'package:http/http.dart' as http;
DateTime selectedDate =  DateTime.now().add(Duration(hours: 2));
class ServiceDetails extends StatefulWidget {
  static String routeName = "/servicedetails";
  ServiceDetails({Key? key, @required this.servicedata}) : super(key: key);
  final servicedata;
  @override
  State<ServiceDetails> createState() => _ServiceDetailsState();
}
class _ServiceDetailsState extends State<ServiceDetails>
    with TickerProviderStateMixin {
  bool _danger=false;
  double ? lat ;
  double ? long;
  //for current location
  LatLng? _currentPosition;
  LatLng basePosition = LatLng(56.324293441187315, 38.13961947281509);
  getLocation() async {
    LocationPermission permission;
    permission = await Geolocator.requestPermission();
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
     lat = position.latitude;
     long = position.longitude;
    LatLng location = LatLng(lat!, long!);
    setState(() {
      _currentPosition = location;
      print(_currentPosition.toString());
    });
  }
  getAddressFromLatLng(context, double lat, double lng) async {
    String _host = 'https://maps.google.com/maps/api/geocode/json';
    final url = '$_host?key=AIzaSyAbN1uulBVvR6GkHkJUniPC9nkQ7yYcXAo&language=en&latlng=$lat,$lng';
      var response = await http.get(Uri.parse(url));
      if(response.statusCode == 200) {
        Map data = jsonDecode(response.body);
        // print(data.toString());
        String _formattedAddress = data["results"][0]["formatted_address"];
        // print("response ==== $_formattedAddress");
        setState(() {
          addresscontroller.text =_formattedAddress;
        });
        return _formattedAddress;
    } else return null;
  }
  TimeRange? result = TimeRange(startTime: const TimeOfDay(hour: 10, minute: 0), endTime: const TimeOfDay(hour: 11, minute: 0));
  TimeOfDay selectedTime = TimeOfDay.fromDateTime(selectedDate);
  //for time
  Future<void> _selectTime(BuildContext context) async {
     result = await showTimeRangePicker(
       selectedColor: kPrimaryColor,
       strokeColor: kPrimaryColor,
       // interval: Duration(minutes: 60),
        context: context,
        start: const TimeOfDay(hour: 10, minute: 0),
        end: const TimeOfDay(hour: 11, minute: 0),

        disabledTime: TimeRange(
            startTime: const TimeOfDay(hour: 22, minute: 0),
            endTime: const TimeOfDay(hour: 5, minute: 0)),
        disabledColor: Colors.red.withOpacity(0.5),
        strokeWidth: 4,
        ticks: 24,
        ticksOffset: -7,
        ticksLength: 15,
        ticksColor: Colors.grey,
        labels: [
          "12 pm",
          "3 pm",
          "6 pm",
          "9 pm",
          "12 am",
          "3 am",
          "6 am",
          "9 am"
        ].asMap().entries.map((e) {
          return ClockLabel.fromIndex(
              idx: e.key, length: 8, text: e.value);
        }).toList(),
        labelOffset: 35,
        rotateLabels: false,
        padding: 60);

    if (kDebugMode) {
      print("result $result");
    }

    if (result != null  )
      setState(() {
        result = result;
      });
  }
  // Future<void> _selectTime(BuildContext context) async {
  //   final TimeOfDay? picked_s = await showTimePicker(
  //       context: context,
  //       initialTime: selectedTime,
  //     builder: (context, child) {
  //       return Theme(
  //         data: Theme.of(context).copyWith(
  //           colorScheme: ColorScheme.light(
  //             primary: kPrimaryColor, // <-- SEE HERE
  //             onPrimary: Colors.white, // <-- SEE HERE
  //             onSurface: Colors.black, // <-- SEE HERE
  //           ),
  //           textButtonTheme: TextButtonThemeData(
  //             style: TextButton.styleFrom(
  //               primary: Colors.red, // button text color
  //             ),
  //           ),
  //         ),
  //         child: child!,
  //       );
  //     },
  //     );
  //
  //   if (picked_s != null && picked_s != selectedTime )
  //     setState(() {
  //       selectedTime = picked_s;
  //     });
  // }
//for date
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        builder: (context, child) {
          return Theme(
            data: Theme.of(context).copyWith(
              colorScheme: ColorScheme.light(
                primary: kPrimaryColor, // <-- SEE HERE
                onPrimary: Colors.white, // <-- SEE HERE
                onSurface: Colors.black, // <-- SEE HERE
              ),
              textButtonTheme: TextButtonThemeData(
                style: TextButton.styleFrom(
                  primary: Colors.red, // button text color
                ),
              ),
            ),
            child: child!,
          );
        },
        initialDate: selectedDate,
        firstDate: DateTime(2023, 5),
        lastDate: DateTime(2101));
    if (picked != null && picked != selectedDate) {
      print(picked.toString());
      if(picked.compareTo(DateTime.now().subtract(Duration(hours: 24))) > 0){
        setState(() {
          _danger = false;
          selectedDate = picked;
        });
      }
      else {
        setState(() {
          _danger = true;
        });
        Fluttertoast.showToast(
          msg: "You can't book in previous date..",
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );
      }
    }
  }
  @override
  void initState() {
    getLocation();
    mobilecontroller.text=Constant.usermobile;
  }
  Random random = new Random();
  //for customerhave
  String? codeDialog;
  String? valueText;
  final TextEditingController _textFieldController = TextEditingController();
  // for contact details
  final _formKey = GlobalKey<FormState>();
  TextEditingController mobilecontroller = TextEditingController();
  TextEditingController addresscontroller = TextEditingController();
  TextEditingController issuescontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  // for choose payment method
  bool _isfav = false;
  void toggelefav() {
    setState(() {
      if (_isfav) {
        _isfav = false;
      } else {
        _isfav = true;
      }
    });
  }
  PickResult? selectedPlace;
  // for schedule
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 50,
        elevation: 2,
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          widget.servicedata['name'],
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: false,
        automaticallyImplyLeading: true,
      ),
      bottomNavigationBar: Container(
        height: 50,
        margin: EdgeInsets.symmetric(vertical: 15, horizontal: 4),
        child: Padding(
          padding: const EdgeInsets.only(left:8.0,right: 8.0),
          child: Row(
            children: <Widget>[
              Container(
                width: SizeConfig.screenWidth/2.5,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.horizontal(left: Radius.circular(20)),
                  color: Colors.white60,
                    border: Border.all(color: kPrimaryColor,width: 1)

                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    InkWell(
                      onTap: () {
                       openWhatsapp(context: context, number: '+971507832292');
                      },
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/images/WhatsApp.png',
                              height: 40,
                              width: 40,
                            ),
                            Text('Chat',style: TextStyle(color: kPrimaryColor),),
                          ],
                        ),
                      ),
                    ),
                    ],
                ),
              ),
              Expanded(
                child: InkWell(
                  onTap: (){
                    if (_formKey.currentState!.validate()) {
                      _formKey.currentState!.save();
                      savebooking(
                          Constant.userId.toString(),
                          widget.servicedata['name'].toString(),
                         '',
                          issuescontroller.text,
                          '',
                          (DateFormat('EEEE, MMM d, yyyy').format(selectedDate)).toString(),
                          selectedTime.toString(),
                          addresscontroller.text,
                          Constant.username,
                          mobilecontroller.text,
                          emailcontroller.text,
                          '').then((value) =>showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (_) => value.toString()=='true'? Sucess() : Failed() ,)
                      );
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.horizontal(right: Radius.circular(20)),
                        color: kPrimaryColor,
                    ),
                    alignment: Alignment.center,
                    child:
                    Text("Book now", style: TextStyle(color: Colors.white, fontSize: 16)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(2)),
                SizedBox(height: getProportionateScreenWidth(4)),
                _body(),
              ],
            ),
          ),
        ),
      ),
    );
  }
  _body() {
    return Column(
        children: [
          Container(
              // width: MediaQuery.of(context).size.width * 0.9,
              // height: MediaQuery.of(context).size.height * 0.17,
              child: CarouselSlider(
            options: CarouselOptions(
              viewportFraction: 1,
              autoPlay: true,
              height: SizeConfig.screenHeight * 1 / 5.0,
            ),
            items: [1, 2].map((i) {
              return Builder(
                builder: (BuildContext context) {
                  return Stack(children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 5.0),
                      decoration: BoxDecoration(
                        border: Border.all(width: 1, color: kPrimaryColor),
                        borderRadius: BorderRadius.circular(5),
                        image: DecorationImage(
                          image: NetworkImage(
                              imgUrl + widget.servicedata['image']),
                          fit: BoxFit.cover,
                        ),
                      ),
                      // child: Center(
                      //   child: Text(
                      //     'Image $i',
                      //   ),
                      // )
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text(
                              'Description : $i',
                            ),
                          ),
                        ),
                      ),
                    ),
                  ]);
                },
              );
            }).toList(),
          )),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15.0),
                    child: Row(
                      children: [
                        Icon(Icons.star_half,color: Colors.orange,),
                        SizedBox(width: 5,),
                        Text('4.5  ('+(random.nextInt(90) + 50).toString()+')'),
                      ],
                    ),
                  ),
                ],
              ),

              Row(
                children: [
                  Text(
                    _isfav == false?'Add':'Remove ',
                    style: TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w400),
                  ),
                  IconButton(
                      onPressed: () {
                        toggelefav();
                        if (_isfav == true) {
                          addfavorite(Constant.userId.toString(),
                              widget.servicedata['id'].toString());
                        } else {
                          addfavorite(Constant.userId.toString(),
                              widget.servicedata['id'].toString());
                        }
                      },
                      icon: _isfav
                          ? Icon(
                              Icons.favorite,
                              color: Colors.orange,
                        size: 30,
                            )
                          : Icon(Icons.favorite_border,size: 28,)),
                ],
              ),
            ],
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.only(left:8.0,right:8.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                      child: Text(
                        'Describe your work :',
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10,top: 3),
                      child: Container(
                        width: double.infinity,
                        child: TextFormField(
                          maxLength: 500,
                          controller: issuescontroller,
                          minLines: 5,
                          maxLines: 7,
                          onSaved: (newValue) => newValue!,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, describe your work!!';
                            } else {
                              return null;
                            }
                          },
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                              contentPadding:
                              EdgeInsets.only(top: 10, left: 10),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: kPrimaryColor,
                                  )),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 0.5,
                                  )),
                              hintText: "Please describe your work..",
                              hintStyle: TextStyle(fontSize: 15),
                              border: OutlineInputBorder()),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                      child: Text(
                        'Schedule :',
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10,top: 3),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () => _selectDate(context),
                              child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(width: 0.8,color: _danger?Colors.red:Colors.black)
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 8,horizontal: 2),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(left: 8.0),
                                          child: Text("${selectedDate.toLocal()}".split(' ')[0],style: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),),
                                        ),
                                        Icon(Icons.calendar_month,color: kPrimaryColor,)
                                      ],
                                    ),
                                  )),
                            ),
                          ),
                          const SizedBox(width: 10.0,),
                          Expanded(
                            child: InkWell(
                              onTap: () => _selectTime(context),
                              child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      border: Border.all(width: 0.8,color: Colors.black)
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 10,horizontal: 0),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Text(result!.startTime.format(context),style: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),),
                                        Text('-'+result!.endTime.format(context),style: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),),

                                        // Icon(Icons.watch_later_outlined,color: kPrimaryColor,)
                                      ],
                                    ),
                                  )),
                            ),
                          ),

                        ],
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 10, bottom: 0),
                          child: Text(
                            "Address:",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                        Stack(
                          children:[ Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10,top: 3,bottom: 25),
                            child: Container(
                              width: double.infinity,
                              child: TextFormField(
                                controller: addresscontroller,
                                minLines: 3,
                                maxLines: 3,
                                onSaved: (newValue) => newValue!,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Please, enter Address!';
                                  } else {
                                    return null;
                                  }
                                },
                                cursorColor: kPrimaryColor,
                                decoration: InputDecoration(
                                    contentPadding:
                                    EdgeInsets.only(top: 10, left: 10),
                                    focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          color: kPrimaryColor,
                                        )),
                                    enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 0.5,
                                        )),
                                    hintText: "Enter your address..",
                                    hintStyle: TextStyle(fontSize: 14),
                                    border: OutlineInputBorder()),
                              ),
                            ),
                          ),
                            Positioned(
                              bottom: -14,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  IconButton(onPressed: () {
                                    getAddressFromLatLng(context,lat!,long!);
                                  }, icon: Icon(Icons.gps_fixed_outlined,color: kPrimaryColor,),),
                                  Text("Current Loaction",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w300),),
                                ],
                              ),
                            ),
                          ]
                        ),

                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 10, bottom: 3),
                          child: Text(
                            "Contact No :",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10),
                          child: Container(
                            width: double.infinity,
                            child: TextFormField(
                              controller: mobilecontroller,
                              onSaved: (newValue) => newValue!,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please, enter mobile!';
                                } else if (value.length > 10) {
                                  return 'Mobile number must be equal to 10 digit.';
                                } else {
                                  return null;
                                }
                              },
                              keyboardType: TextInputType.phone,
                              cursorColor: kPrimaryColor,
                              decoration: InputDecoration(
                                  contentPadding:
                                  EdgeInsets.only(top: 10, left: 10),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: kPrimaryColor,
                                      )),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        width: 0.5,
                                      )),
                                  hintText: "Enter Contact no..",
                                  hintStyle: TextStyle(fontSize: 14),
                                  border: OutlineInputBorder()),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 2,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 10, bottom: 0),
                          child: Text(
                            "Email:",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w500),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10, right: 10,bottom: 3),
                          child: Container(
                            width: MediaQuery.of(context).size.width * 0.9,
                            child: TextFormField(
                              controller: emailcontroller,
                              onSaved: (newValue) => newValue!,
                              validator: (val) {
                                return RegExp(
                                    r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                    .hasMatch(val!)
                                    ? null
                                    : "Please enter a valid email";
                              },
                              cursorColor: kPrimaryColor,
                              decoration: InputDecoration(
                                  contentPadding:
                                  EdgeInsets.only(top: 10, left: 10),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        color: kPrimaryColor,
                                      )),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        width: 0.5,
                                      )),
                                  hintText: "Enter your email..",
                                  hintStyle: TextStyle(fontSize: 14),
                                  border: OutlineInputBorder()),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),

                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      );
    }

  void openWhatsapp (
      {required BuildContext context,
        // required String text,
        required String number}) async {
    var whatsapp = number; //+92xx enter like this
    var whatsappURlAndroid =
        "whatsapp://send?phone=" + whatsapp ;
            // + "&text=$text";
    // var whatsappURLIos = "https://wa.me/$whatsapp?text=${Uri.tryParse(text)}";
    if (Platform.isAndroid) {
      // for android phone only
      if (await canLaunchUrl(Uri.parse(whatsappURlAndroid))) {
        await launchUrl(Uri.parse(
          whatsappURlAndroid,
        ));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Whatsapp not installed")));
      }
    }
    // else {
    //   // ios , web
    //   if (await canLaunchUrl(Uri.parse(whatsappURLIos))) {
    //     await launchUrl(Uri.parse(whatsappURLIos));
    //   } else {
    //     ScaffoldMessenger.of(context).showSnackBar(
    //         const SnackBar(content: Text("Whatsapp not installed")));
    //   }
    // }
  }
  }

