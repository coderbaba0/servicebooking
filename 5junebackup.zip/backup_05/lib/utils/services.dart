import 'package:cloud_firestore/cloud_firestore.dart';

class DatabaseService {
  final String? uid;

  DatabaseService({this.uid});

  // reference for our collections
  final CollectionReference userCollection =
  FirebaseFirestore.instance.collection("user");
  final CollectionReference bookingCollection =
  FirebaseFirestore.instance.collection("bookings");
  final CollectionReference notificationCollection =
  FirebaseFirestore.instance.collection("notifications");
  // saving the userdata
  Future savingUserData(String mobile, String uid) async {
    return await userCollection.doc(uid).set({
      "mobile": mobile,
      "uid": uid,
      "bookings": [],
    });
  }
  Future saveNotifications(String body,String time, String service, String id,String token)async {
    return await userCollection.doc(uid).collection('notifications').add({
      "body": body,
      "time": time,
      "service":service,
      'id':id,
      'read':false,
      'token':token,
    });
  }
  //update read status
  Future updateNotifications(String docid)async {
    return await userCollection.doc(uid).collection('notifications').doc(docid).update({
      'read':true,
    });
  }
//get notifications
  // getting the chats
  getNotifications(String uid) async {
    return userCollection
        .doc(uid)
        .collection("notifications",)
        .orderBy("time")
        .snapshots();
  }

  getNotificationscount(String uid) async {
    return userCollection
         .doc(uid)
         .collection("notifications")
         .where('read', isEqualTo: false)
        .count().get();

    // .then(
    //       (res) =>  res.count,
    //   onError: (e) => print("Error completing: $e"),
    // );
  }
  //delete documents
  deletedoc(String uid)async{
    final WriteBatch _batch = FirebaseFirestore.instance.batch();

    QuerySnapshot _query = await userCollection
        .doc(uid)
        .collection("notifications").get();

    _query.docs.forEach((doc) {
      _batch.delete(userCollection
          .doc(uid)
          .collection("notifications").doc(doc.reference.id));
    });

    await _batch.commit();
  }
  //delete collection
  deletenotifications(String uid) {
    userCollection
        .doc(uid)
        .collection("notifications").snapshots().forEach((querySnapshot) {
      for (QueryDocumentSnapshot docSnapshot in querySnapshot.docs) {
        docSnapshot.reference.delete();
      }
    });
  }
  // getting user data
  Future gettingUserData(String mobile) async {
    QuerySnapshot snapshot =
    await userCollection.where("mobile", isEqualTo: mobile).get();
    return snapshot;
  }
  // get user bookings
  getUserbookings() async {
    return userCollection.doc(uid).snapshots();
  }

  // creating bookings
  Future createbookings(String mobile, String id, String servicename) async {
     await bookingCollection.doc(uid).set({
      "servicename": servicename,
      "admin": "${id}_$mobile",
      "users": [],
      "bookingId": "",
      "recentMessage": "",
      "recentMessageSender": "",
    });
    // update the users
    DocumentReference bookingDocumentReference =  bookingCollection.doc(uid);
    await bookingDocumentReference.update({
      "users": FieldValue.arrayUnion(["${uid}_$mobile"]),
      "bookingId": bookingDocumentReference.id,
    });
    DocumentReference userDocumentReference = userCollection.doc(id);
    return await userDocumentReference.update({
      "bookings":
      FieldValue.arrayUnion(["${bookingDocumentReference.id}_$servicename"])
    });
  }
  //booking delete
  deletebooking(String bookingId) async{
    bookingCollection.doc(bookingId).delete().then(
          (doc) => print("booking deleted"),
      onError: (e) => print("Error updating document $e"),
    );
  }
  // getting the chats
  getChats(String bookingid) async {
    return bookingCollection
        .doc(bookingid)
        .collection("messages")
        .orderBy("time")
        .snapshots();
  }
  // send message
  sendMessage(String bookingId, Map<String, dynamic> chatMessageData) async {
    bookingCollection.doc(bookingId).collection("messages").add(chatMessageData);
    bookingCollection.doc(bookingId).update({
      "recentMessage": chatMessageData['message'],
      "recentMessageSender": chatMessageData['sender'],
      "recentMessageTime": chatMessageData['time'].toString(),
    });
  }
}
