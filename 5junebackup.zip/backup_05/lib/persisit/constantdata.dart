
 import 'package:shared_preferences/shared_preferences.dart';

class Constant{
  static String usermobile = "";
  static String useremail = "";
  static String username = "";
 static String userId = "";
  // static List<Map<String, dynamic>> messagesForUI  = [];
  // static List<String> sharedPreferenceMessages = [];
  // static  SharedPreferences? sharedPreference;
}