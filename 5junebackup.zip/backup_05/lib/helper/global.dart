

import 'dart:convert';

import 'package:http/http.dart' as http;

import 'dart:async';

String baseUrl = "https://maintainance.coinymx.com/api/";
String imgUrl = "https://maintainance.coinymx.com/public/";
String localurl="http://192.168.1.6:9000/api/";
String imgUrl2 = "http://192.168.1.6:9000/";

// void sendPushMessage(var bookingdata,{required String body, required String title, required String token}) async {
//   try {
//     await http.post(
//       Uri.parse('https://fcm.googleapis.com/fcm/send'),
//       headers: <String, String>{
//         'Content-Type': 'application/json',
//         'Authorization':
//         'key=AAAADB4KFTg:APA91bEvM5SNQSW6uMOzwTf55zi7mMX33_cJAl0NNrsz_RdzRbLGrXX-rO78yLifC7r2r0wWZiwVyiZqf8Fc1GcmJkE-lkavC4uHwT13FymMihi_W4CUKVzcbMJsUkAvQ2Ec1yDbGPyb',
//       },
//       body: jsonEncode(
//         <String, dynamic>{
//           'notification': <String, dynamic>{
//             'body': body,
//             'title': title,
//           },
//           'priority': 'high',
//           'data': <String, dynamic>{
//             'click_action': 'FLUTTER_NOTIFICATION_CLICK',
//             'id': '1',
//             'bookingdata': bookingdata,
//             'status': 'done',
//
//           },
//           "to": token,
//         },
//       ),
//     );
//     print('done');
//   } catch (e) {
//     print("error push notification");
//   }
// }
