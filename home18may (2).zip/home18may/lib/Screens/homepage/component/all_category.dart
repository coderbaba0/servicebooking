
import 'package:book_services/constant/constui.dart';
import 'package:book_services/data_repo/categorydata.dart';
import 'package:book_services/helper/global.dart';
import 'package:flutter/material.dart';

class Allcategory extends StatefulWidget {
  const Allcategory({Key? key}) : super(key: key);
  @override
  State<Allcategory> createState() => _AllcategoryState();
}
class _AllcategoryState extends State<Allcategory> with SingleTickerProviderStateMixin{
  AnimationController? _animationController;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // Allcat();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white54,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.only(left:15.0,right:15,top:0,bottom:50),
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10)
              ),
              width:double.infinity,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(
                          Icons.cancel,
                          size: 30,
                          color: kPrimaryColor,
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 0,),
                  MediaQuery.removePadding(
                      context: context,
                      removeTop: true,
                      child: FutureBuilder<dynamic>(
                          future:Allcat(),
                          builder: (context, snapshot) {
                            if (snapshot.hasData) {
                              return GridView.builder(
                                  shrinkWrap: true,
                                  // scrollDirection: Axis.vertical,
                                  physics: const NeverScrollableScrollPhysics(),
                                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 4, mainAxisSpacing: 1),
                                  itemCount: snapshot.data.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    return InkWell(
                                      onTap: () {

                                      },
                                      child: Column(
                                        children: [
                                          Container(
                                              height: 50,
                                              width: 50,
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: kPrimaryColor.withOpacity(0.5),
                                                      width: 2),
                                                  image: DecorationImage(
                                                    image: NetworkImage(
                                                        imgUrl+snapshot.data![index]['icon']),
                                                    fit: BoxFit.cover,
                                                  ),
                                                  shape: BoxShape.circle)),
                                          const SizedBox(height: 5),
                                          Text(
                                            snapshot.data![index]['name'],
                                            // snapshot.data!.name,
                                            textAlign: TextAlign.center,
                                            maxLines: 3,
                                          )
                                        ],
                                      ),
                                    );
                                  });
                            }
                            else{
                              return Center(child: CircularProgressIndicator());
                            }
                          }
                      )
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
