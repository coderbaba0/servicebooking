import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;

import 'package:book_services/Screens/bookings/accepted_booking.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/data_repo/categorydata.dart';
import 'package:book_services/data_repo/homepageprovider.dart';
import 'package:book_services/helper/global.dart';
import 'package:book_services/size_config.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:book_services/models/All_category.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:book_services/Screens/services/all_services.dart';
import 'package:book_services/Screens/homepage/component/all_category.dart';

import 'package:book_services/Screens/services/bookings_step/service_details.dart';

class Body extends StatefulWidget {
  const Body({Key? key}) : super(key: key);
  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends State<Body> {
  int _current = 0;
  List<String> sliderimage = <String>[];
  var localimagelist = ['assets/images/1.png', 'assets/images/2.png','assets/images/fav.png'];
  late Future<AllCategory> Allcategory1;
  List<String> _assetNames = <String>[
    'https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/ubuntu.svg',
    'https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/alphachannel.svg',
    'https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/atom.svg',
  ];
  var colorlist = [
    <Color>[
      Color(0x13db1ff8),
      Color(0x8ff81f),
    ],
    <Color>[
      Color(0x1bf8b31f),
      Color(0x8ff81f),
    ],
    <Color>[
      Color(0x181fe6f8),
      Color(0x8ff81f),
    ],
    <Color>[
      Color(0x17be852e),
      Color(0x8ff81f),
    ],
  ];

  // get all categories
  @override
  void initState() {
    super.initState();
    // Allcat();
    // slider();
    // makeMultipleRequests();
  }

//get slider image
  Future<dynamic> slider() async {
    final response = await http.get(
      Uri.parse(localurl + 'crousel'),
    );
    var data = jsonDecode(response.body);
    // print(data);
    if (response.statusCode == 200) {
      for (var data3 in data) {
        if (data3['status'] == 'Active') {
          sliderimage.add(data3['image']);
        }
      }
      // print(sliderimage);
      return data;
    } else {
      throw Exception('Failed to load ');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0, right: 8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(height: getProportionateScreenHeight(1)),
              _SliderView(),
              SizedBox(height: getProportionateScreenWidth(8)),
              _serviceView(),
              SizedBox(height: getProportionateScreenWidth(5)),
              _offers(),
              SizedBox(height: getProportionateScreenWidth(8)),
              _bestservices(),
              SizedBox(height: getProportionateScreenWidth(8)),
              _Recommended(),
              SizedBox(height: getProportionateScreenWidth(10)),
              _serviceoffers(),
            ],
          ),
        ),
      ),
    );
  }

  _SliderView() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 10),
      FutureBuilder<dynamic>(
          future: slider(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Column(
                children: [
                  CarouselSlider(
                    options: CarouselOptions(
                      viewportFraction: 1.0,
                      autoPlay: true,
                      height: SizeConfig.screenHeight * 1 / 4,
                    ),
                    items: sliderimage.map((i) {
                      return Builder(
                        builder: (BuildContext context) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            margin: const EdgeInsets.symmetric(horizontal: 8.0),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              image: DecorationImage(
                                image: NetworkImage(imgUrl2 + '$i'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          );
                        },
                      );
                    }).toList(),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: sliderimage.map(
                          (i) {
                        int index = sliderimage.indexOf(i);
                        return Container(
                          width: 8.0,
                          height: 8.0,
                          margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _current == index
                                  ? kPrimaryColor
                                  : Color.fromRGBO(0, 0, 0, 0.4)),
                        );
                      },
                    ).toList(),
                  ),
                ],
              );
            } else {
              return Column(
                children: [
                  CarouselSlider(
                    options: CarouselOptions(
                        viewportFraction: 1.0,
                        autoPlay: true,
                        height: SizeConfig.screenHeight * 1 / 4,
                        onPageChanged: (index, reason) {
                          setState(() {
                            _current = index;
                          });
                        }),
                    items: localimagelist.map((i) {
                      return Builder(
                        builder: (BuildContext context) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            margin: const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Image.asset(
                              '$i',
                              fit: BoxFit.cover,
                            ),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                            ),
                          );
                        },
                      );
                    }).toList(),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: localimagelist.map(
                          (i) {
                        int index = localimagelist.indexOf(i);

                        return Container(
                          width: 8.0,
                          height: 8.0,
                          margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _current == index
                                  ? kPrimaryColor
                                  : Color.fromRGBO(0, 0, 0, 0.4)),
                        );
                      },
                    ).toList(),
                  ),
                ],
              );
            }
          }),
      // Row(
      //   mainAxisAlignment: MainAxisAlignment.center,
      //   children: localimagelist.map(
      //     (i) {
      //       int index = localimagelist.indexOf(i);
      //
      //       return Container(
      //         width: 8.0,
      //         height: 8.0,
      //         margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
      //         decoration: BoxDecoration(
      //             shape: BoxShape.circle,
      //             color: _current == index
      //                 ? Color.fromRGBO(0, 0, 0, 0.9)
      //                 : Color.fromRGBO(0, 0, 0, 0.4)),
      //       );
      //     },
      //   ).toList(),
      // ),
    ]);
  }

  _serviceView() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 10,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    'Services',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.start,
                  ),
                  InkWell(
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (_) => Allcategory(),
                      );
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(left: 0.0, right: 16.0),
                      child: Text(
                        "View All",
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: kPrimaryColor),
                        textAlign: TextAlign.start,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            MediaQuery.removePadding(
                context: context,
                removeTop: true,
                child: FutureBuilder<dynamic>(
                    future: Allcat(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return GridView.builder(
                            shrinkWrap: true,
                            // scrollDirection: Axis.vertical,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 4, mainAxisSpacing: 1),
                            itemCount: 4,
                            itemBuilder: (BuildContext context, int index) {
                              return InkWell(
                                onTap: () {},
                                child: Column(
                                  children: [
                                    Container(
                                        height: 50,
                                        width: 50,
                                        decoration: BoxDecoration(
                                            border: Border.all(
                                                color: kPrimaryColor
                                                    .withOpacity(1),
                                                width: 2),
                                            image: DecorationImage(
                                              image: NetworkImage(imgUrl +
                                                  snapshot.data![index]
                                                      ['icon']),
                                              fit: BoxFit.cover,
                                            ),
                                            shape: BoxShape.circle)),
                                    const SizedBox(height: 5),
                                    Text(
                                      snapshot.data![index]['name'],
                                      // snapshot.data!.name,
                                      style: TextStyle(fontSize: 12),
                                      textAlign: TextAlign.center,
                                      maxLines: 3,
                                    )
                                  ],
                                ),
                              );
                            });
                      } else {
                        return Center(child: CircularProgressIndicator());
                      }
                    })),
          ],
        ),
      ),
    );
  }

  _serviceoffers() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                'Services on discount',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
              InkWell(
                onTap: () {
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      AceeptedBookings.routeName, (route) => true);
                },
                child: const Padding(
                  padding: EdgeInsets.only(left: 0.0, right: 16.0),
                  child: Text(
                    "View All",
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: kPrimaryColor),
                    textAlign: TextAlign.start,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          width: SizeConfig.screenWidth * 0.95,
          height: SizeConfig.screenHeight * 0.35,
          child: ListView.builder(
            itemCount: 15,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, i) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(0, 15, 5, 5),
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0, left: 0.0),
                      child: SizedBox(
                        width: SizeConfig.screenWidth * 0.48,
                        height: SizeConfig.screenHeight * 0.35,
                        child: Card(
                          elevation: 2,
                          child: Column(
                            children: [
                              Expanded(
                                  child: Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(5),
                                              topRight: Radius.circular(5))))),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8.0,
                                      bottom: 10.0,
                                      right: 8.0,
                                      top: 0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          Navigator.of(context)
                                              .pushNamedAndRemoveUntil(
                                                  AceeptedBookings.routeName,
                                                  (route) => true);
                                        },
                                        child: Container(
                                          width: SizeConfig.screenWidth * 0.80,
                                          height:
                                              SizeConfig.screenHeight * 0.15,
                                          // color:Colors.orange.shade100,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: NetworkImage(
                                                  "https://picsum.photos/500/500/"),
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Home Cleaning",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black87,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      const SizedBox(height: 3),
                                      Row(
                                        children: const [
                                          Text(
                                            "AED 355",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.orange,
                                              fontWeight: FontWeight.w300,
                                              decoration:
                                                  TextDecoration.lineThrough,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Row(
                                        children: const [
                                          Text(
                                            "Now at : ",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.black87,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            "AED 255",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.orange,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 10),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const SizedBox(width: 15),
                                          InkWell(
                                            onTap: () {},
                                            child: Container(
                                              height: SizeConfig.screenHeight *
                                                  0.047,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      color: Colors.black45),
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: const Text(
                                                  "Book Now",
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Container(
                                              height: 20,
                                              width: 0.3,
                                              color: Colors.black45),
                                          InkWell(
                                            onTap: () {},
                                            child: Container(
                                                height:
                                                    SizeConfig.screenHeight *
                                                        0.05,
                                                width: SizeConfig.screenWidth *
                                                    0.10,
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            4)),
                                                child: const Center(
                                                  child: Icon(
                                                      Icons.favorite_border),
                                                )),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                        child: Container(
                            height: 35,
                            width: 70,
                            decoration: BoxDecoration(
                                color: kPrimaryColor.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(5)),
                            child: const Center(
                                child: Text(
                              "30% Off",
                            )))),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  _offers() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                'Services on discount',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AllServices(
                          title: 'All Services on discount',
                        ),
                      ));
                },
                child: const Padding(
                  padding: EdgeInsets.only(left: 0.0, right: 16.0),
                  child: Text(
                    "View All",
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: kPrimaryColor),
                    textAlign: TextAlign.start,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          width: SizeConfig.screenWidth * 0.95,
          height: SizeConfig.screenHeight * 0.35,
          child: ListView.builder(
            itemCount: 15,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, i) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(0, 15, 5, 5),
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0, left: 0.0),
                      child: SizedBox(
                        width: SizeConfig.screenWidth * 0.48,
                        height: SizeConfig.screenHeight * 0.35,
                        child: Card(
                          elevation: 2,
                          child: Column(
                            children: [
                              Expanded(
                                  child: Container(
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(5),
                                              topRight: Radius.circular(5))))),
                              Align(
                                alignment: Alignment.bottomLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 8.0,
                                      bottom: 10.0,
                                      right: 8.0,
                                      top: 0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      InkWell(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    ServiceDetails(
                                                  title: 'Home Cleaning',
                                                ),
                                              ));
                                        },
                                        child: Container(
                                          width: SizeConfig.screenWidth * 0.80,
                                          height:
                                              SizeConfig.screenHeight * 0.15,
                                          // color:Colors.orange.shade100,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: NetworkImage(
                                                  "https://picsum.photos/500/500/"),
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const Text(
                                        "Home Cleaning",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.black87,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      const SizedBox(height: 3),
                                      Row(
                                        children: const [
                                          Text(
                                            "AED 355",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: Colors.orange,
                                              fontWeight: FontWeight.w300,
                                              decoration:
                                                  TextDecoration.lineThrough,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 3),
                                      Row(
                                        children: const [
                                          Text(
                                            "Now at : ",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.black87,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Text(
                                            "AED 255",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.orange,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 10),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          const SizedBox(width: 15),
                                          InkWell(
                                            onTap: () {},
                                            child: Container(
                                              height: SizeConfig.screenHeight *
                                                  0.047,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      color: Colors.black45),
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: const Text(
                                                  "Book Now",
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Container(
                                              height: 20,
                                              width: 0.3,
                                              color: Colors.black45),
                                          InkWell(
                                            onTap: () {},
                                            child: Container(
                                                height:
                                                    SizeConfig.screenHeight *
                                                        0.05,
                                                width: SizeConfig.screenWidth *
                                                    0.10,
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            4)),
                                                child: const Center(
                                                  child: Icon(
                                                      Icons.favorite_border),
                                                )),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                        child: Container(
                            height: 35,
                            width: 70,
                            decoration: BoxDecoration(
                                color: kPrimaryColor.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(5)),
                            child: const Center(
                                child: Text(
                              "30% Off",
                            )))),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  _bestservices() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                'Best Services',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AllServices(
                          title: 'Best Services',
                        ),
                      ));
                },
                child: const Padding(
                  padding: EdgeInsets.only(left: 0.0, right: 18.0),
                  child: Text(
                    "View All",
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: kPrimaryColor),
                    textAlign: TextAlign.start,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          width: SizeConfig.screenWidth * 0.95,
          height: SizeConfig.screenHeight * 0.35,
          child: ListView.builder(
            itemCount: 15,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, i) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(0, 15, 0, 10),
                child: InkWell(
                  onTap: () {},
                  child: Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0, left: 0.0),
                        child: SizedBox(
                          width: SizeConfig.screenWidth * 0.48,
                          height: SizeConfig.screenHeight * 0.35,
                          child: Card(
                            elevation: 2,
                            child: Column(
                              children: [
                                Expanded(
                                    child: Container(
                                        decoration: const BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(5),
                                                topRight:
                                                    Radius.circular(5))))),
                                Align(
                                  alignment: Alignment.bottomLeft,
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 8.0,
                                        right: 8.0,
                                        bottom: 10.0,
                                        top: 0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          width: 500,
                                          height:
                                              SizeConfig.screenHeight * 0.15,
                                          // color:Colors.orange.shade100,
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: NetworkImage(
                                                  "https://picsum.photos/400/500/"),
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        ),
                                        const Text(
                                          "Plumbing Services",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.black87,
                                              fontWeight: FontWeight.w500),
                                        ),
                                        const SizedBox(height: 3),
                                        Row(
                                          children: const [
                                            Icon(
                                              Icons.star,
                                              color: Colors.orange,
                                              size: 15,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.orange,
                                              size: 15,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.orange,
                                              size: 15,
                                            ),
                                            Icon(
                                              Icons.star,
                                              color: Colors.orange,
                                              size: 15,
                                            ),
                                            Icon(
                                              Icons.star_half,
                                              color: Colors.orange,
                                              size: 15,
                                            ),
                                            Text(
                                              "4.5 (35)",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.orange,
                                                fontWeight: FontWeight.w300,
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 3),
                                        Row(
                                          children: const [
                                            Text(
                                              "Start from : ",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              "AED 255",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.orange,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 10),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            const SizedBox(width: 15),
                                            Container(
                                              height: SizeConfig.screenHeight *
                                                  0.047,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      color: Colors.black45),
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: const Text(
                                                  "Book Now",
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            Container(
                                                height: 20,
                                                width: 0.3,
                                                color: Colors.black45),
                                            Container(
                                                height:
                                                    SizeConfig.screenHeight *
                                                        0.05,
                                                width: SizeConfig.screenWidth *
                                                    0.10,
                                                decoration: BoxDecoration(
                                                    //

                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            4)),
                                                child: const Center(
                                                  child: Icon(
                                                      Icons.favorite_border),
                                                )),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  _Recommended() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(
                'Recommended ',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.start,
              ),
            ],
          ),
        ),
        Container(
          child: Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 10,
            ),
            child: MediaQuery.removePadding(
              context: context,
              removeTop: true,
              child: GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 0.5,
                  ),
                  itemCount: 4,
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {},
                      child: Card(
                        elevation: 2,
                        child: Container(
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Stack(
                                children: [
                                  Align(
                                    alignment: AlignmentDirectional.topStart,
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              'Fuse Replacement',
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 2,
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                              'AED 80 -',
                                              style: TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              '1 Hour',
                                              style: TextStyle(fontSize: 12),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional.bottomStart,
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.star_half,
                                          color: Colors.orange,
                                          size: 15,
                                        ),
                                        Text('4.2 (55)'),
                                      ],
                                    ),
                                  ),
                                  Align(
                                      alignment: AlignmentDirectional.bottomEnd,
                                      child: Container(
                                          height:
                                              SizeConfig.screenHeight * 0.12,
                                          width: SizeConfig.screenWidth * 0.25,
                                          child: Stack(children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  bottom: 20.0, right: 15.0),
                                              child: Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: SvgPicture.network(
                                                  getRandomElement(_assetNames),
                                                  height: 50,
                                                  width: 50,
                                                ),
                                              ),
                                            ),
                                          ]),
                                          decoration: BoxDecoration(
                                              borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(60)),
                                              gradient: LinearGradient(
                                                tileMode: TileMode.clamp,
                                                colors:
                                                    getRandomElement(colorlist),
                                                begin: Alignment.topCenter,
                                                end: Alignment.bottomCenter,
                                              ),
                                              shape: BoxShape.rectangle))),
                                ],
                              ),
                            ),
                            height: SizeConfig.screenHeight * 0.2,
                            width: SizeConfig.screenWidth * 0.43,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.black45),
                                borderRadius: BorderRadius.circular(5),
                                gradient: LinearGradient(
                                  tileMode: TileMode.clamp,
                                  colors: getRandomElement(colorlist),
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                                shape: BoxShape.rectangle)),
                      ),
                    );
                  }),
            ),
          ),
        ),
      ],
    );
  }

  T getRandomElement<T>(List<T> list) {
    final random = new Random();
    var i = random.nextInt(list.length);
    return list[i];
  }
}
