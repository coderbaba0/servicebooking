import 'package:book_services/Screens/homepage/component/body.dart';
import 'package:book_services/Screens/homepage/component/notifications.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  static String routeName = "/home";
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: AppBar(
          automaticallyImplyLeading: false,
          elevation: 2,
          backgroundColor: kPrimaryColor,
          toolbarHeight: SizeConfig.screenHeight * 0.2,
          centerTitle: true,
          title: Padding(
            padding: const EdgeInsets.only(top: 25.0),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      SizedBox(
                        width: SizeConfig.screenWidth * 0.80,
                        child: Container(
                          height: 40,
                          decoration: BoxDecoration(
                            // ignore: prefer_const_constructors
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: TextFormField(
                            //
                            textAlignVertical: TextAlignVertical.center,
                            style: TextStyle(
                                fontSize: 14.0,
                                height: 1.0,
                                color: Colors.white),
                            onTap: () {},
                            cursorColor: Colors.white,
                            cursorHeight: 15,
                            keyboardType: TextInputType.text,
                            showCursor: true,
                            // onSaved:,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Enter Query";
                              }
                              return null;
                            },
                            decoration: InputDecoration(
                              prefix: Padding(
                                padding: EdgeInsets.only(
                                  top: 30,
                                ),
                              ),
                              prefixIcon: Padding(
                                padding: const EdgeInsets.only(left: 0.0),
                                child: Icon(
                                  Icons.do_not_disturb_on_total_silence_sharp,
                                  color: Colors.transparent,
                                ),
                              ),
                              prefixIconConstraints:
                                  BoxConstraints(maxWidth: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide(color: Colors.white38),
                              ),
                              disabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide.none,
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide(color: Colors.white),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                borderSide: BorderSide(color: Colors.red),
                              ),
                              labelStyle: const TextStyle(
                                color: kPrimaryColor,
                              ),
                              focusColor: kTextColorSecondary.withOpacity(0.2),
                              hintText: "Search Services..",
                              fillColor: Colors.white54.withOpacity(0.3),
                              filled: true,
                              suffixIcon: const Icon(
                                Icons.camera_alt_outlined,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Stack(children: [
                        IconButton(
                          visualDensity: const VisualDensity(
                              horizontal: -4.0, vertical: -4.0),
                          icon: const Icon(
                            Icons.notifications_active_outlined,
                            color: Colors.white,
                            size: 28,
                          ),
                          onPressed: () {
                            Navigator.of(context).pushNamedAndRemoveUntil(
                                Notifications.routeName, (route) => true);
                          },
                        ),
                        Positioned(
                          left: 22,
                          top: 5,
                          child: CircleAvatar(
                            radius: 8,
                            backgroundColor: Colors.red,
                            child: Text(
                              "1",
                              style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.location_on,
                        color: Colors.black54,
                        size: 15,
                      ),
                      Text(
                        'Sector 3 , Noida',
                        // box!.get("Address"),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        style: const TextStyle(
                            color: Colors.black54, fontSize: 14),
                      ),
                      IconButton(
                          onPressed: () {}, icon: Icon(Icons.arrow_drop_down)),
                      // Text(
                      //   'Edit',
                      //   // box!.get("Address"),
                      //   overflow: TextOverflow.ellipsis,
                      //   maxLines: 1,
                      //   style: const TextStyle(color: Colors
                      //       .black54, fontSize: 14),
                      // ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),

      body: const Body(),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.transparent,
        splashColor: Colors.transparent,
        focusColor: Colors.transparent,
        child: Center(
          child: Column(
            children: [
              CircleAvatar(
                  radius: 25,
                  backgroundColor: kPrimaryColor.withOpacity(0.4),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: Image.asset(
                      'assets/images/WhatsApp.png',
                      height: 40,
                      width: 40,
                    ),
                  )),
              // Text('Send',style: TextStyle(color: Colors.green,fontSize: 15,fontWeight: FontWeight.w500),)
            ],
          ),
        ),
        elevation: 0,
        onPressed: () {},
        tooltip: 'Send',
      ),

      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.home),
    );
  }
}
