import 'package:book_services/Screens/services/bookings_step/sucess.dart';
import 'package:book_services/Screens/services/bookings_step/failed.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/showprogress.dart';
import 'package:book_services/size_config.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_places_picker_refractored/google_maps_places_picker_refractored.dart';

List<String> list = <String>['Choose Category', 'Two', 'Three', 'Four'];

class ServiceDetails extends StatefulWidget {
  static String routeName = "/servicedetails";
  var title;
  static const kInitialPosition = LatLng(-33.8567844, 151.213108);
  ServiceDetails({Key? key, @required this.title}) : super(key: key);
  @override
  State<ServiceDetails> createState() => _ServiceDetailsState();
}

class _ServiceDetailsState extends State<ServiceDetails>
    with TickerProviderStateMixin {
  // for choose payment method
  var _value = 1;
  var _select = 1;
  var _subtotal = 486, _vat = 5 / 100, _total = 0;
  // for location
  PickResult? selectedPlace;

  // for schedule
  int? selectedIndex;
  List<String> _time = [
    '12:00 AM-01:00AM',
    '01:00 AM-02:00AM',
    '02:00 AM-03:00AM',
    '03:00 AM-04:00AM',
    '04:00 AM-05:00AM',
    '05:00 AM-06:00AM',
    '06:00 AM-07:00AM',
    '07:00 AM-08:00AM',
    '08:00 AM-09:00AM',
    '09:00 AM-10:00AM',
    '10:00 AM-11:00AM',
    '11:00 AM-12:00PM',
    '12:00 PM-01:00PM',
    '01:00 PM-02:00PM',
    '02:00 PM-03:00PM',
    '03:00 PM-04:00PM',
    '04:00 PM-05:00PM',
    '05:00 PM-06:00PM',
    '06:00 PM-07:00PM',
    '07:00 PM-08:00PM',
    '08:00 PM-09:00PM',
    '09:00 PM-10:00PM',
    '10:00 PM-11:00PM',
    '11:00 PM-12:00PM'
  ];
  List<String> _time2 = [
    '12:00 PM-01:00PM',
    '01:00 PM-02:00PM',
    '02:00 PM-03:00PM',
    '03:00 PM-04:00PM',
    '04:00 PM-05:00PM',
    '05:00 PM-06:00PM',
    '06:00 PM-07:00PM',
    '07:00 PM-08:00PM',
    '08:00 PM-09:00PM',
    '09:00 PM-10:00PM',
    '10:00 PM-11:00PM',
    '11:00 PM-12:00PM'
  ];

  DateTime _selectedDate = DateTime.now();
  List<DateTime> _calendarDays = [];
  final List<String> daysOfWeek = [
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun'
  ];

  void initState() {
    super.initState();

    _calendarDays = _generateCalendar(_selectedDate.year, _selectedDate.month);
  }

  //genrate cal
  List<DateTime> _generateCalendar(int year, int month) {
    List<DateTime> daysInMonth = [];
    DateTime date = DateTime(year, month, 1);
    int firstWeekdayOfMonth = date.weekday;
    int daysBefore = (firstWeekdayOfMonth - 1) % 7;
    DateTime startDate = date.subtract(Duration(days: daysBefore));
    for (int i = 0; i < 42; i++) {
      daysInMonth.add(startDate.add(Duration(days: i)));
    }

    return daysInMonth;
  }

  // check month

//
  String dropdownValue = list.first;
  TabController? tabController2;
  var _counter = 1;
  void _increamentcounter() {
    setState(() {
      _counter++;
    });
  }
  void _decreamentcounter() {
    setState(() {
      if (_counter < 2) {
        return;
      }

      _counter--;
    });
  }
  int activeStep = 0;
  @override
  Widget build(BuildContext context) {
    TabController tabController = TabController(length: 2, vsync: this);
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 50,
        elevation: 2,
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          widget.title,
          style: TextStyle(
            color: Colors.white,
            fontSize: 15,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: false,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(2)),
                Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: EasyStepper(
                            showLoadingAnimation: false,
                            activeStepIconColor: kPrimaryColor,
                            lineColor: kPrimaryColor,
                            stepRadius: 20,
                            lineType: LineType.dotted,
                            activeStep: activeStep,
                            direction: Axis.horizontal,
                            activeStepTextColor: kPrimaryColor,
                            finishedStepTextColor: kPrimaryColor,
                            activeStepBorderColor: kPrimaryColor,
                            unreachedStepIconColor: Colors.white,
                            unreachedStepBorderColor: Colors.black54,
                            finishedStepBackgroundColor: kPrimaryColor,
                            unreachedStepBackgroundColor: Colors.black12,
                            showTitle: true,
                            onStepReached: (index) => setState(() {
                              activeStep = index;
                              tabController2 = tabController;
                            }),
                            steps: const [
                              EasyStep(
                                icon: Icon(Icons.remove_red_eye_outlined),
                                title: 'View',
                                activeIcon: Icon(Icons.done),
                              ),
                              EasyStep(
                                icon: Icon(Icons.calendar_month_outlined),
                                activeIcon: Icon(Icons.done),
                                title: 'Schedule',
                              ),
                              EasyStep(
                                icon: Icon(Icons.location_on),
                                activeIcon: Icon(Icons.done),
                                title: 'Location',
                              ),
                              EasyStep(
                                icon: Icon(Icons.checklist),
                                activeIcon: Icon(Icons.done),
                                title: 'Confirmation',
                              ),
                              EasyStep(
                                icon: Icon(Icons.money),
                                activeIcon: Icon(Icons.done),
                                title: 'Payment',
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: getProportionateScreenWidth(1)),
                _body(),

              ],
            ),
          ),
        ),
      ),
    );
  }
  _body() {
    if (activeStep == 1) {
      return Column(children: [
        Container(
          height: 20,
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(
                  Icons.arrow_back_ios,
                  size: 20,
                  color: kPrimaryColor,
                ),
                onPressed: () {
                  setState(() {
                    _selectedDate = DateTime(
                        _selectedDate.year, _selectedDate.month - 1, 1);
                    _calendarDays = _generateCalendar(
                        _selectedDate.year, _selectedDate.month);
                  });
                },
              ),
              Text(
                (DateFormat('MMMM, yyyy').format(_selectedDate)),
                // '${_selectedDate.year} ${_selectedDate.month}',
                style: TextStyle(fontSize: 16),
              ),
              IconButton(
                icon: Icon(
                  Icons.arrow_forward_ios,
                  size: 20,
                  color: kPrimaryColor,
                ),
                onPressed: () {
                  setState(() {
                    _selectedDate = DateTime(
                        _selectedDate.year, _selectedDate.month + 1, 1);
                    _calendarDays = _generateCalendar(
                        _selectedDate.year, _selectedDate.month);
                  });
                },
              ),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 15),
          child: Row(
            children: daysOfWeek.map((day) {
              return Expanded(
                child: Container(
                  alignment: Alignment.center,
                  child: Text(
                    day,
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        GridView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            physics: ScrollPhysics(),
            padding: EdgeInsets.all(8),
            itemCount: _calendarDays.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
            ),
            itemBuilder: (context, index) {
              DateTime date = _calendarDays[index];
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedDate = date;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _selectedDate == date
                        ? kPrimaryColor
                        : kPrimaryColor.withOpacity(0.2),
                  ),
                  child: Center(
                    child: Text(
                      '${date.day}',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: _selectedDate == date ? Colors.white : null,
                      ),
                    ),
                  ),
                ),
              );
            }),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            'Choose Time Slot:',
            style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
          ),
        ),
        Divider(
          color: kPrimaryColor,
          thickness: 1,
          indent: 50,
          endIndent: 50,
        ),
        SizedBox(
          // Horizontal ListView
          height: 50,
          child: ListView.builder(
            itemCount: _time.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 2.0, right: 2.0),
                child: ChoiceChip(
                  selectedColor: kPrimaryColor,
                  backgroundColor: kPrimaryColor.withOpacity(0.2),
                  label: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(_time[index]),
                  ),
                  labelStyle: TextStyle(color: Colors.black),
                  selected: selectedIndex == index,
                  onSelected: (bool value) {
                    setState(() {
                      selectedIndex = index;
                    });
                  },
                ),
              );
            },
          ),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          // Horizontal ListView
          height: 50,
          child: ListView.builder(
            reverse: true,
            itemCount: _time.length,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 2.0, right: 2.0),
                child: ChoiceChip(
                  selectedColor: kPrimaryColor,
                  backgroundColor: kPrimaryColor.withOpacity(0.2),
                  label: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(_time[index]),
                  ),
                  labelStyle: TextStyle(color: Colors.black),
                  selected: selectedIndex == index,
                  onSelected: (bool value) {
                    setState(() {
                      selectedIndex = index;
                    });
                  },
                ),
              );
            },
          ),
        ),
        SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.only(left: 5, right: 5),
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.black12.withOpacity(0.05)),
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 18.0, right: 18, top: 5, bottom: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Price : AED 15",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        fontFamily: "Inter"),
                  ),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: kPrimaryColor,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30))),
                      onPressed: () {
                        setState(() {
                          activeStep = activeStep + 1;
                        });
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(
                          "Continue",
                          style: TextStyle(fontSize: 16),
                        ),
                      ))
                ],
              ),
            ),
          ),
        ),
      ]);
    } else if (activeStep == 2) {
      return Padding(
        padding: const EdgeInsets.only(left: 0.0, right: 0.0, bottom: 8),
        child: Column(
          children: [
            SizedBox(
              height: 1,
            ),
            Container(
              height: MediaQuery.of(context).size.height * 0.30,
              width: double.infinity,
              decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: kPrimaryColor,
                  )),
              child: PlacePicker(
                apiKey: 'AIzaSyAbN1uulBVvR6GkHkJUniPC9nkQ7yYcXAo',
                initialPosition: ServiceDetails.kInitialPosition,
                useCurrentLocation: true,
                selectInitialPosition: true,
                height: 40.0,
                usePlaceDetailSearch: true,
                onPlacePicked: (result) {
                  selectedPlace = result;
                  Navigator.of(context).pop();
                  setState(() {});
                },
                //forceSearchOnZoomChanged: true,
                automaticallyImplyAppBarLeading: false,
                //autocompleteLanguage: "ko",
                //region: 'au',
                //selectInitialPosition: true,
                // selectedPlaceWidgetBuilder: (_, selectedPlace, state, isSearchBarFocused) {
                //   print("state: $state, isSearchBarFocused: $isSearchBarFocused");
                //   return isSearchBarFocused
                //       ? Container()
                //       : FloatingCard(
                //           bottomPosition: 0.0, // MediaQuery.of(context) will cause rebuild. See MediaQuery document for the information.
                //           leftPosition: 0.0,
                //           rightPosition: 0.0,
                //           width: 500,
                //           borderRadius: BorderRadius.circular(12.0),
                //           child: state == SearchingState.Searching
                //               ? Center(child: CircularProgressIndicator())
                //               : RaisedButton(
                //                   child: Text("Pick Here"),
                //                   onPressed: () {
                //                     // IMPORTANT: You MUST manage selectedPlace data yourself as using this build will not invoke onPlacePicker as
                //                     //            this will override default 'Select here' Button.
                //                     print("do something with [selectedPlace] data");
                //                     Navigator.of(context).pop();
                //                   },
                //                 ),
                //         );
                // },
                // pinBuilder: (context, state) {
                //   if (state == PinState.Idle) {
                //     return Icon(Icons.favorite_border);
                //   } else {
                //     return Icon(Icons.favorite);
                //   }
                // },
              ),
            ),
            SizedBox(
              height: 0,
            ),
            Container(
              width: double.infinity,
              child: Card(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 10.0, left: 10.0, top: 10),
                      child: Container(
                        height: 45,
                        width: double.infinity,
                        child: Container(
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                                color: kPrimaryColor.withOpacity(0.5),
                                borderRadius: BorderRadius.circular(
                                  30,
                                )),
                            child: TabBar(
                              indicatorColor: Colors.transparent,
                              indicator: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                      30), // Creates border
                                  color: kPrimaryColor),
                              controller: tabController2,
                              isScrollable: true,
                              labelPadding:
                              EdgeInsets.symmetric(horizontal: 60),
                              tabs: [
                                Tab(
                                  child: Text(
                                    "Home",
                                    style: TextStyle(
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                Tab(
                                  child: Text(
                                    "Office",
                                    style: TextStyle(
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ],
                            )),
                      ),
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.only(left: 10, top: 10, bottom: 10),
                      child: Text(
                        "Address:",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.05,
                        width: double.infinity,
                        child: TextFormField(
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                              contentPadding:
                              EdgeInsets.only(top: 10, left: 10),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: kPrimaryColor,
                                  )),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 0.5,
                                  )),
                              hintText: "Enter your correct address..",
                              hintStyle: TextStyle(fontSize: 14),
                              border: OutlineInputBorder()),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 2,
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.only(left: 10, top: 10, bottom: 10),
                      child: Text(
                        "Contact Name:",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.05,
                        width: MediaQuery.of(context).size.width * 0.9,
                        child: TextFormField(
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                              contentPadding:
                              EdgeInsets.only(top: 10, left: 10),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: kPrimaryColor,
                                  )),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 0.5,
                                  )),
                              hintText: "Enter your name..",
                              hintStyle: TextStyle(fontSize: 14),
                              border: OutlineInputBorder()),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 2,
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.only(left: 10, top: 10, bottom: 10),
                      child: Text(
                        "Contact No :",
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Container(
                        height: MediaQuery.of(context).size.height * 0.05,
                        width: double.infinity,
                        child: TextFormField(
                          keyboardType: TextInputType.phone,
                          cursorColor: kPrimaryColor,
                          decoration: InputDecoration(
                              contentPadding:
                              EdgeInsets.only(top: 10, left: 10),
                              focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: kPrimaryColor,
                                  )),
                              enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 0.5,
                                  )),
                              hintText: "Enter Contact no..",
                              hintStyle: TextStyle(fontSize: 14),
                              border: OutlineInputBorder()),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 5, right: 5),
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.black12.withOpacity(0.05)),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 18.0, right: 18, top: 5, bottom: 5),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Price : AED 15",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: "Inter"),
                              ),
                              ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      primary: kPrimaryColor,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(30))),
                                  onPressed: () {
                                    setState(() {
                                      activeStep = activeStep + 1;
                                    });
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: Text(
                                      "Save",
                                      style: TextStyle(fontSize: 16),
                                    ),
                                  ))
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    } else if (activeStep == 3) {
      return Card(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Confirm you Details: ',
                      style:
                      TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            Text('Service Details: ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ListTile(
                leading: Image.network('https://picsum.photos/500/300/',
                    height: 50, width: 50),
                title: Text('Home Cleaning'),
                subtitle: Text('AED 80'),
                trailing: TextButton.icon(
                    label: Text('Edit'),
                    style: TextButton.styleFrom(
                      primary: kPrimaryColor,
                    ),
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      setState(() {
                        activeStep = activeStep - 3;
                      });
                    })),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            Text('Schedule Details : ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ListTile(
              title: Text('Date : 10 April 2023'),
              subtitle: Text('10:00 -01:00 PM'),
              trailing: TextButton.icon(
                  label: Text('Edit'),
                  style: TextButton.styleFrom(
                    primary: kPrimaryColor,
                  ),
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    setState(() {
                      activeStep = activeStep - 2;
                    });
                  }),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            Text('Address Details : ',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ListTile(
              title: Text('Address : '),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Sector 3, Noida Pin 201301'),
                  Text('Ramesh Kumar'),
                  Text('9158632585')
                ],
              ),
              trailing: TextButton.icon(
                  label: Text('Edit'),
                  style: TextButton.styleFrom(
                    primary: kPrimaryColor,
                  ),
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    setState(() {
                      activeStep = activeStep - 1;
                    });
                  }),
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              indent: 20,
              endIndent: 20,
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.only(left: 15, right: 15, bottom: 30),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.black12.withOpacity(0.05)),
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 18.0, right: 18, top: 5, bottom: 5),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Price : AED 15",
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: "Inter"),
                      ),
                      ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              primary: kPrimaryColor,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30))),
                          onPressed: () {
                            setState(() {
                              activeStep = activeStep + 1;
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Text(
                              "Checkout",
                              style: TextStyle(fontSize: 16),
                            ),
                          ))
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    } else if (activeStep == 4) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('Choose payment Method : ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),

              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Radio(
                          activeColor: kPrimaryColor,
                          value: 1,
                          groupValue: _value,
                          onChanged: (value) {
                            setState(() {
                              _value = value!;
                            });
                          }),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Pay with Google",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height * 0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Radio(
                          activeColor: kPrimaryColor,
                          value: 2,
                          groupValue: _value,
                          onChanged: (value) {
                            setState(() {
                              _value = value!;
                            });
                          }),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          "Pay with Stripe",
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height*0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Radio(

                          activeColor: kPrimaryColor,
                          value: 3, groupValue: _value, onChanged: (value){
                        setState(() {
                          _value= value!;
                        });
                      }),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text("Pay on Cash",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w500,fontFamily: "Inter"),),
                      ),

                    ],

                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: Container(
                  height: MediaQuery.of(context).size.height*0.1,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey)
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Radio(

                          activeColor: kPrimaryColor,
                          value: 4, groupValue: _value, onChanged: (value){
                        setState(() {
                          _value= value!;
                        });
                      }),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text("Pay with Crypto",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w500,fontFamily: "Inter"),),
                      ),


                    ],

                  ),
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.only(left: 15, right: 15, bottom: 30),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black12.withOpacity(0.05)),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 18.0, right: 18, top: 5, bottom: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                        ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: kPrimaryColor,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            onPressed: () {
                              bool _orderdone = true;

                              Constants.showProgressDialog(context, 'Please wait..' );
                              showDialog(
                                barrierDismissible: false,
                                context: context,
                                builder: (_) => _orderdone? Sucess(): Failed(),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Text(
                                "Checkout",
                                style: TextStyle(fontSize: 16),
                              ),
                            ))
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    } else {
      return Column(
        children: [
          Container(
            // width: MediaQuery.of(context).size.width * 0.9,
            // height: MediaQuery.of(context).size.height * 0.17,
              child: CarouselSlider(
                options: CarouselOptions(
                  viewportFraction: 1,
                  autoPlay: true,
                  height: SizeConfig.screenHeight * 1 / 4.5,
                ),
                items: [1, 2, 3, 4, 5].map((i) {
                  return Builder(
                    builder: (BuildContext context) {
                      return Stack(children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.symmetric(horizontal: 5.0),
                          decoration: BoxDecoration(
                            border: Border.all(width: 1, color: kPrimaryColor),
                            borderRadius: BorderRadius.circular(5),
                            image: DecorationImage(
                              image: NetworkImage("https://picsum.photos/500/300/"),
                              fit: BoxFit.cover,
                            ),
                          ),
                          // child: Center(
                          //   child: Text(
                          //     'Image $i',
                          //   ),
                          // )
                        ),
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(50),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Text(
                                  'Description : $i',
                                ),
                              ),
                            ),
                          ),
                        )
                      ]);
                    },
                  );
                }).toList(),
              )),
          SizedBox(
            height: 15,
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ExpansionTile(
                    collapsedTextColor: kPrimaryColor,
                    collapsedIconColor: kPrimaryColor,
                    textColor: kPrimaryColor,
                    iconColor: kPrimaryColor,
                    childrenPadding: EdgeInsets.only(
                        left: 10, right: 10, top: 0, bottom: 10),
                    title: Text(
                      'Service Details',
                      style: TextStyle(
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                      ),
                    ),
                    // Contents
                    children: [
                      Text(
                          'Home cleaning  service offered by home service provider on the minimal rate you can book your service just on single click.')
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 10, left: 15),
                    child: Text(
                      "Select your issue :",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 10, right: 15, top: 15),
                    width: double.infinity,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.black12.withOpacity(0.03)),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton(
                        icon: Icon(
                          Icons.arrow_drop_down_sharp,
                          size: 30,
                        ),
                        onChanged: (String? newvalue) {
                          setState(() {
                            dropdownValue = newvalue!;
                          });
                        },
                        value: dropdownValue,
                        items:
                        list.map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem(
                            value: value,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                value,
                                style: TextStyle(fontSize: 14),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0, bottom: 10),
                    child: Text(
                      "Numbers of hours needed ?",
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 10.0, right: 10.0, top: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 17,
                              backgroundColor: Colors.red,
                              child: Center(
                                child: IconButton(
                                    onPressed: () {
                                      _increamentcounter();
                                    },
                                    icon: Icon(
                                      Icons.add,
                                      size: 17,
                                      color: Colors.white,
                                    )),
                              ),
                            ),
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20),
                              child: Text(
                                "$_counter",
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                            CircleAvatar(
                                radius: 17,
                                backgroundColor: Colors.green,
                                child: Center(
                                  child: IconButton(
                                      onPressed: () {
                                        _decreamentcounter();
                                      },
                                      icon: Icon(
                                        Icons.remove,
                                        color: Colors.white,
                                        size: 17,
                                      )),
                                ))
                          ],
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 10.0, bottom: 20, top: 5),
                    child: Text(
                      "Need Related materials ?",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            primary: kPrimaryColor),
                        onPressed: () {},
                        child: Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Text(
                            "Yes",
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)),
                              primary: Colors.white),
                          onPressed: () {},
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text(
                              "No",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 5, right: 5),
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.black12.withOpacity(0.05)),
                      child: Padding(
                        padding: const EdgeInsets.only(
                            left: 18.0, right: 18, top: 5, bottom: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Price : AED 15",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: "Inter"),
                            ),
                            ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    primary: kPrimaryColor,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(30))),
                                onPressed: () {
                                  setState(() {
                                    activeStep = activeStep + 1;
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Text(
                                    "Book Now",
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ))
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      );
    }
  }

  // for payment method page

  Future _showbottom() {
    return showModalBottomSheet(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
        context: (context),
        builder: (BuildContext context) {
          return SizedBox(
            height: 400,
            child: Center(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 50, left: 40),
                    child: Text(
                      "Order Summary",
                      style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.w500,
                          fontFamily: "Inter"),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Text(
                          "SUBTOTAL",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Text(
                          _subtotal.toString(),
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Inter"),
                        ),
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 40, top: 10),
                        child: Text(
                          "VAT 5%",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Inter"),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Text(
                          (_vat * _subtotal).toDouble().toString(),
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Inter"),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Divider(
                    thickness: 1.5,
                    color: Colors.grey,
                    indent: 10,
                    endIndent: 10,
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: Text(
                          "TOTAL",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Inter"),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 30),
                        child: Text(
                          (_subtotal + _vat * _subtotal).toDouble().toString(),
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              fontFamily: "Inter"),
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 40,
                  ),
                  Center(
                    child: Container(
                      height: 60,
                      width: MediaQuery.of(context).size.width * 0.8,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.white, width: 3)),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: kPrimaryColor,
                        ),
                        onPressed: () {},
                        child: Text(
                          "Pay Now",
                          style: TextStyle(fontSize: 25, color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
