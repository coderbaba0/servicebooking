import 'package:book_services/Screens/Register/RegisterScreen.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class WalkthroughScreen extends StatefulWidget {
  static String routeName = "/walkthrough";

  const WalkthroughScreen({Key? key}) : super(key: key);
  @override
  State<WalkthroughScreen> createState() => _WalkthroughScreenState();
}
class _WalkthroughScreenState extends State<WalkthroughScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[
              Color.fromARGB(255, 83, 217, 193),
              Color(0xae2a5e52),
            ],
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
          ),
        ),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RichText(
                      text: TextSpan(children: [
                    TextSpan(
                        text: 'All Home services on \n Your ',
                        style: TextStyle(fontSize: 25,fontFamily: 'Inter',    shadows: [
                          Shadow(
                            blurRadius: 1.0, // shadow blur
                            color: Colors.black, // shadow color
                            offset:
                            Offset(1.0, 1.0), // how much shadow will be shown
                          ),
                        ], )),
                    TextSpan(
                        text: ' Fingertips.',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 28,
                            fontFamily: 'Inter',
                            color: Color.fromRGBO(
                                12, 12, 12, 0.6588235294117647))),
                  ]
                      )
                  ),
                ],
              ),
            ),
            SizedBox(height: 20,),
            Column(children: [
              CircleAvatar(
                radius: MediaQuery.of(context).size.height * 0.18,
                backgroundColor: Color.fromARGB(24, 255, 255, 255),
                child: Padding(
                  padding: const EdgeInsets.only(left:10.0),
                  child: Lottie.asset("assets/images/walkthrough.json",height: 300,width: 300),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    InkWell(
                      onTap:(){
                        Navigator.of(context).pushNamed(
                            RegisterScreen.routeName,);
    },
                      child: CircleAvatar(
                        radius: 30,
                        backgroundColor: Color.fromARGB(39, 255, 255, 255),
                        child:IconButton(icon: Icon(Icons.keyboard_arrow_right,color: Colors.white,size: 30,), onPressed: () { Navigator.of(context).pushNamedAndRemoveUntil(
                            RegisterScreen.routeName, (route) => true); },)
                      ),
                    ),
                    Text(
                      "Next",
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: "Inter",
                          color: Colors.white),
                    ),
                  ],
                ),
              ),
            ])
          ],
        ),
      ),
    );
  }
}
