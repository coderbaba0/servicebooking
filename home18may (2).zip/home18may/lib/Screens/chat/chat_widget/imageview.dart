import 'package:book_services/constant/constui.dart';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';

class FullImageView extends StatelessWidget {
  final String url;
  const FullImageView({Key? key, required this.url}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
        toolbarHeight: 50,
        title: Text(
          'Image View',
          style: TextStyle(
              fontSize: 16,
              fontFamily: "Poppins",
              fontWeight: FontWeight.normal),
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
          ),
        ),
        leading: IconButton(
          onPressed: () => Navigator.pop(context), icon: Icon(
          Icons.arrow_back,
          size: 16,
        ),),
      ),
      body: PhotoView(
        enableRotation: true,
        imageProvider: NetworkImage(url),
      ),
    );
  }
}