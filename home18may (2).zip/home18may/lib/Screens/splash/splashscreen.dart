import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/Screens/walkthrough/WalkthroughScreen.dart';
import 'package:book_services/persisit/helperfunctions.dart';
import 'package:flutter/material.dart';
import 'dart:async';

import '../../persisit/constantdata.dart';

class SplashScreen extends StatefulWidget {
  static String routeName = "/splash";
  const SplashScreen({Key? key}) : super(key: key);
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  bool _isSignedIn = false;


  @override
  void initState() {
    super.initState();
    getadminLoggedInStatus();
  }
  getadminLoggedInStatus() async {
    await HelperFunctions.getUserLoggedInStatus().then((value) {
      if (value != null) {
        setState(() {
          _isSignedIn = value;
        });
      }
    });
    await HelperFunctions.getUserMobileFromSF().then((value) {
      if (value != null) {
        setState(() {
          Constant.usermobile = value;
        });
      }
    });
    await HelperFunctions.getUserIdFromSF().then((value) {
      if (value != null) {
        setState(() {
          Constant.userId = value;
        });
      }
    });
  }
  _SplashScreenState(){
    Timer(const Duration(milliseconds: 3000), () {
      setState(() {
        _isSignedIn? Navigator.of(context).pushNamedAndRemoveUntil(
            HomeScreen.routeName, (route) => false):Navigator.of(context).pushNamedAndRemoveUntil(
            WalkthroughScreen.routeName, (route) => false);
      }
      );
    });
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[
            Color.fromARGB(255, 83, 217, 193),
            Color(0xae089d82),
          ],
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
        ),
      ),
      child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              radius: 103,
              backgroundColor: Color.fromARGB(249, 247, 247, 248),
              child: CircleAvatar(
                backgroundColor: Color.fromARGB(100, 132, 132, 134),
                radius: 100,
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: Image.asset('assets/images/logo.png')),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top:20),
              child: Container(
                 height: 20,
                  width: 20,
                  child: CircularProgressIndicator(strokeWidth: 0.5,color: Colors.white,)),
            ),
          ]
      ),

    );
  }
}

