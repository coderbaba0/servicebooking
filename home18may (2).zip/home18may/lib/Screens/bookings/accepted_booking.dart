import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';

class AceeptedBookings extends StatefulWidget {
  static String routeName = "/acceptedbookings";
  const AceeptedBookings({Key? key}) : super(key: key);
  @override
  State<AceeptedBookings> createState() => _AceeptedBookingsState();
}

class _AceeptedBookingsState extends State<AceeptedBookings> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          'Chat Now',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _acceptedbookings(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _acceptedbookings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          child: Card(
            child: ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: 15,
                itemBuilder: (BuildContext context, int) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        ListTile(
                          onTap: () {
                            Navigator.of(context).pushNamedAndRemoveUntil(
                                ChatScreen.routeName, (route) => true);
                          },
                          leading: CircleAvatar(
                              radius: 20,
                              backgroundColor: kPrimaryColor.withOpacity(0.6),
                              child: const Icon(
                                Icons.chat,
                                color: Colors.white,
                              )),
                          trailing: Icon(Icons.arrow_right),
                          title: Text(
                            "Kitchen Cleaning",
                            style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                color: Colors.black87),
                          ),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 5.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Booking id : #8547584',
                                    style: TextStyle(
                                        fontSize: 12, color: Colors.black87)),
                                Text('Date : 20/03/2022 '),
                              ],
                            ),
                          ),
                          selectedTileColor: kPrimaryColor.withOpacity(0.5),
                        ),
                        new SizedBox(
                          height: 5.0,
                          child: new Center(
                            child: new Container(
                              margin: new EdgeInsetsDirectional.only(
                                  start: 15.0, end: 15.0),
                              height: 0.5,
                              color: Colors.black54,
                            ),
                          ),
                        )
                      ],
                    ),
                  );
                }),
          ),
        ),
      ],
    );
  }
}
