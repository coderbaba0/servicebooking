import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';
import 'package:book_services/models/ServiceCategory.dart';

Future<dynamic>Services(int catid) async {
    var uri = baseUrl+'services_by_category';
    var url = Uri.parse(uri);
    final response = await http.post(
      url,
      headers:{
        "Content-Type": "application/x-www-form-urlencoded",
      },
      encoding: Encoding.getByName('utf-8'),
    );
    print (response.body);
    final String responseString = response.body.toString();
    return Servicedetails.fromJson(json.decode(response.body.toString()));
  }