package com.homeservices.app.book_services

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
