import 'dart:convert';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

Future<bool>sendratings(String userid,String serviceid,String serviceengineer,String rating ,String message) async {
  var url = Uri.parse(baseUrl + 'submit_rating');
  var body = {
    'user_id': userid,
    'service_id':serviceid,
    'serviceengineer_id':serviceengineer,
    'rating':rating,
    'comment':message
  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
  print(resBody);
  if (res.statusCode == 200) {

    return true;
  }
  else {

    return false;
  }
}