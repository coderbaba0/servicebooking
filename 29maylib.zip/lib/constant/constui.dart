import 'package:flutter/material.dart';
const kPrimaryBGColor = Color(0xFFFFFCFC);
const kPrimaryColor =Color.fromARGB(255, 84, 219, 195);
const kPrimaryLightColor = Color.fromARGB(255, 170, 113, 250);
const kPrimaryGradientColor = LinearGradient(
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
  colors: [
    Color.fromARGB(255, 118, 32, 238),
    Color.fromARGB(255, 170, 113, 250)],
);
const kSecondaryColor = Color(0xFFFFFFFF);
const kTextColor = Color(0xFF000000);
const kTextColorSecondary = Color(0xFF949494);
final headingStyle = TextStyle(
  fontSize: 20,
  fontWeight: FontWeight.bold,
  color: Colors.black,
  height: 1.5,
);
final headingStyleWhite = TextStyle(
  fontSize: 20,
  fontWeight: FontWeight.bold,
  color: Colors.white,
);
final secondaryTextStyle12 = TextStyle(
  fontSize: 12,
  color: kTextColorSecondary,
);
const defaultDuration = Duration(milliseconds: 250);

