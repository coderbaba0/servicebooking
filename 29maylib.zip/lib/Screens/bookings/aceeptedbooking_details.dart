import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/showprogress.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/utils/services.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../constant/loader.dart';
import '../../persisit/constantdata.dart';

class Acceptedbookingdetails extends StatefulWidget {
  static String routeName = "/orderdetails";
  const Acceptedbookingdetails({Key? key, @required this.bookingdata})
      : super(key: key);
  final bookingdata;
  @override
  State<Acceptedbookingdetails> createState() => _AcceptedbookingdetailsState();
}

class _AcceptedbookingdetailsState extends State<Acceptedbookingdetails> {
  bool  _isloading=false;
  String? codeDialog;
  String? valueText;
  final TextEditingController _textFieldController = TextEditingController();
  var _subtotal = 685, _vat = 5 / 100, _total = 0;
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        titleSpacing: 2,
        backgroundColor: kPrimaryColor,
        automaticallyImplyLeading: true,
        leadingWidth: 40,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ], ////change your color here
        ),
        title: ListTile(
          title: Text(
            widget.bookingdata['service'],
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              shadows: [
                Shadow(
                  blurRadius: 1.0, // shadow blur
                  color: Colors.black, // shadow color
                  offset: Offset(0.5, 0.5), // how much shadow will be shown
                ),
              ],
            ),
          ),
          subtitle: Text(
            'id :#' + widget.bookingdata['id'].toString(),
            style: TextStyle(
              color: Colors.white,
              fontSize: 12,
              shadows: [
                Shadow(
                  blurRadius: 1.0, // shadow blur
                  color: Colors.black, // shadow color
                  offset: Offset(0.5, 0.5), // how much shadow will be shown
                ),
              ],
            ),
          ),
        ),
        actions: [
          InkWell(
            onTap: () async {
              Uri phoneno =
                  Uri.parse(widget.bookingdata['user_detail']['mobile']);
              Fluttertoast.showToast(
                msg: "Dialer is Opening..",
                backgroundColor: Colors.black,
                toastLength: Toast.LENGTH_LONG,
                gravity: ToastGravity.CENTER,
              );
              (await launchUrl(phoneno));
            },
            child: Padding(
              padding: EdgeInsets.only(right: 20),
              child: CircleAvatar(
                  backgroundColor: Colors.white54,
                  radius: 20,
                  child: Icon(
                    Icons.dialer_sip_outlined,
                    color: Colors.white,
                    size: 20,
                  )),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _orderdetails(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _orderdetails() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  "Customer Details : ",
                  style: TextStyle(
                      fontSize: 17,
                      fontFamily: "Inter",
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),

            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),

            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Customer name",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['user_detail']['name'],
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Conatct : ",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['user_detail']['mobile'],
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Address: ",
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Container(width:100,
                  child: Text(
                    widget.bookingdata['user_detail']['address'],
                    style: TextStyle(
                        fontSize: 13,
                        fontFamily: "Inter"),
                      maxLines: 3
                  ),
                )
              ],
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Service Date : ",
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['date'],
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Time Slot :",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['time'],
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(height: 10,),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Customer Issue : ",
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['issues'],
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 10,
            ),

            // Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //   children: [
            //     Text(widget.bookingdata['service_engineer'].toString()=='null'?'Not Assigned':widget.bookingdata['service_engineer']['name']!.toString(),style: TextStyle(fontSize: 17,fontFamily: "Inter",fontWeight: FontWeight.w600),),
            //     Container(
            //       alignment: Alignment.center,
            //       decoration: BoxDecoration(
            //           borderRadius: BorderRadius.circular(10),
            //           border: Border.all(color: kPrimaryColor)
            //       ),
            //       child: Padding(
            //         padding: const EdgeInsets.all(4.0),
            //         child: Text(widget.bookingdata['status'],style: TextStyle(fontSize: 15,fontFamily: "Inter",color: kPrimaryColor,fontWeight: FontWeight.w500),),
            //       ),
            //     ),
            //     Text("₹ 300",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600),),
            //   ],
            // ),
            // Row(
            //   children: [
            //     Text("10 March,12:00PM",style: TextStyle(fontFamily: "Inter",fontSize: 12,fontWeight: FontWeight.w500),),
            //   ],
            // ),
            SizedBox(
              height: 20,
            ),
            // Container(
            //   color: kPrimaryColor.withOpacity(0.1),
            //   child: DottedBorder(
            //     radius: Radius.circular(100),
            //     color: Colors.black,//color of dotted/dash line
            //     strokeWidth: 1, //thickness of dash/dots
            //     dashPattern: [5,6],
            //     child: Padding(
            //       padding: const EdgeInsets.all(8.0),
            //       child: Column(
            //         crossAxisAlignment: CrossAxisAlignment.start,
            //         children: [
            //           SizedBox(height: 10),
            //           Text("Cancellation policy: ",style: TextStyle(fontSize: 15,fontWeight: FontWeight.w500,fontFamily: "Inter"),),
            //           SizedBox(height: 5,),
            //           Text("If you cancel a Booking or don't show up, any cancellation/no-show fee and any refund will depend on the Service Provider's cancellation/no-show policy.",style: TextStyle(fontSize: 14,fontWeight: FontWeight.w100,fontFamily: "Inter",overflow: TextOverflow.visible),)
            //         ],
            //       ),
            //     ),
            //   ),
            //
            // ),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  "Order Details : ",
                  style: TextStyle(
                      fontSize: 17,
                      fontFamily: "Inter",
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Booking Id: ",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  '#'+widget.bookingdata['id'].toString(),
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Service name: ",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['service'].toString(),
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Invoice no",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['invoice_no'].toString() == 'null'
                      ? 'Not created'
                      : widget.bookingdata['invoice_no'],
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Service Price",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  'AED '+widget.bookingdata['price'].toString(),
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Booking Date :",
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      fontFamily: "Inter"),
                ),
                Text(
                  widget.bookingdata['created_at'].toString().split('T').first.toString().split('Z').toString(),
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Inter"),
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(
              height: 5,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.grey,
                      side: BorderSide(color: Colors.white, width: 2),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5))),
                  onPressed: () async {
                    _displayTextInputDialog(context);
                    // _isloading? Constants.showProgressDialog(context,'Please,wait..'):Container();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      "Update Status",
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                _isloading?Container(width:40,height:40,child: ColorLoader2()):Container(),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: kPrimaryColor,
                      side: BorderSide(color: Colors.white, width: 2),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5))),
                  onPressed: () async {
                    setState(() {
                      _isloading=true;
                    });
                    await DatabaseService(
                            uid: widget.bookingdata['id'].toString())
                        .createbookings(
                            Constant.usermobile.toString(),
                            Constant.userId.toString(),
                            widget.bookingdata['service'].toString())
                        .then((value) => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ChatScreen(
                                bookingdata: widget.bookingdata,
                              ),
                            ))).then((value) => setState(() {
                      _isloading=false;
                    }));
                    // _isloading? Constants.showProgressDialog(context,'Please,wait..'):Container();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      "Chat Now",
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _displayTextInputDialog(BuildContext context) async {
    return showDialog(
        barrierDismissible: false,

        context: context,
        builder: (context) {
          return AlertDialog(

            title: const Text(
              'Remarks',
              style: TextStyle(fontSize: 15),
            ),
            content: TextField(
              minLines: 3,
              maxLines: 3,
              onChanged: (value) {
                setState(() {
                  valueText = value;
                });
              },
              controller: _textFieldController,
              decoration: const InputDecoration(hintText: "Write here"),
            ),
            actions: <Widget>[
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red.withOpacity(0.5)),
                onPressed: () {
                  setState(() {
                    _textFieldController.clear();
                    Navigator.pop(context);
                  });
                },
                icon: Icon(
                  Icons.dangerous_outlined,
                  size: 16.0,
                ),
                label: Text('Exit'), // <-- Text
              ),

              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
                onPressed: () {
                  setState(() {
                    codeDialog = valueText;
                    Navigator.pop(context);
                  });
                },
                icon: Icon(
                  Icons.check,
                  size: 16.0,
                ),
                label: Text('Update'), // <-- Text
              ),
            ],
          );
        });
  }
}
