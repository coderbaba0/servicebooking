import 'package:book_services/Screens/write_us/write_us.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/size_config.dart';
import 'package:flutter/material.dart';
class BookingDone extends StatefulWidget {
  static String routeName = "/bookingdone";
  final bookingdata;
  const BookingDone({Key? key, this.bookingdata}) : super(key: key);
  @override
  State<BookingDone> createState() => _BookingDoneState();
}
class _BookingDoneState extends State<BookingDone> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        titleSpacing: 2,
        backgroundColor: kPrimaryColor,
        automaticallyImplyLeading: true,
        leadingWidth: 40,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],////change your color here
        ),
        title: ListTile(
          title: const Text(
            'Kitchen Cleaning',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 16,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
          subtitle: const Text(
            'id :#85676525',
            style: TextStyle(color: Colors.white,fontSize: 12,shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _orderdone(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _orderdone() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Appartment",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,fontFamily: "Inter"),),
                Text("₹550",style: TextStyle(fontSize: 16,fontFamily: "Inter",fontWeight: FontWeight.w600),)
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Text("Suited for repair or replacement!",style: TextStyle(fontSize: 13,fontFamily: "Inter",fontWeight: FontWeight.w100),),
              ],
            ),
            SizedBox(height: 10,),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Waste Pipe Leakage",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,fontFamily: "Inter"),),
                Text("₹350",style: TextStyle(fontSize: 16,fontFamily: "Inter",fontWeight: FontWeight.w600),)
              ],
            ),
            SizedBox(height: 10,),
            Row(
              children: [
                Text("Suited for repair or replacement!",style: TextStyle(fontSize: 13,fontFamily: "Inter",fontWeight: FontWeight.w100),),
              ],
            ),
            SizedBox(height: 10,),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),
            SizedBox(height: 10,),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Sumit kumar",style: TextStyle(fontSize: 17,fontFamily: "Inter",fontWeight: FontWeight.w600),),
                Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: kPrimaryColor)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Text("Completed",style: TextStyle(fontSize: 15,fontFamily: "Inter",color: kPrimaryColor,fontWeight: FontWeight.w500),),
                  ),
                ),
                Text("₹ 300",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600),),
              ],
            ),
            Row(
              children: [
                Text("10 March,12:00PM",style: TextStyle(fontFamily: "Inter",fontSize: 12,fontWeight: FontWeight.w500),),
              ],
            ),

            SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.grey),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Row(
                              children: [
                                Icon(Icons.star,size: 20,color: Colors.orange,),
                                Text("4.7 ",style: TextStyle(fontSize: 13,fontFamily: "Inter",fontWeight: FontWeight.w200),),
                                Text("(180) Ratings",style: TextStyle(fontSize: 13,fontFamily: "Inter",fontWeight: FontWeight.w200),)
                              ],
                            ),
                          ),
                        ),
                        CircleAvatar(
                          backgroundColor: kPrimaryColor.withOpacity(0.3),
                          radius: 20,
                          child: Icon(Icons.person,color: Colors.white,),
                        ),

                      ],
                    ),
                    SizedBox(height: 30,),

                    Row(
                      children: [
                        Text("Job Completed at 04:20 pm on saturday 11 March 2023",style: TextStyle(fontFamily: "Inter",fontWeight: FontWeight.w600,fontSize: 11.5),),
                      ],
                    ),
            Divider(
              thickness: 1,
              color: kPrimaryColor,
              endIndent: 0,
              indent: 0,
            ),

        SizedBox(height: 10,),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Rate Now : ",style: TextStyle(fontSize: 16,fontFamily: "Inter",fontWeight: FontWeight.w600),),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.grey),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                     Icon(Icons.star,color: Colors.orange,size: 20,),
                    Icon(Icons.star,color: Colors.orange,size: 20,),
                    Icon(Icons.star,color: Colors.orange,size: 20,),
                    Icon(Icons.star,color: Colors.grey,size: 20,),
                    Icon(Icons.star,color: Colors.grey,size: 20,),

                  ],
                ),

              ),
            ),


          ],
        ),
            SizedBox(height: 20,),
            Container(
              child: TextField(
                minLines: 5,
                maxLines: 5,
                keyboardType: TextInputType.multiline,
                style: TextStyle(color: Colors.black,fontSize: 16),
                cursorColor: kPrimaryColor,
                decoration: InputDecoration(
                  labelStyle: TextStyle(fontSize: 15,color: kPrimaryColor),
                  labelText: "Feedback : ",
                  hintStyle: TextStyle(fontSize: 13,fontWeight: FontWeight.w300),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: Colors.black),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: kPrimaryColor),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: Colors.red),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20,),


            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: kPrimaryColor,side:BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))),
                  onPressed: (){

                  },child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Text("Sumit Feedback",style: TextStyle(fontSize: 16,color: Colors.white),),
                ),
                ),
              ],
            ),
            SizedBox(height: 20,),
        ]
      )
      )
      );

  }

}
