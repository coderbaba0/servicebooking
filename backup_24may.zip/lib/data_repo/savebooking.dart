
import 'dart:convert';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';
savebooking(String userid,String serviceid,String hourneed,String issue,String customerhave,String bookingdate,String timeslot,String address, String conatctname,String Contactno,String paymentid,String serviceprice) async {
  var url = Uri.parse(baseUrl + 'bookservice');
  var body = {
    'User': userid,
    'serviceid':serviceid,
    'serviceid':hourneed,
    'serviceid':issue,
    'serviceid':customerhave,
    'serviceid':bookingdate,
    'serviceid':timeslot,
    'serviceid':address,
    'serviceid':conatctname,
    'serviceid':Contactno,
    'serviceid':serviceprice,
    'serviceid':paymentid,


  };
  var headerList = {
    "Content-Type": "application/json",
    "accept": "application/json",
    "Access-Control-Allow-Origin": "*"
  };
  var req = http.MultipartRequest('POST', url);
  req.headers.addAll(headerList);
  req.fields.addAll(body);
  var res = await req.send();
  final resBody = await res.stream.bytesToString();
  print(resBody);
  if (res.statusCode >= 200 && res.statusCode < 300) {
    print(resBody);
    var data = json.decode(resBody);
    if (data['status'] == true) {
      Fluttertoast.showToast(
        msg: data['message'],
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
    } else {
      Fluttertoast.showToast(
        msg: data['message'],
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );

    }
  } else {
    Fluttertoast.showToast(
      msg: "Something is wrong..",
      backgroundColor: Colors.black,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
    );
  }
}