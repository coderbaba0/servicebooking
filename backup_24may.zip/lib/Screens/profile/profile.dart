import 'package:book_services/Screens/Register/RegisterScreen.dart';
import 'package:book_services/Screens/bookings/booking_list.dart';
import 'package:book_services/Screens/fav_product/favpro.dart';
import 'package:book_services/Screens/profile/component/edit_profile.dart';
import 'package:book_services/Screens/splash/splashscreen.dart';
import 'package:book_services/Screens/walkthrough/WalkthroughScreen.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/persisit/helperfunctions.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';
import 'package:book_services/Screens/profile/component/contact.dart';

import '../../persisit/constantdata.dart';

class Profile extends StatefulWidget {
  static String routeName = "/profile";
  const Profile({Key? key}) : super(key: key);
  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  bool _isprofileimage = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: CustomBottomNavBar(selectedMenu: MenuState.profile),
      appBar: AppBar(
        toolbarHeight: 50,
        backgroundColor: kPrimaryColor,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],
          //change your color here
        ),
        title: Text(
          'Profile',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 5),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _profile_content(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
      // drawer: const Drawer(),
    );
  }

  _profile_content() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.only(top: 8.0),
        child: Column(
          children: [
            ListTile(
              leading: CircleAvatar(
                radius: 40,
                backgroundColor: kPrimaryColor.withOpacity(0.9),
                child: _isprofileimage
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: Image.network(
                          "https://picsum.photos/500/500/",
                          height: 50,
                          width: 50,
                        ),
                      )
                    : IconButton(
                        onPressed: () {},
                        icon: Icon(
                          Icons.person_add_alt_1_outlined,
                          color: Colors.white,
                          size: 35,
                        )),
              ),
              title: Text(
                Constant.username.isEmpty ? 'Hello, Guest !' : Constant.username,
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
              ),

              subtitle: Padding(
                padding: const EdgeInsets.only(top: 5.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                     'Mobile: ' +Constant.usermobile,style: TextStyle(fontStyle: FontStyle.italic),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 3.0),
                      child: Text(
                        Constant.useremail.isNotEmpty
                            ?  'Email: '+ Constant.useremail
                            : 'Email: guest@mail.com' ,style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ),
                  ],
                ),
              ),
              trailing: IconButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (_) => EditProfile(),
                  );
                },
                icon: Icon(
                  Icons.edit_note_sharp,
                  color: kPrimaryColor,
                  size: 30,
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            // ListTile(
            //   leading: Icon(Icons.app_registration, color: kPrimaryColor),
            //   title: Text(
            //     "Register as a Partner",
            //     style: TextStyle(
            //         fontSize: 15,
            //         fontWeight: FontWeight.w300,
            //         fontFamily: 'Inter'),
            //   ),
            //   trailing: Icon(
            //     Icons.arrow_right,
            //     color: kPrimaryColor,
            //   ),
            // ),
            // Divider(
            //   thickness: 1,
            //   color: Colors.grey,
            //   indent: 20,
            //   endIndent: 20,
            // ),
            ListTile(
              onTap: (){
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          AllBookings(
                          ),
                    ));
              },
              leading: Icon(
                Icons.calendar_month_outlined,
                color: kPrimaryColor,
              ),
              title: Text(
                "Bookings Details",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              // enabled: true,
              focusColor: kPrimaryColor.withOpacity(0.2),
              selectedTileColor: kPrimaryColor.withOpacity(0.2),
              onTap: () {
                Navigator.of(context)
                    .pushNamedAndRemoveUntil(FavPro.routeName, (route) => true);
              },
              leading: Icon(
                Icons.bookmark_added_outlined,
                color: kPrimaryColor,
              ),
              title: Text(
                "Favorites Services",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              leading: Icon(
                Icons.star_half,
                color: kPrimaryColor,
              ),
              title: Text(
                "Rate Us",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              onTap: () {
                Navigator.push(context,
                    new MaterialPageRoute(builder: (context) => new Support()));
              },
              leading: Icon(
                Icons.support_agent_sharp,
                color: kPrimaryColor,
              ),
              title: Text(
                "Support",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              onTap: () async {
                await HelperFunctions.saveUserLoggedInStatus(false);
                await HelperFunctions.saveUserNameSF("");
                await HelperFunctions.saveuserMobileSF("");
                await HelperFunctions.saveUserIdSF("");
                await HelperFunctions.saveUserEmailSF("");
                Navigator.of(context).pushNamedAndRemoveUntil(
                    WalkthroughScreen.routeName, (route) => false);
              },
              leading: Icon(
                Icons.login,
                color: kPrimaryColor,
              ),
              title: Text(
                "Logout",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              leading: Icon(
                Icons.share,
                color: kPrimaryColor,
              ),
              title: Text(
                "Share",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              leading: Icon(
                Icons.privacy_tip_outlined,
                color: kPrimaryColor,
              ),
              title: Text(
                "Privacy & Policy",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              leading: Icon(
                Icons.file_copy_outlined,
                color: kPrimaryColor,
              ),
              title: Text(
                "Terms & Conditions",
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w300,
                    fontFamily: 'Inter'),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            ListTile(
              leading: Icon(Icons.delete, color: kPrimaryColor),
              title: InkWell(
                onTap: () {
                  showModalBottomSheet(
                      shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(25))),
                      context: (context),
                      builder: (BuildContext context) {
                        return SizedBox(
                          height: 250,
                          child: Center(
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 40),
                                  child: Text(
                                    "Delete Account!",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Text(
                                  "Are you sure ,want to delete? ",
                                  style: TextStyle(fontSize: 15),
                                ),
                                SizedBox(
                                  height: 30,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            primary: Colors.grey,
                                            side: BorderSide(
                                              color: Colors.white,
                                              width: 1,
                                            ),
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(5))),
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(10.0),
                                          child: Text(
                                            "No",
                                            style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 15),
                                          ),
                                        )),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            primary: kPrimaryColor,
                                            side: BorderSide(
                                              color: Colors.white,
                                              width: 1,
                                            ),
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(5))),
                                        onPressed: () {},
                                        child: Padding(
                                          padding: const EdgeInsets.all(10.0),
                                          child: Text("Yes",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 15)),
                                        )),
                                  ],
                                )
                              ],
                            ),
                          ),
                        );
                      });
                },
                child: Text(
                  "Delete  Account",
                ),
              ),
              trailing: Icon(
                Icons.arrow_right,
                color: kPrimaryColor,
              ),
            ),
            Divider(
              thickness: 1,
              color: Colors.grey,
              indent: 20,
              endIndent: 20,
            ),
            Container(
              margin: EdgeInsets.only(top: 30, bottom: 15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Version: 1.0.0",
                    style: TextStyle(fontSize: 8, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
