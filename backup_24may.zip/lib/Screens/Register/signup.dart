import 'dart:convert';
import 'package:book_services/constant/showprogress.dart';
import 'package:book_services/persisit/helperfunctions.dart';
import 'package:book_services/utils/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/helper/global.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../data_repo/senftoken.dart';
import '../../persisit/constantdata.dart';
import 'RegisterScreen.dart';

class SignupScreen extends StatefulWidget {
  static String routeName = "";
  const SignupScreen({Key? key}) : super(key: key);
  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen>
    with SingleTickerProviderStateMixin {
  bool? isloading;
  late AnimationController _animationController;
  String? mobile;
  String ?name;
  final _formKey = GlobalKey<FormState>();
  TextEditingController mobilecontroller = TextEditingController();
  TextEditingController namecontroller = TextEditingController();
  String? mtoken = " ";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getDeviceToken();
    _animationController = AnimationController(vsync: this);
  }
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
  //get device token
  Future<void> getDeviceToken() async {
    await FirebaseMessaging.instance.getToken().then((token) {
      setState(() {
        mtoken = token;
        // print(mtoken);
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: <Color>[
              Color.fromARGB(255, 83, 217, 193),
              Color(0xae089d82),
            ],
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(
                10, MediaQuery.of(context).size.height * 0.1, 20, 0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.arrow_back,
                        size: 30,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Lottie.asset(
                  "assets/images/sign.json",
                  controller: _animationController,
                  height: 150,
                  onLoaded: (com) {
                    // Configure the AnimationController with the duration of the
                    // Lottie file and start the animation.
                    _animationController
                      ..duration = com.duration
                      ..forward();
                  },
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 150,top: 15),
                  child: Text(
                    "Please Register now!",
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w400,
                        color: Colors.white),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                Form(
                  key: _formKey,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 15.0, right: 15),
                    child: Column(
                      children: [
                        TextFormField(
                          onSaved: (newValue) => name = newValue!,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, enter Your Name!';
                            }  else {
                              return null;
                            }
                          },
                          style: TextStyle(color: Colors.white),
                          cursorColor: Colors.white,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white60),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            labelStyle: const TextStyle(color: kPrimaryColor),
                            focusColor: kTextColorSecondary.withOpacity(0.2),
                            hintText: "Enter Your Name",
                            hintStyle: TextStyle(color: Colors.white),
                            fillColor: Colors.white,
                            filled: false,
                            prefixIcon: const Icon(
                              Icons.person,
                              color: Colors.white,
                            ),
                          ),
                          controller: namecontroller,
                          keyboardType: TextInputType.name,
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          onSaved: (newValue) => mobile = newValue!,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please, enter mobile!';
                            } else if (value.length > 10) {
                              return 'Mobile number must be equal to 10 digit.';
                            } else {
                              return null;
                            }
                          },
                          style: TextStyle(color: Colors.white),
                          cursorColor: Colors.white,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white60),
                            ),
                            disabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(5.0),
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            errorBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(color: Colors.red),
                            ),
                            labelStyle: const TextStyle(color: kPrimaryColor),
                            focusColor: kTextColorSecondary.withOpacity(0.2),
                            hintText: "Enter Mobile number",
                            hintStyle: TextStyle(color: Colors.white),
                            fillColor: Colors.white,
                            filled: false,
                            prefixIcon: const Icon(
                              Icons.call,
                              color: Colors.white,
                            ),
                          ),
                          controller: mobilecontroller,
                          keyboardType: TextInputType.phone,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 50,
                  width: double.infinity,
                  margin: EdgeInsets.only(
                    left: 20,
                    right: 20,
                  ),
                  // decoration: BoxDecoration(
                  //   borderRadius: BorderRadius.circular(10),
                  //
                  // ),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: Colors.white24,
                        side: BorderSide(
                          color: Colors.white,
                          width: 2,
                        ),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20))),
                    onPressed: () {
                      setState(() {
                        isloading = true;
                      });

                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                         register(mobilecontroller.text,namecontroller.text);
                      }
                    },
                    child: Text(
                      "Register Now",
                      style: TextStyle(fontSize: 20, color: Colors.white),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Center(child: InkWell(onTap: (){
                    Navigator.of(context).pushNamed(
                      RegisterScreen.routeName,);
                  },

                    child: Text('Already Registerd !',style: TextStyle(fontSize: 15,color: Colors.white),)),)
              ],
            ),
          ),
        ),
      ),
    );

  }

  register(String mobile,String name) async {
    var url = Uri.parse(baseUrl + 'customer');
    var body = {
      'mobile': mobile,
      'name': name,
    };
    isloading!
        ? Constants.showProgressDialog(context, 'Please wait..'):'';
    var headerList = {
      "Content-Type": "application/json",
      "accept": "application/json",
      "Access-Control-Allow-Origin": "*"
    };
    var req = http.MultipartRequest('POST', url);
    req.headers.addAll(headerList);
    req.fields.addAll(body);
    var res = await req.send();
    final resBody = await res.stream.bytesToString();
    print(resBody);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      print(resBody);
      var data = json.decode(resBody);
      if (data['status'] == true) {
        print(data['message']);
        var actualdata = data['data'];
        var userid = actualdata['id'];
        var usermobile = actualdata['mobile'];
        var username = actualdata['name'];
        setState(() {
          Constant.userId = userid.toString();
          Constant.usermobile = usermobile;
          Constant.username = username;
        }
        );
        await HelperFunctions.saveUserLoggedInStatus(true);
        await HelperFunctions.saveUserIdSF(userid.toString());
        await HelperFunctions.saveuserMobileSF(usermobile.toString());
        await HelperFunctions.saveUserNameSF(username.toString());
        Fluttertoast.showToast(
          msg: data['message'],
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );
        await DatabaseService(uid: Constant.userId)
            .savingUserData(usermobile, userid.toString());
        sendtoken(Constant.userId,mtoken);
        setState(() {
          isloading = false;
        });
        Navigator.of(context)
            .pushNamedAndRemoveUntil(HomeScreen.routeName, (route) => false);
      } else {
        setState(() {
          isloading = false;
        });
        Fluttertoast.showToast(
          msg: data['message'],
          backgroundColor: Colors.black,
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
        );

      }
    } else {

      Fluttertoast.showToast(
        msg: "Something is wrong..",
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
      setState(() {
        isloading = false;
      });
    }
  }
}
