import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/constant/loader.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';
import '../../data_repo/service_engineerbooking.dart';
import '../../persisit/constantdata.dart';
import '../../persisit/helperfunctions.dart';
import '../walkthrough/WalkthroughScreen.dart';
import 'aceeptedbooking_details.dart';
class AceeptedBookings extends StatefulWidget {
  static String routeName = "/acceptedbookings";
  const AceeptedBookings({Key? key}) : super(key: key);
  @override
  State<AceeptedBookings> createState() => _AceeptedBookingsState();
}
class _AceeptedBookingsState extends State<AceeptedBookings> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(

          child: ListView(
            // Important: Remove any padding from the ListView.
            children: [
               DrawerHeader(
                decoration: BoxDecoration(
                  color: kPrimaryColor,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(radius: 40,backgroundColor: Colors.white,),
                    SizedBox(
                      height: 10,
                    ),
                    Text(Constant.username.toString(),style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500,color: Colors.white),),
                  ],
                ),
              ),
              ListTile(
                title: const Text('Logout'),
                onTap: () async{
                    await HelperFunctions.saveUserLoggedInStatus(false);
                    await HelperFunctions.saveUserNameSF("");
                    await HelperFunctions.saveuserMobileSF("");
                    await HelperFunctions.saveUserIdSF("");
                    await HelperFunctions.saveUserEmailSF("");
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        WalkthroughScreen.routeName, (route) => false);
                },
              ),
              ListTile(
                title: const Text('Profile'),
                onTap: () {

                  Navigator.pop(context);
                },
              ),
            ],
          )
      ),
      appBar: AppBar(
        actions: [
          IconButton(onPressed: (){
          }, icon: Icon(Icons.notifications)),
        ],
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          'Alloted Services',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _acceptedbookings(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }
  _acceptedbookings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          child: Card(
            child:  FutureBuilder<dynamic>(
                future: serviceengineerbooking(
                    '1'),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if(snapshot.data.length!=0){
                      return ListView.builder(
                          scrollDirection: Axis.vertical,
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: snapshot.data.length,
                          itemBuilder:
                              (context, index) {
                                return Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    children: [
                                      ListTile(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    Acceptedbookingdetails(
                                                      bookingdata: snapshot.data[index],
                                                    ),
                                              ));
                                        },
                                        leading: CircleAvatar(
                                            radius: 20,
                                            backgroundColor: kPrimaryColor.withOpacity(0.6),
                                            child: const Icon(
                                              Icons.chat,
                                              color: Colors.white,
                                            )),
                                        trailing: Icon(Icons.arrow_right),
                                        title: Text(
                                          snapshot.data[index]['service'].toString(),
                                          style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.black87),
                                        ),
                                        subtitle: Padding(
                                          padding: const EdgeInsets.only(top: 5.0),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text('Booking id : #'+snapshot.data[index]['id'].toString(),
                                                  style: TextStyle(
                                                      fontSize: 12, color: Colors.black87)),
                                              SizedBox(
                                                height: 5,
                                              ),
                                              Container(
                                                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),border: Border.all(width: 0.5,color: Colors.red)),
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                                                    child: Text(snapshot.data[index]['status'].toString(),style: TextStyle(color: Colors.red),),
                                                  ))
                                            ],
                                          ),
                                        ),
                                        selectedTileColor: kPrimaryColor.withOpacity(0.5),
                                      ),
                                      new SizedBox(
                                        height: 5.0,
                                        child: new Center(
                                          child: new Container(
                                            margin: new EdgeInsetsDirectional.only(
                                                start: 15.0, end: 15.0),
                                            height: 0.5,
                                            color: Colors.black54,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                );
                          });
                    }
                    else{
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 100.0,bottom: 100),
                          child: Text('No any booking Alloted yet!'),
                        ),
                      );
                    }
                  }
                  else {
                    return Center(
                      child:
                      ColorLoader2(),
                    );
                  }
                }),
          ),
        ),
      ],
    );
  }
}
