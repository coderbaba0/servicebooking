import 'dart:io';
import 'package:book_services/utils/services.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'Screens/chat/conversastions.dart';
import 'Screens/homepage/component/notifications.dart';
class NotificationServices {
  //initialising firebase message plugin
  FirebaseMessaging messaging = FirebaseMessaging.instance ;
  //initialising firebase message plugin
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin  = FlutterLocalNotificationsPlugin();

  // function to request notifications permissions
  void requestNotificationPermission()async{
    NotificationSettings settings = await messaging.requestPermission(
        alert: true ,
        announcement: true ,
        badge: true ,
        carPlay:  true ,
        criticalAlert: true ,
        provisional: true ,
        sound: true
    );
    if(settings.authorizationStatus == AuthorizationStatus.authorized){
      print('user granted permission');
    }else if(settings.authorizationStatus == AuthorizationStatus.provisional){
      print('user granted provisional permission');
    } else {
      // AppSettings.openNotificationSettings();
      print('user denied permission');
    }
  }
  //function to initialise flutter local notification plugin to show notifications for android when app is active
  void initLocalNotifications(BuildContext context, RemoteMessage message)async{
    var androidInitializationSettings = const AndroidInitializationSettings('@mipmap/ic_launcher');
    var initializationSetting = InitializationSettings(
      android: androidInitializationSettings ,
    );
    await _flutterLocalNotificationsPlugin.initialize(
        initializationSetting,
        onDidReceiveNotificationResponse: (payload) async {
          // handle interaction when app is active for android
          handleMessage(context, message);
          print(message.data);
        }
    );
  }
  void firebaseInit(BuildContext context){
    FirebaseMessaging.onMessage.listen((message) {
      if (kDebugMode) {
        print("notifications title:"+message.notification!.title.toString());
        print("notifications body:"+message.notification!.body.toString());
        print("notifications channel id:"+message.notification!.android!.channelId.toString());
        print("notifications click action:"+message.notification!.android!.clickAction.toString());
        print("notifications color:"+message.notification!.android!.color.toString());
        print("notifications count:"+message.notification!.android!.count.toString());
      }
      if(Platform.isAndroid){
        initLocalNotifications(context, message);
        print(message.data);

      }
    });
  }
  //function to get device token on which we will send the notifications
  Future<String> getDeviceToken() async {
    String? token = await messaging.getToken();
    return token!;
  }
  void isTokenRefresh()async{
    messaging.onTokenRefresh.listen((event) {
      event.toString();
      if (kDebugMode) {
        print('refresh');
      }
    });
  }
//forground

  //handle tap on notification when app is in background or terminated
  Future<void> setupInteractMessage(BuildContext context)async{
    // when app is terminated
    RemoteMessage? initialMessage = await FirebaseMessaging.instance.getInitialMessage();
    if(initialMessage != null){
      handleMessage(context, initialMessage);
    }
    //when app ins background
    FirebaseMessaging.onMessageOpenedApp.listen((event) {
      handleMessage(context, event);
    });
  }
  void handleMessage(BuildContext context, RemoteMessage message) async{
    if(message.data['id'] != Null)
    {
      Navigator.of(context).pushNamedAndRemoveUntil(
          Notifications.routeName, (route) => true);
      print(message.data['id'].toString());
          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //       builder: (context) =>
          //           ChatScreen(
          //             bookingdata: message.data['bookingdata'],
          //           ),
          //     ));
    }
    else{
      Navigator.of(context).pushNamedAndRemoveUntil(
          Notifications.routeName, (route) => true);
    }
  }

}