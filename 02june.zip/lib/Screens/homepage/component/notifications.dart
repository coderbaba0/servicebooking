import 'package:book_services/constant/constui.dart';
import 'package:book_services/size_config.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
class Notifications extends StatefulWidget {
  static String routeName = "/notifications";
  final title;
  final body;
  final time;
  final data;
  const Notifications({Key? key, this.title, this.body, this.time, this.data}) : super(key: key);
  @override
  State<Notifications> createState() => _NotificationsState();
}
class _NotificationsState extends State<Notifications>
    with TickerProviderStateMixin {
// String ?title;
// String?body;
//   @override
//   void initState() {
//     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
//       print('Got a message whilst in the foreground!');
//       print('Message data: ${message.data}');
//       if (message.notification != null) {
//         print('Message also contained a notification: ${message.notification!.title}');
//         print('Message also contained a notification: ${message.sentTime}');
// setState(() {
//   title =message.notification!.title!;
//   body=message.notification!.body!;
//   print(title!);
// });
//       }
//     });
//     super.initState();
//   }
  @override
  Widget build(BuildContext context) {
    TabController tabController=TabController(length: 3, vsync: this);
    return Scaffold(
      appBar: AppBar(
        elevation: 2,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],//change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          'Notifications',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: true,
        actions: [
          Center(child: Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Text('Clear All',style: TextStyle(color: Colors.white,fontSize: 12,fontWeight: FontWeight.w500),),
          ))
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 2.0,right: 2.0),
                    child: Column(
                      children: [
                        SizedBox(height: 5,),
                        Container(
                          height: SizeConfig.screenHeight *0.04,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(50.0))
                          ),
                          child: TabBar(
                            labelStyle: TextStyle(fontWeight: FontWeight.w500,fontSize: 15),
                            labelColor: Colors.black,
                            controller: tabController,
                            indicatorColor: Colors.transparent,
                            indicator: BoxDecoration(
                              border: Border.all(
                              color: Colors.black54 ,
                              width: 1.0 ,
                            ),
                                borderRadius: BorderRadius.circular(50), // Creates border
                                ),
                            tabs: [
                              Tab(text: "All",),
                              Tab(text: "Bookings",),
                              Tab(text: "Offers",),
                            ],
                          ),
                        ),
                        SizedBox(height: 10,),
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              Container(
                                height: 1000,
                                child: TabBarView(
                                  physics: NeverScrollableScrollPhysics(),
                                  controller: tabController,
                                  children: [
                                    ListView.builder(
                                        shrinkWrap:true,
                                        itemCount: 5,
                                        itemBuilder: (context,index){
                                          return Padding(
                                            padding: const EdgeInsets.only(top: 10.0),
                                            child: Card(
                                              child: ListTile(
                                                onTap: () {

                                                },
                                                leading: CircleAvatar(
                                                    radius: 20,
                                                    backgroundColor: kPrimaryColor.withOpacity(0.5),
                                                    child: const Icon(
                                                      Icons.notifications_active_outlined,
                                                      color: Colors.white,
                                                    )),
                                                title: Text(widget.body!,
                                                    style: TextStyle(inherit: true,overflow: TextOverflow.visible,
                                                        fontSize: 13, color: Colors.black,fontWeight: FontWeight.w500)),
                                                subtitle: Text(widget.time!),
                                                selectedTileColor: kPrimaryColor.withOpacity(0.5),
                                              ),


                                            ),
                                          );
                                        }),
                                    ListView.builder(
                                        shrinkWrap:true,
                                        itemCount: 20,
                                        itemBuilder: (context,index){
                                          return Padding(
                                            padding: const EdgeInsets.only(top: 10.0),
                                            child: Card(
                                              child: ListTile(
                                                onTap: () {

                                                },
                                                leading: CircleAvatar(
                                                    radius: 20,
                                                    backgroundColor: kPrimaryColor.withOpacity(0.5),
                                                    child: const Icon(
                                                      Icons.notifications_active_outlined,
                                                      color: Colors.white,
                                                    )),
                                                title: Text('Hurray up! A great discount on cleaning services,go and book now!',
                                                    style: TextStyle(inherit: true,overflow: TextOverflow.visible,
                                                        fontSize: 13, color: Colors.black,fontWeight: FontWeight.w500)),
                                                subtitle: Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Text('12 minute ago'),
                                                ),
                                                selectedTileColor: kPrimaryColor.withOpacity(0.5),
                                              ),


                                            ),
                                          );
                                        }),
                                    ListView.builder(
                                        shrinkWrap:true,
                                        itemCount: 20,
                                        itemBuilder: (context,index){
                                          return Padding(
                                            padding: const EdgeInsets.only(top: 10.0),
                                            child: Card(
                                              child: ListTile(
                                                onTap: () {

                                                },
                                                leading: CircleAvatar(
                                                    radius: 20,
                                                    backgroundColor: kPrimaryColor.withOpacity(0.5),
                                                    child: const Icon(
                                                      Icons.notifications_active_outlined,
                                                      color: Colors.white,
                                                    )),
                                                title: Text('Hurray up! A great discount on cleaning services,go and book now!',
                                                    style: TextStyle(inherit: true,overflow: TextOverflow.visible,
                                                        fontSize: 13, color: Colors.black,fontWeight: FontWeight.w500)),
                                                subtitle: Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Text('12 minute ago'),
                                                ),
                                                selectedTileColor: kPrimaryColor.withOpacity(0.5),
                                              ),


                                            ),
                                          );
                                        }),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
