import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/constant/constui.dart';
import 'package:book_services/data_repo/favorite.dart';
import 'package:book_services/enum.dart';
import 'package:book_services/helper/global.dart';
import 'package:book_services/size_config.dart';
import 'package:book_services/widgets/custombottom_navbar.dart';
import 'package:flutter/material.dart';
import '../../constant/loader.dart';
import '../../persisit/constantdata.dart';
import '../../shimmer/services_shimmer.dart';
import '../homepage/component/serviceondicount.dart';
import '../services/bookings_step/fav_service_details.dart';
import '../services/bookings_step/service_details.dart';

class FavPro extends StatefulWidget {
  static String routeName = "/fav";

  const FavPro({Key? key}) : super(key: key);

  @override
  State<FavPro> createState() => _FavProState();
}

class _FavProState extends State<FavPro> {
  bool _isanyfav = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar:
          CustomBottomNavBar(selectedMenu: MenuState.favorites),
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.white, //change your color here
        ),
        backgroundColor: kPrimaryColor,
        title: Text(
          'Favorite Services',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, right: 8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _favserv(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _favserv() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
            child: FutureBuilder<dynamic>(
                future: getfavlist(Constant.userId.toString()),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    if(snapshot.data.length!=0)
                    {
                      return GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.75,
                      ),
                      itemCount:snapshot.data.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(3, 5, 3, 5),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        FavServiceDetails(
                                          servicedata: snapshot.data[index],
                                        ),
                                  ));

                            },
                            child: SizedBox(
                              width: SizeConfig.screenWidth / 2.5,
                              height: SizeConfig.screenWidth / 3.5,
                              child: Card(
                                elevation: 2,
                                child: Column(
                                  children: [
                                    Expanded(
                                        child: Container(
                                            decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  image: NetworkImage(imgUrl+ snapshot.data[index]['image']),
                                                  fit: BoxFit.cover,
                                                ),
                                                borderRadius: const BorderRadius
                                                    .only(
                                                    topLeft: Radius.circular(5),
                                                    topRight:
                                                    Radius.circular(5))))),
                                    Align(
                                      alignment: Alignment.bottomLeft,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 8.0,
                                            right: 8.0,
                                            bottom: 10.0,
                                            top: 5),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              snapshot.data[index]['name'],
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: Colors.black87,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            const SizedBox(height: 3),
                                            // Row(
                                            //   children: const [
                                            //     Icon(
                                            //       Icons.star,
                                            //       color: Colors.orange,
                                            //       size: 15,
                                            //     ),
                                            //     Icon(
                                            //       Icons.star,
                                            //       color: Colors.orange,
                                            //       size: 15,
                                            //     ),
                                            //     Icon(
                                            //       Icons.star,
                                            //       color: Colors.orange,
                                            //       size: 15,
                                            //     ),
                                            //     Icon(
                                            //       Icons.star,
                                            //       color: Colors.orange,
                                            //       size: 15,
                                            //     ),
                                            //     Icon(
                                            //       Icons.star_half,
                                            //       color: Colors.orange,
                                            //       size: 15,
                                            //     ),
                                            //     Text(
                                            //       "4.5 (35)",
                                            //       textAlign: TextAlign.center,
                                            //       style: TextStyle(
                                            //         fontSize: 12,
                                            //         color: Colors.orange,
                                            //         fontWeight: FontWeight.w300,
                                            //       ),
                                            //     ),
                                            //   ],
                                            // ),
                                            const SizedBox(height: 3),
                                            Row(
                                              children:  [
                                                Text(
                                                  "Now at : " ,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.black87,
                                                      fontWeight:
                                                      FontWeight.bold),
                                                ),
                                                Text(
                                                  ' AED '+ snapshot.data[index]['price_per_unit'].toString(),
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.orange,
                                                      fontWeight:
                                                      FontWeight.bold),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 8),
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .spaceBetween,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                      color: Colors.white,
                                                      border: Border.all(
                                                          color:
                                                          Colors.black45),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          5)),
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets.all(
                                                        6.0),
                                                    child: const Text(
                                                      "Book Now",
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(width: 1),
                                                Container(
                                                    height: 20,
                                                    width: 0.3,
                                                    color: Colors.black45),
                                                const Center(
                                                  child: Icon(
                                                    Icons.favorite,
                                                    color: Colors.orange,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );}
                    else{
                       return Center(
                        child: _emptyfav(),
                      );
                    }

                  }
                  else{
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.75,
                          ),
                          itemCount:4,
                          itemBuilder: (BuildContext context, int index) {
                            return Padding(
                              padding: const EdgeInsets.fromLTRB(3, 5, 3, 5),
                              child: SizedBox(
                                width: SizeConfig.screenWidth / 2.5,
                                height: SizeConfig.screenWidth / 3.5,
                                child: other(),
                              ),
                            );
                          },
                        ),
                        Center(child: Container(
                            height:30,
                            width:30,child: ColorLoader2())),
                      ],
                    );
                  }
                })),
      ],
    );
  }
  _emptyfav() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 150),
          child: Container(
              height: MediaQuery.of(context).size.width * 0.28,
              width: MediaQuery.of(context).size.width * 0.28,
              decoration: BoxDecoration(),
              child: Image.asset(
                "assets/images/favorite.png",
                height: 50,
                width: 50,
              )),
        ),

        Text(
          "You have not Added any \n Favorite service !",
          style: TextStyle(
              fontSize: 15, fontWeight: FontWeight.w100, fontFamily: "Inter"),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20),
          child: Container(
              height: 40,
              width: MediaQuery.of(context).size.width * 0.5,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: kPrimaryColor,
                      side: BorderSide(
                        color: Colors.white,
                        width: 2,
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15))),
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Service_on_discount(
                            title: 'All Services on discount',
                          ),
                        ));
                  },
                  child: Text(
                    "Explore Service",
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ))),
        )
      ],
    );
  }
}
