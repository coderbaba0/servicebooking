import 'package:book_services/constant/constui.dart';
import 'package:book_services/size_config.dart';
import 'package:flutter/material.dart';

import '../../../data_repo/sendwriteus.dart';
import '../../../persisit/constantdata.dart';

class Support extends StatefulWidget {
  static String routeName ="/supp";
  const Support({Key? key}) : super(key: key);
  @override
  State<Support> createState() => _SupportState();
}
class _SupportState extends State<Support> {
  String? name;
  String? issue;
  TextEditingController namectrl = TextEditingController();
  TextEditingController issuectrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 50,
        backgroundColor: kPrimaryColor,
        iconTheme: IconThemeData(
          color: Colors.white,
          shadows: [
            Shadow(
              blurRadius: 1.0, // shadow blur
              color: Colors.black, // shadow color
              offset: Offset(0.5, 0.5), // how much shadow will be shown
            ),
          ],
          //change your color here
        ),
        title: Text(
          'Contact Us',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            shadows: [
              Shadow(
                blurRadius: 1.0, // shadow blur
                color: Colors.black, // shadow color
                offset: Offset(0.5, 0.5), // how much shadow will be shown
              ),
            ],
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(left: 10.0, right: 10.0, top: 5),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: getProportionateScreenHeight(1)),
                _reachus(),
                SizedBox(height: getProportionateScreenWidth(8)),
              ],
            ),
          ),
        ),
      ),
      // drawer: const Drawer(),
    );
  }
  _reachus() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.only(top: 10.0,bottom: 20,left: 25,right: 25),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              SizedBox(height: 10,),

              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text("Write us:",style: TextStyle(fontSize: 16,fontFamily: "Inter",fontWeight: FontWeight.w500),),
                ],
              ),

              SizedBox(height: 20,),
              TextFormField(
                controller: namectrl,
                onSaved: (newValue) => name = newValue!,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please, enter your name!';
                  }
                  return null;
                },
                style: TextStyle(color: Colors.black,fontSize: 16),
                cursorColor: kPrimaryColor,
                decoration: InputDecoration(
                  labelStyle: TextStyle(fontSize: 15,color: kPrimaryColor),
                  contentPadding: EdgeInsets.only(left: 15,top: 20),
                  hintText: "Enter your Name",
                  hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: Colors.black),
                  ),
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide.none,
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: kPrimaryColor),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: Colors.red),
                  ),
                ),
              ),
              SizedBox(height: 20,),
              TextFormField(
                controller: issuectrl,
                onSaved: (newValue) => issue = newValue!,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please, enter your name!';
                  }
                  return null;
                },
                minLines: 5,
                maxLines: 5,
                keyboardType: TextInputType.multiline,
                style: TextStyle(color: Colors.black,fontSize: 16),
                cursorColor: kPrimaryColor,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.only(left: 15,top: 20),
                  hintText: "Please, type your Issue..",
                  hintStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w300),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: Colors.black),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: kPrimaryColor),
                  ),
                  errorBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide(color: Colors.red),
                  ),
                ),
              ),
              SizedBox(height: 20,),
              ElevatedButton(
                style: ElevatedButton.styleFrom(primary: kPrimaryColor,side: BorderSide(color: Colors.white,width: 2),shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                onPressed: (){
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      sendsupport(Constant.userId,namectrl.text,issuectrl.text).then((value) => value? showAlertDialog(context,'Message Sucessfully Sent!') : showAlertDialog(context,'Somthing Error!') ,);
    }
                },child: Padding(
                  padding: const EdgeInsets.only(left: 40.0,right: 40,top: 10,bottom: 10),
                  child: Text("Submit",style: TextStyle(fontSize: 18,color: Colors.white),),
                ),
              ),
              SizedBox(height: 30,),

              Row(
                children: [
                  Text("Reach Us:",style: TextStyle(fontSize: 16,fontFamily: "Inter",fontWeight: FontWeight.w500),),
                ],
              ),

              SizedBox(height: 20,),
              Row(

                children: [
                  CircleAvatar(
                      backgroundColor: kPrimaryColor,
                      child: Icon(Icons.email_outlined,color: Colors.white,)),
                  Padding(
                    padding: const EdgeInsets.only(left: 10,top: 0),
                    child: Text("info@alkhail.co",style: TextStyle(fontSize: 14,fontFamily: "Inter",fontWeight: FontWeight.w500)),
                  )
                ],
              ),
              SizedBox(height: 10,),

              Row(
                children: [
                  CircleAvatar(
                      backgroundColor: kPrimaryColor,
                      child: Icon(Icons.phone_outlined,color: Colors.white,)),
                  Padding(
                    padding: const EdgeInsets.only(left: 10,top: 0),
                    child: Text("050 783 2292",style: TextStyle(fontSize: 14,fontFamily: "Inter",fontWeight: FontWeight.w500),),
                  )
                ],
              ),
              SizedBox(height: 10,),

              Row(

                children: [
                  CircleAvatar(
                      backgroundColor: kPrimaryColor,
                      child: Icon(Icons.location_on,color: Colors.white,)),
                  Padding(
                    padding: const EdgeInsets.only(left: 10,top: 0),
                    child: Text("Dubai, UAE",style: TextStyle(fontSize: 14,fontFamily: "Inter",fontWeight: FontWeight.w500),),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
showAlertDialog(BuildContext context,String message) {
  // set up the button
  Widget okButton = TextButton(
    child: Text("OK",style: TextStyle(color: kPrimaryColor),),
    onPressed: () {
      Navigator.pop(context);
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Message"),
    content: Text(message),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
