import 'package:book_services/Screens/Register/RegisterScreen.dart';
import 'package:book_services/Screens/bookings/accepted_booking.dart';
import 'package:book_services/Screens/bookings/booking_done.dart';
import 'package:book_services/Screens/bookings/booking_list.dart';
import 'package:book_services/Screens/bookings/order_details.dart';
import 'package:book_services/Screens/chat/conversastions.dart';
import 'package:book_services/Screens/fav_product/favpro.dart';
import 'package:book_services/Screens/homepage/component/notifications.dart';
import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/Screens/profile/profile.dart';
import 'package:book_services/Screens/splash/splashscreen.dart';
import 'package:book_services/Screens/walkthrough/WalkthroughScreen.dart';
import 'package:book_services/Screens/write_us/write_us.dart';
import 'package:book_services/Screens/services/all_services.dart';

import 'package:flutter/widgets.dart';

import 'Screens/Register/service_engineer.dart';
import 'Screens/profile/component/contact.dart';

final Map<String, WidgetBuilder> routes = {
  SplashScreen.routeName: (context) => const SplashScreen(),
  WalkthroughScreen.routeName: (context) => const WalkthroughScreen(),
  RegisterScreen.routeName:(context) => const RegisterScreen(),
  HomeScreen.routeName:(context) => const HomeScreen(),
  FavPro.routeName:(context) => const FavPro(),
  Profile.routeName:(context) => const Profile(),
  Suggestion.routeName:(context) => const Suggestion(),
  Support.routeName:(context) => const Support(),
  AllBookings.routeName:(context) => const AllBookings(),
  OrderDetails.routeName:(context) => const OrderDetails(),
  AceeptedBookings.routeName:(context) =>  AceeptedBookings(),
  ChatScreen.routeName:(context) => const ChatScreen(),
  BookingDone.routeName:(context) => const BookingDone(),
  Notifications.routeName:(context) => const Notifications(),
  AllServices.routeName:(context) =>  AllServices(),
  Service_engineer.routeName:(context) =>  Service_engineer(),

};

