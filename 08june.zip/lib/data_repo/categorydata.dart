
import 'dart:convert';
import 'dart:io';
import 'package:book_services/helper/global.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/models/All_category.dart';
import 'package:path_provider/path_provider.dart';

Future<dynamic> Allcat() async {
    final response = await http.get(
      Uri.parse(baseUrl + 'categories'),
    );
    var data = jsonDecode(response.body.toString());
    // print(data);
    if (response.statusCode == 200) {
      return data;
    } else {
      throw Exception('Failed to load ');
    }
  }

// Future<dynamic> Allcat() async {
//   String fileName = 'category.json';
//   var dir = await getTemporaryDirectory();
//   File file = File(dir.path + '/' + fileName);
//   if (file.existsSync()) {
//     print("Fetching from cache");
//     var jsonData = file.readAsStringSync();
//     var data = jsonDecode(jsonData);
//     return data;
//   }
//   else {
//     final response = await http.get(
//       Uri.parse(baseUrl + 'categories'),
//     );
//     var data = jsonDecode(response.body.toString());
//     // print(data);
//     if (response.statusCode == 200) {
//       file.writeAsStringSync(response.body, flush: true, mode:FileMode.write );
//       return data;
//     } else {
//       throw Exception('Failed to load ');
//     }
//   }
// }