
import 'dart:convert';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

Future<dynamic>cancelbooking(String bookingid) async {
  var uri = baseUrl + 'cancel_booking/'+bookingid;
  final response = await http.get(Uri.parse(uri),);
  var data = jsonDecode(response.body.toString());
  if (response.statusCode == 200) {
      Fluttertoast.showToast(
        msg: data['message'],
        backgroundColor: Colors.black,
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
      );
      return data;
  }
  else {
    Fluttertoast.showToast(
      msg: 'Something is error',
      backgroundColor: Colors.black,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
    );
    throw Exception('Failed to load ');
  }
}