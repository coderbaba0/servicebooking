
import 'dart:convert';
import 'package:book_services/models/userbookingmodel.dart';
import 'package:http/http.dart' as http;
import 'package:book_services/helper/global.dart';

Future<dynamic>getbookingslist(String userid) async {
  var uri = baseUrl + 'user/mybookings/'+userid;
  final response = await http.get(Uri.parse(uri),);
  var data = jsonDecode(response.body.toString());
  // print('hum hai booking data $data');
  if (response.statusCode == 200) {
    return data;
  } else {
    throw Exception('Failed to load ');
  }
}
// List<userbookingmodel> parseProducts(String responseBody) {
//   final parsed = json.decode(responseBody).cast<Map<String, dynamic>>();
//   return parsed.map<userbookingmodel>((json) => userbookingmodel.fromMap(json)).toList();
// }
// Future<List<userbookingmodel>> fetchProducts(String userid) async {
//   final response = await http.get(Uri.parse((baseUrl + 'user/mybookings/'+userid)));
//   if (response.statusCode == 200) {
//     return parseProducts(response.body);
//   } else {
//     throw Exception('Unable to fetch products from the REST API');
//   }
// }