class AllCategory {
  AllCategory({
       this.id,
       this.name,
       this.icon,
       this.status,
       this.createdAt,
       this.updatedAt,});

  AllCategory.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    icon = json['icon'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }
  late int? id;
 late  String ?name;
 late String ?icon;
  late int ?status;
  late String ?createdAt;
  late String ?updatedAt;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['icon'] = icon;
    map['status'] = status;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    return map;
  }

}