import 'package:book_services/Screens/homepage/homepage.dart';
import 'package:book_services/Screens/services/bookings_step/service_details.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../../constant/constui.dart';
import '../../../helper/global.dart';
class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}
class _SearchScreenState extends State<SearchScreen> {
  bool? searching, error;
  var data;
  String? query;
  String dataurl ='https://maintainance.coinymx.com/api/search_services/';
  @override
  void initState() {
    searching = false;
    error = false;
    query = "";
    super.initState();
  }
  void getSuggestion() async {
    //get suggestion function
    var res = await http.get(
        Uri.parse(dataurl+ query!),
       );
    if (res.statusCode == 200) {
      setState(() {
        data = json.decode(res.body);
        print(data);
        if (data.toString().contains('true')) {
          print('eerrorooror');
          const snackBar = SnackBar(
            content: Text('No Results, Try again'),
          );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        }
        //update data value and UI
      });
    } else {
      //there is error
      setState(() {
        error = true;
      });
    }
  }
  final _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          iconTheme: const IconThemeData(
            color: Colors.white, //change your color here
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              setState(() {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    HomeScreen.routeName, ((route) => false));
              });
            },
          ),
          title: searchField(),
          actions: [
            IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {
                  setState(() {
                    searching = true;
                  });
                }),
          ],
          backgroundColor: searching! ? kPrimaryColor : kPrimaryColor,
        ),
        body: SingleChildScrollView(
            child: Container(
                alignment: Alignment.center,
                child: data == null
                    ? Container(
                    padding: const EdgeInsets.all(20),
                    child: searching!
                        ? Text(data.length==0?'No Results':'Please wait..')
                        : const Text("Search any services here")
                )
                    : Container(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: searching!
                        ? data.length ==0?Text('No Result found'):showSearchSuggestions()

                        : const Text("Find any services"),
                  ),
                )
              // if data is null or not retrived then
              // show message, else show suggestion
            )));
  }
  Widget showSearchSuggestions() {
    List suggestionlist = List.from(data.map((i) {
      return SearchSuggestion.fromJSON(i);
    }));
    //serilizing json data inside model list.
    return Column(
      children: suggestionlist.map((suggestion) {
        return InkResponse(
            onTap: () {
              // print(suggestion.id);
              // print(suggestion.name);
              // print(suggestion.servicedata);
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        ServiceDetails(
                          servicedata: suggestion.servicedata,
                        ),
                  ));
            },
            child: SizedBox(
                width: double.infinity, //make 100% width
                child: Container(
                  padding: const EdgeInsets.only(top:15,left: 10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        data.length==0
                            ? 'Try Again, Nothing found'
                            : suggestion.name,
                        style: const TextStyle(
                          fontSize: 15,
                          // fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Divider(
                        color: Colors.black,
                        thickness: 0.2,
                        indent: 1,
                        endIndent: 25,
                      ),
                    ],
                  ),
                )));
      }).toList(),
    );
  }

  Widget searchField() {
    //search input field
    return Container(
        child: TextField(
          cursorColor: Colors.white,
          controller: _controller,
          autofocus: true,
          //textInputAction: TextInputAction.search,
          style: const TextStyle(color: Colors.white, fontSize: 16),
          decoration: const InputDecoration(
            hintStyle: TextStyle(color: Colors.white, fontSize: 16),
            hintText: "Search Services",
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white, width: 1),
            ), //under line border, set OutlineInputBorder() for all side border
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white, width: 1),
            ), // focused border color
          ), //decoration for search input field
          onChanged: (value) {
            searching = true;
            query = value; //update the value of query
             getSuggestion(); //start to get suggestion
          },
          onSubmitted: (value) {
            getSuggestion();
          },
        ));
  }
}
//serarch suggestion data model to serialize JSON data
class SearchSuggestion {
  String id, name;var servicedata;
  SearchSuggestion({required this.id, required this.name,this.servicedata});
  factory SearchSuggestion.fromJSON(Map<String, dynamic> json) {
    return SearchSuggestion(
      id: json["id"].toString(),
      name: json["name"],
        servicedata:json,
    );
  }
}
